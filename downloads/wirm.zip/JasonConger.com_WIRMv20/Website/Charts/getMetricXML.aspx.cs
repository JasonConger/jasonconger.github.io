//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using System.Data.SqlClient;

public partial class Charts_getMetricXML : System.Web.UI.Page
{
    private string strDate;
    private string strServerID;
    private string strObjectID;
    private string strMetricCounterID;
    private string strInstanceID;
    private float utcOffset;
    private DateTime dtStart;
    private DateTime dtEnd;
    private string strStat;
    private string strCounter;

    protected void Page_Load(object sender, EventArgs e)
    {
        strDate = Request["strDate"];
        strServerID = Request["strServerID"];
        strObjectID = Request["strObjectID"];
        strMetricCounterID = Request["strMetricCounterID"];
        strInstanceID = Request["strInstanceID"];
        strStat = Request["strStat"];
        utcOffset = float.Parse(Session["utcOffset"].ToString());
        strCounter = Request["strCounter"];
        dtStart = DateTime.Parse(strDate + " 00:00:00").AddHours(-1 * utcOffset);
        dtEnd = DateTime.Parse(strDate + " 23:59:59").AddHours(-1 * utcOffset);

        Response.Write(getChartData());
    }

    protected string getChartData()
    {
        string strRetXML = String.Empty;

        strRetXML = getChartHeader();

        strRetXML += getChartBody();

        strRetXML += "</graph>";

        return (strRetXML);
    }

    private string getChartHeader()
    {
        string strHoverText = String.Empty;

        string strRetXML = String.Empty;

        // Setup XML for chart
        strRetXML = "<graph ";
        strRetXML += "Bgcolor='ffffff' ";
        strRetXML += "canvasbgcolor='ececec' ";
        strRetXML += "basefont='Verdana' ";
        strRetXML += "bastfontsize='12px' ";
        strRetXML += "outcnvbasefontsize='12px' ";
        strRetXML += "showValues='0' ";
        strRetXML += "decimalPrecision='2' ";
        strRetXML += "animation='0' ";
        strRetXML += "anchorscale='30' ";

        if (strCounter.Contains("%"))
        {
            strRetXML += "numberSuffix='%' ";
            strRetXML += "yAxisMinValue='0' yAxisMaxValue='100' ";
        }

        // Set hover options
        strRetXML += "hovercapbg='f5f5f5' ";
        strRetXML += "hovercapborder='c0c0c0' ";
        strRetXML += "showhovercap='1' ";
        strRetXML += ">";

        return strRetXML;
    }

    private string getChartBody()
    {
        string strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;

        string strRetXML = String.Empty;

        ArrayList alValues = new ArrayList();

        switch (strProvider)
        {
            case "System.Data.OracleClient":
                alValues = getDataOracle();
                break;
            default:
                alValues = getDataSQL();
                break;
        }

        string strName;
        string strShowName;
        string strColor = "5583D3";

        for (int x = 0; x < alValues.Count; x++)
        {
            // Add labels to certain hours
            switch (x)
            {
                case 0:
                    strName = Resources.WIRM.Midnight;
                    break;
                case 12:
                    strName = Resources.WIRM.Noon;
                    break;
                default:
                    if (x > 12)
                        strName = (x - 12).ToString() + ":00 PM";
                    else
                        strName = x.ToString() + ":00 AM";
                    break;
            }

            if (x % 4 == 0)
                strShowName = "1";
            else
                strShowName = "0";


            strRetXML += String.Format("<set value='{0}' ", alValues[x].ToString());
            strRetXML += String.Format("name='{0}' ", strName);
            strRetXML += String.Format(" showName='{0}' ", strShowName);
            strRetXML += "alpha='80' ";
            strRetXML += string.Format("color='{0}' ", strColor);
            strRetXML += "/>";
        }

        return strRetXML;
    }

    private ArrayList getDataSQL()
    {
        string strRetXML = String.Empty;

        ArrayList alValues = new ArrayList();

        string strSql = String.Format(
            "SELECT DATEADD(hh, {6}, SDB_METRICS.METRICUPDATETIME) AS METRICUPDATETIME, " +
            "SDB_METRICS.{7} AS STATVAL " +
            "FROM SDB_METRICS " +
            "INNER JOIN LU_METRIC ON SDB_METRICS.FK_METRICID = LU_METRIC.PK_METRICID " +
            "WHERE (SDB_METRICS.FK_SERVERID = '{0}') AND (LU_METRIC.FK_OBJECTID = '{1}') AND " +
            "(LU_METRIC.FK_METRICCOUNTERID = '{2}') AND (LU_METRIC.FK_INSTANCEID = '{3}') AND " +
            "(DATEADD(hh, {6}, SDB_METRICS.METRICUPDATETIME) BETWEEN '{4}' AND '{5}') " +
            "ORDER BY METRICUPDATETIME",
            strServerID,
            strObjectID,
            strMetricCounterID,
            strInstanceID,
            dtStart.ToString(),
            dtEnd.ToString(),
            utcOffset.ToString(),
            strStat);
            
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        SqlCommand sqlCmd = new SqlCommand(strSql, sqlConn);

        SqlDataReader dr;

        sqlConn.Open();

        try
        {
            dr = sqlCmd.ExecuteReader();

            while (dr.Read())
                alValues.Add(dr["STATVAL"].ToString());
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }

        return alValues;
    }

    private ArrayList getDataOracle()
    {
        string strRetXML = String.Empty;

        ArrayList alValues = new ArrayList();

        string strSql = String.Format(
            "SELECT SDB_METRICS.METRICUPDATETIME + ({6}/24) AS METRICUPDATETIME, " +
            "SDB_METRICS.{7} " +
            "FROM SDB_METRICS " +
            "INNER JOIN LU_METRIC ON SDB_METRICS.FK_METRICID = LU_METRIC.PK_METRICID " +
            "WHERE (SDB_METRICS.FK_SERVERID = '{0}') AND (LU_METRIC.FK_OBJECTID = '{1}') AND " +
            "(LU_METRIC.FK_METRICCOUNTERID = '{2}') AND (LU_METRIC.FK_INSTANCEID = '{3}') AND " +
            "(METRICUPDATETIME BETWEEN TO_DATE('{4}', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('{5}', 'YYYY-MM-DD HH24:MI:SS')) " +
            "ORDER BY METRICUPDATETIME",
            strServerID,
            strObjectID,
            strMetricCounterID,
            strInstanceID,
            dtStart.ToString("yyyy-MM-dd hh:mm:ss"),
            dtEnd.ToString("yyyy-MM-dd hh:mm:ss"),
            utcOffset.ToString(),
            strStat);

        OracleConnection sqlConn = new OracleConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        OracleCommand sqlCmd = new OracleCommand(strSql, sqlConn);

        OracleDataReader dr;

        sqlConn.Open();

        try
        {
            dr = sqlCmd.ExecuteReader();

            while (dr.Read())
                alValues.Add(dr["MAXMETRICVALUE"].ToString());
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }

        return alValues;
    }
}
