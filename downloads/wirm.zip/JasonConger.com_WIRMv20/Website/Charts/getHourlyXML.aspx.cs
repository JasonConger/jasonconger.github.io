using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.OracleClient;

public partial class Charts_getHourlyXML : System.Web.UI.Page
{
    private string strDate;
    private string strAppName;
    private string strAppID;
    private string strShow;
    private string strStartDate;
    private string strEndDate;
    private float utcOffset;

    protected void Page_Load(object sender, EventArgs e)
    {
        strDate = Request["strDate"];
        strAppName = Request["strAppName"];
        strAppID = Request["strAppID"];
        strShow = Request["strShow"];
        strStartDate = strDate + " 0:0:0";
        strEndDate = strDate + " 23:59:59";
        utcOffset = float.Parse(Session["utcOffset"].ToString());

        Response.Write(getChartData());
    }

    protected string getChartData()
    {
        string strRetXML = String.Empty;

        strRetXML = getChartHeader();

        strRetXML += getChartBody();

        strRetXML += "</graph>";

        return (strRetXML);
    }

    private string getChartBody()
    {
        string strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;

        string strRetXML = String.Empty;

        int[] hours;

        switch (strProvider)
        {
            case "System.Data.SqlClient":
                hours = getHoursSQL();
                break;
            case "System.Data.OracleClient":
                hours = getHoursOracle();
                break;
            default:
                hours = getHoursSQL();
                break;
        }

        

        // Populate graph data set
        for (int x = 0; x < 24; x++)
        {
            string strName;
            string strShowName;
            string strColor = "5583D3";

            // Add labels to certain hours
            switch (x)
            {
                case 0:
                    strName = Resources.WIRM.Midnight;
                    break;
                case 12:
                    strName = Resources.WIRM.Noon;
                    break;
                default:
                    if (x > 12)
                        strName = (x - 12).ToString() + ":00 PM";
                    else
                        strName = x.ToString() + ":00 AM";
                    break;
            }

            if (x % 4 == 0)
                strShowName = "1";
            else
                strShowName = "0";

            strRetXML += String.Format("<set name='{0}' ", strName);
            strRetXML += String.Format("value='{0}' ", hours[x].ToString());
            strRetXML += String.Format("link='hourDetail.aspx?strDate={0}&strHour={1}&strAppID={2}'", strDate, x.ToString(), strAppID);
            strRetXML += String.Format(" showName='{0}' ", strShowName);
            strRetXML += "alpha='80' ";
            strRetXML += string.Format("color='{0}' ", strColor);
            strRetXML += " />";
        }

        return strRetXML;
    }

    private int[] getHoursSQL()
    {
        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlDataReader sqlDR;
        SqlCommand sqlCmd;

        // Set up SQL query parameters
        string strSQL;
        
        // array to hold sessions counts for each hour
        int[] hours = new int[24];

        // initialize all array values to 0
        for (int i = 0; i < 24; i++)
            hours[i] = 0;


        // Connect to the RM summary database
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        

        try
        {
            sqlConn.Open();

            // Select sessions started on this day
            if (strShow == "Users")
            {
                strSQL = String.Format("SELECT MAX(DATEADD(hh, {0}, SDB_SESSION.SESSIONSTART)) AS sessionStarted, LU_USER.PK_USERID FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID WHERE (SDB_SESSION.SESSIONSTART BETWEEN DATEADD(hh, {3}, '{1}') AND DATEADD(hh, {3}, '{2}')) ", utcOffset, strStartDate, strEndDate, utcOffset * -1);

                if (strAppID.Trim() != String.Empty)
                    strSQL += String.Format(" AND SDB_SESSION.FK_APPNAMEID = '{0}'", strAppID);

                strSQL += "GROUP BY LU_USER.USERNAME, LU_USER.PK_USERID";
            }
            else
            {
                strSQL = String.Format("SELECT DATEADD(hh, {0}, SESSIONSTART) as sessionStarted FROM SDB_SESSION WHERE SESSIONSTART BETWEEN DATEADD(hh, {3}, '{1}') AND DATEADD(hh, {3}, '{2}')", utcOffset, strStartDate, strEndDate, utcOffset * -1);

                if (strAppID.Trim() != String.Empty)
                    strSQL += String.Format(" AND SDB_SESSION.FK_APPNAMEID = '{0}'", strAppID);
            }

            // Execute the SQL command to retreive the data
            sqlCmd = new SqlCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            while (sqlDR.Read())
            {
                DateTime sessionStarted = (DateTime)sqlDR["sessionStarted"];
                int hourStarted = sessionStarted.Hour;

                if (sessionStarted.ToShortDateString() == strDate)
                {
                    hours[hourStarted]++;
                }
            }

            return hours;

        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }

        
    }

    private int[] getHoursOracle()
    {
        OracleConnection sqlConn;
        OracleDataReader sqlDR;
        OracleCommand sqlCmd;

        string strSQL;

        // array to hold sessions counts for each hour
        int[] hours = new int[24];

        // initialize all array values to 0
        for (int i = 0; i < 24; i++)
            hours[i] = 0;

        // Connect to the RM summary database
        sqlConn = new OracleConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);

        try
        {
            sqlConn.Open();

            // Select sessions started on this day
            if (strShow == "Users")
            {
                strSQL = String.Format("SELECT MAX(SDB_SESSION.SESSIONSTART + ({0}/24)) AS sessionStarted, LU_USER.PK_USERID FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID WHERE SDB_SESSION.SESSIONSTART BETWEEN  (To_Date('{1}', 'YYYY-MM-DD HH24:MI:SS') + ({3}/24)) AND (To_Date('{2}', 'YYYY-MM-DD HH24:MI:SS') + ({3}/24)) ", utcOffset, DateTime.Parse(strStartDate).ToString("yyyy-MM-dd HH:mm:ss"), DateTime.Parse(strEndDate).ToString("yyyy-MM-dd HH:mm:ss"), utcOffset * -1);

                if (strAppID.Trim() != String.Empty)
                    strSQL += String.Format(" AND SDB_SESSION.FK_APPNAMEID = '{0}'", strAppID);

                strSQL += "GROUP BY LU_USER.USERNAME, LU_USER.PK_USERID";
            }
            else
            {
                strSQL = String.Format("SELECT SDB_SESSION.SESSIONSTART + ({0}/24) as sessionStarted FROM SDB_SESSION WHERE SESSIONSTART BETWEEN To_Date('{1}', 'YYYY-MM-DD HH24:MI:SS') + ({3}/24) AND To_Date('{2}', 'YYYY-MM-DD HH24:MI:SS') + ({3}/24)", utcOffset, DateTime.Parse(strStartDate).ToString("yyyy-MM-dd HH:mm:ss"), DateTime.Parse(strEndDate).ToString("yyyy-MM-dd HH:mm:ss"), utcOffset * -1);

                if (strAppID.Trim() != String.Empty)
                    strSQL += String.Format(" AND SDB_SESSION.FK_APPNAMEID = '{0}'", strAppID);
            }

            // Execute the SQL command to retreive the data
            sqlCmd = new OracleCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            while (sqlDR.Read())
            {
                DateTime sessionStarted = (DateTime)sqlDR["sessionStarted"];
                int hourStarted = sessionStarted.Hour;

                if (sessionStarted.ToShortDateString() == strDate)
                {
                    hours[hourStarted]++;
                }
            }

            return hours;

        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
    }

    private string getChartHeader()
    {
        string strRetXML = String.Empty;

        // generate graph XML header data
        strRetXML = "<graph ";
        strRetXML += "basefont='Verdana' ";
        strRetXML += "bastfontsize='10px' ";
        strRetXML += "outcnvbasefontsize='10px' ";
        strRetXML += String.Format("caption='{0} {1}' ", 
            Resources.WIRM.NumberOfSessionsStartedOn, strDate);

        if (strAppName.Trim() != String.Empty)
            strRetXML += String.Format("subcaption='({0} {1})' ", Resources.WIRM.For.ToLower(), strAppName);

        strRetXML += "yaxisname='" + Resources.WIRM.Sessions + "' ";
        strRetXML += "xaxisname='" + Resources.WIRM.TimeOfDay + "' ";
        strRetXML += "decimalPrecision='0' ";
        strRetXML += "showGridBg='0' ";
        strRetXML += "showCanvas='1' ";
        strRetXML += "canvasbgcolor='ececec' ";
        strRetXML += "divlinecolor='ececec' ";
        strRetXML += "animation='0' ";

        // Set hover options
        strRetXML += "hovercapbg='f5f5f5' ";
        strRetXML += "hovercapborder='c0c0c0' ";
        strRetXML += "hovercapSepChar=' - " + Resources.WIRM.Logons.ToLower() + ":' ";

        strRetXML += "showhovercap='1' ";
        strRetXML += ">";

        return strRetXML;
    }
}
