//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using System.Threading;

public partial class _Default : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Session["minDateExtreme"] == null) || (Session["maxDateExtreme"] == null))
        {
            if (Session["utcOffset"] != null)
            {
                DataAccess da = new DataAccess();
                float utcOffset = float.Parse(Session["utcOffset"].ToString());
                string strMinDateExtreme = String.Empty;
                string strMaxDateExtreme = String.Empty;

                da.DateHelper(utcOffset, ref strMinDateExtreme, ref strMaxDateExtreme);

                Session["minDateExtreme"] = strMinDateExtreme;
                Session["maxDateExtreme"] = strMaxDateExtreme;
            }
            else
            {
                throw new Exception(Resources.WIRM.ErrorGettingDatesUTCOffset);
            }
        }
    }
}
