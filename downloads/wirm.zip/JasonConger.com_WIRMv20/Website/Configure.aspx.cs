using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data.OracleClient;

public partial class Configure : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
            Resources.WIRM.Configuration;

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.Configuration;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/configure.gif";

            getConfiguration();
            hlUTCOffsetHelp.Attributes.Add("onClick", "window.open(this.href, 'UTCHelp', 'width=300px, height=200px, directories=no, menubar=no, resizable=yes, status=yes, toolbar=no, scrollbars=yes'); return false;");

            lblDBName.Text += ":";
        }
    }

    private string getConnectionString()
    {
        string strSQLAuth = "Data Source=[DBServer];Initial Catalog=[DBName];Persist Security Info=True;User ID=[DBUsername];Password=[DBPassword];Current Language=[DBLanguage]";
        string strIntegratedAuth = "Data Source=[DBServer];Initial Catalog=[DBName];Integrated Security=True;Current Language=[DBLanguage]";
        string strOracle = "Data Source=[DBServer];Persist Security Info=True;Password=[DBPassword];User ID=[DBUsername]";
        string strConnectionString = String.Empty;

        if (ddlDBServerType.SelectedValue == "System.Data.OracleClient")
            strSQLAuth = strOracle;

        if (rblAuth.SelectedIndex == 0)
        {
            // Windows Authentication
            strConnectionString = strIntegratedAuth;
        }
        else
        {
            // Sql Authentication
            strConnectionString = strSQLAuth;
            strConnectionString = strConnectionString.Replace("[DBUsername]", tbUsername.Text.Trim());
            strConnectionString = strConnectionString.Replace("[DBPassword]", tbPassword.Text.Trim());
        }

        strConnectionString = strConnectionString.Replace("[DBServer]", tbDBServerName.Text.Trim());
        strConnectionString = strConnectionString.Replace("[DBName]", tbDBName.Text.Trim());
        strConnectionString = strConnectionString.Replace("[DBLanguage]", getCurrentLanguage(ddlLanguage.SelectedValue));

        return strConnectionString;
    }

    private string getCurrentLanguage(string strLocale)
    {
        string strCurrentLanguage = String.Empty;
        
        switch (strLocale)
        {
            case "en-US":
                strCurrentLanguage = "English";
                break;
            case "de-DE":
                strCurrentLanguage = "German";
                break;
            case "nl-NL":
                strCurrentLanguage = "Dutch";
                break;
            default:
                strCurrentLanguage = "English";
                break;
        }

        return strCurrentLanguage;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (testConnection())
        {
            Configuration config = WebConfigurationManager.OpenWebConfiguration("~");
            AppSettingsSection appSettings = config.AppSettings;
            ConnectionStringsSection connStrings = config.ConnectionStrings;
            GlobalizationSection globalSettings = 
                (GlobalizationSection)config.GetSection("system.web/globalization");

            if (appSettings != null)
            {
                appSettings.Settings["TimeZoneUTCOffset"].Value = tbUTCOffset.Text;
            }

            connStrings.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString = getConnectionString();
            connStrings.ConnectionStrings["rmsummarydbConnectionString"].ProviderName = ddlDBServerType.SelectedValue;

            globalSettings.UICulture = ddlLanguage.SelectedValue;
            globalSettings.Culture = ddlLanguage.SelectedValue;

            try
            {
                config.Save();
                Response.Redirect("~/Default.aspx");
            }
            catch
            {
                Response.Write(Resources.WIRM.CannotWriteWebConfig);
            }
        }
    }

    private void getConfiguration()
    {
        Configuration config = WebConfigurationManager.OpenWebConfiguration("~");
        AppSettingsSection appSettings = config.AppSettings;
        ConnectionStringsSection connStrings = config.ConnectionStrings;
        GlobalizationSection globalSettings =
                (GlobalizationSection)config.GetSection("system.web/globalization");

        string strConnString = connStrings.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString;
        string strProvider = connStrings.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;

        ddlLanguage.SelectedIndex = ddlLanguage.Items.IndexOf(ddlLanguage.Items.FindByValue(globalSettings.Culture));

        ddlDBServerType.SelectedIndex = ddlDBServerType.Items.IndexOf(ddlDBServerType.Items.FindByValue(strProvider));

        if (strConnString.Contains("Integrated Security=True"))
        {
            rblAuth.SelectedIndex = 0;
        }
        else
        {
            rblAuth.SelectedIndex = 1;
        }

        enableSqlAuth();
        controlDBOptions();

        tbUTCOffset.Text = appSettings.Settings["TimeZoneUTCOffset"].Value;

        string[] strConnStringPairs = strConnString.Split(';');

        foreach (string strPair in strConnStringPairs)
        {
            string[] values = strPair.Split('=');

            string strName = values[0];
            string strValue = values[1];

            switch (strName)
            {
                case "Data Source":
                    tbDBServerName.Text = strValue;
                    break;

                case "Initial Catalog":
                    tbDBName.Text = strValue;
                    break;

                case "User ID":
                    tbUsername.Text = strValue;
                    break;

                case "Password":
                    tbPassword.Text = strValue;
                    break;
            }
        }
    }

    protected void rblAuth_SelectedIndexChanged(object sender, EventArgs e)
    {
        enableSqlAuth();
    }

    private void enableSqlAuth()
    {
        bool bEnabled;

        if (rblAuth.SelectedIndex == 0)
            bEnabled = false;
        else
            bEnabled = true;


        lblUsername.Enabled = bEnabled;
        lblPassword.Enabled = bEnabled;
        tbUsername.Enabled = bEnabled;
        tbPassword.Enabled = bEnabled;
    }

    private void controlDBOptions()
    {
        if (ddlDBServerType.SelectedValue == "System.Data.OracleClient")
        {
            rblAuth.Items[0].Enabled = false;
            lblDBName.Visible = false;
            tbDBName.Visible = false;
            rblAuth.Items[1].Selected = true;
            lblDBServer.Text = Resources.WIRM.TNSServiceName;
        }
        else
        {
            rblAuth.Items[0].Enabled = true;
            lblDBName.Visible = true;
            tbDBName.Visible = true;
            lblDBServer.Text = Resources.WIRM.DatabaseServer;
        }
    }

    protected void btnTest_Click(object sender, EventArgs e)
    {
        testConnection();
    }

    private bool testConnection()
    {
        bool bConnection = false;

        if(ddlDBServerType.SelectedValue == "System.Data.SqlClient")
            bConnection = testConnectionSQL();

        if (ddlDBServerType.SelectedValue == "System.Data.OracleClient")
            bConnection = testConnectionOracle();

        return bConnection;
    }

    private bool testConnectionSQL()
    {
        bool bConnection = false;

        SqlConnection sqlConn = new SqlConnection();
        sqlConn.ConnectionString = getConnectionString();
        string strSql = "SELECT TOP 1 * FROM SDB_SESSION";
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandText = strSql;
        sqlCmd.Connection = sqlConn;

        try
        {
            sqlConn.Open();
            sqlCmd.ExecuteNonQuery();
            lblSQLTest.Text = "<img src='images/check.gif' /> <b>" + Resources.WIRM.TestCompletedSuccessfully + "</b>";
            bConnection = true;
        }
        catch (Exception ex)
        {
            lblSQLTest.Text = "<span style='color: red'><img src='images/error.gif' /> <b>" + Resources.WIRM.TestFailed + "</b> <br />" + ex.Message + "</span>";
            bConnection = false;
        }
        finally
        {
            sqlCmd.Dispose();
            sqlConn.Close();
        }

        return bConnection;
    }

    private bool testConnectionOracle()
    {
        bool bConnection = false;

        OracleConnection sqlConn = new OracleConnection();
        sqlConn.ConnectionString = getConnectionString();
        string strSql = "SELECT * FROM SDB_SESSION WHERE ROWNUM <= 1";
        OracleCommand sqlCmd = new OracleCommand();
        sqlCmd.CommandText = strSql;
        sqlCmd.Connection = sqlConn;

        try
        {
            sqlConn.Open();
            sqlCmd.ExecuteNonQuery();
            lblSQLTest.Text = "<img src='images/check.gif' /> <b>" + Resources.WIRM.TestCompletedSuccessfully + "</b>";
            bConnection = true;
        }
        catch (Exception ex)
        {
            lblSQLTest.Text = "<span style='color: red'><img src='images/error.gif' /> <b>" + Resources.WIRM.TestFailed + "</b> <br />" + ex.Message + "</span>";
            bConnection = false;
        }
        finally
        {
            sqlCmd.Dispose();
            sqlConn.Close();
        }

        return bConnection;
    }

    protected void ddlDBServerType_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblSQLTest.Text = String.Empty;
        controlDBOptions();
    }

    protected void ddlLanguage_SelectedIndexChanged(object sender, EventArgs e)
    {
        Configuration config = WebConfigurationManager.OpenWebConfiguration("~");
        ConnectionStringsSection connStrings = config.ConnectionStrings;
        GlobalizationSection globalSettings =
            (GlobalizationSection)config.GetSection("system.web/globalization");

        string strUtcOffset = Session["utcOffset"].ToString();

        string strConnString = connStrings.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString;
        globalSettings.UICulture = ddlLanguage.SelectedValue;
        globalSettings.Culture = ddlLanguage.SelectedValue;

        string[] strConnStringPairs = strConnString.Split(';');

        foreach (string strPair in strConnStringPairs)
        {
            string[] values = strPair.Split('=');

            string strName = values[0];
            string strValue = values[1];

            if (strName == "Current Language")
            {
                strConnString = strConnString.Replace(strValue, getCurrentLanguage(ddlLanguage.SelectedValue));
            }
        }

        connStrings.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString = strConnString;

        bool bSaved = false;

        try
        {
            config.Save();
            bSaved = true;
        }
        catch (Exception ex)
        {
            Response.Write(Resources.WIRM.CannotWriteWebConfig);
        }

        if (bSaved)
        {
            Response.Redirect("~/Default.aspx?redirect=Configure.aspx");
        }
    }
}
