//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class sessionDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
            Resources.WIRM.SessionDetails;

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.SessionDetails;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/sessionDetail.gif";
        }

        if (ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName == "System.Data.OracleClient")
        {
            sdsSessionDetail.ProviderName = "System.Data.OracleClient";
            sdsProcessDetail.ProviderName = "System.Data.OracleClient";
            
            sdsSessionDetail.SelectCommand = String.Format("SELECT (SDB_SESSION.SESSIONSTART + ({0}/24)) AS SESSIONSTART, (SDB_SESSION.SESSIONEND + ({0}/24)) AS SESSIONEND, SDB_SESSION.DURATION, SDB_SESSION.SESSIONID, SDB_SESSION.TOTALTIMESUM, SDB_SESSION.ACTIVETIMESUM, SDB_SESSION.CPUTIMESUM, SDB_SESSION.MEMORYSUM, LU_USER.USERNAME, LU_SERVERNAME.SERVERNAME, LU_APPNAME.APPNAME, LU_CLIENT.CLIENTNAME, LU_CLIENT.CLIENTADDRESS, SDB_SESSION.PK_SDB_SESSIONID, LU_CLIENTPROPERTIES.BUILD, LU_CLIENTPROPERTIES.VERSION, SDB_CLIENTHISTORY.USINGSG, LU_CLIENTTYPEMAPPINGS.CLIENTTYPENAME, LU_LAUNCHER.LAUNCHER FROM LU_CLIENTPROPERTIES INNER JOIN SDB_CLIENTHISTORY ON LU_CLIENTPROPERTIES.PK_CLIENTPROPERTIESID = SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID INNER JOIN LU_CLIENTTYPEMAPPINGS ON LU_CLIENTPROPERTIES.FK_CLIENTTYPEID = LU_CLIENTTYPEMAPPINGS.PK_CLIENTTYPEID INNER JOIN LU_LAUNCHER ON SDB_CLIENTHISTORY.FK_LAUNCHERID = LU_LAUNCHER.PK_LAUNCHERID RIGHT OUTER JOIN SDB_SESSION INNER JOIN LU_USER ON SDB_SESSION.FK_USERID = LU_USER.PK_USERID INNER JOIN LU_SERVER ON SDB_SESSION.FK_SERVERID = LU_SERVER.PK_SERVERID INNER JOIN LU_SERVERNAME ON LU_SERVER.FK_SERVERNAMEID = LU_SERVERNAME.PK_SERVERNAMEID INNER JOIN LU_CLIENT ON SDB_SESSION.FK_CLIENTID = LU_CLIENT.PK_CLIENTID INNER JOIN LU_APPNAME ON SDB_SESSION.FK_APPNAMEID = LU_APPNAME.PK_APPNAMEID ON SDB_CLIENTHISTORY.FK_SDB_SESSIONID = SDB_SESSION.PK_SDB_SESSIONID WHERE (SDB_SESSION.PK_SDB_SESSIONID = {1})", float.Parse(Session["utcOffset"].ToString()), Request.QueryString["sessionID"]);
            sdsProcessDetail.SelectCommand = String.Format("SELECT LU_PROCESS.VERSION, LU_PROCESS.PRODUCTDATE, LU_PATH.PATH, LU_PROCESSNAME.PROCESSNAME, SDB_PROCESS.PID, SDB_PROCESS.EXITCODE, (SDB_PROCESS.STARTTIME + ({0}/24)) AS STARTTIME, (SDB_PROCESS.ENDTIME + ({0}/24)) AS ENDTIME, SDB_PROCESS.TOTALTIME, SDB_PROCESS.ACTIVETIME, SDB_PROCESS.MEMORY, SDB_PROCESS.PAGEFILE, SDB_PROCESS.PAGEFAULTS, SDB_PROCESS.PAGEDPOOL, SDB_PROCESS.NONPAGEDPOOL FROM SDB_PROCESS INNER JOIN LU_PROCESS ON SDB_PROCESS.FK_PROCESSID = LU_PROCESS.PK_PROCESSID INNER JOIN LU_PATH ON LU_PROCESS.FK_PATHID = LU_PATH.PK_PATHID INNER JOIN LU_PROCESSNAME ON LU_PROCESS.FK_PROCESSNAMEID = LU_PROCESSNAME.PK_PROCESSNAMEID WHERE SDB_PROCESS.FK_SDB_SESSIONID = '{1}'", float.Parse(Session["utcOffset"].ToString()), Request.QueryString["sessionID"]);
        }
        else
        {
            sdsSessionDetail.SelectCommand = String.Format("SELECT DATEADD(hh, {0}, SDB_SESSION.SESSIONSTART) AS SESSIONSTART, DATEADD(hh, {0}, SDB_SESSION.SESSIONEND) AS SESSIONEND, SDB_SESSION.DURATION, SDB_SESSION.SESSIONID, SDB_SESSION.TOTALTIMESUM, SDB_SESSION.ACTIVETIMESUM, SDB_SESSION.CPUTIMESUM, SDB_SESSION.MEMORYSUM, LU_USER.USERNAME, LU_SERVERNAME.SERVERNAME, LU_APPNAME.APPNAME, LU_CLIENT.CLIENTNAME, LU_CLIENT.CLIENTADDRESS, SDB_SESSION.PK_SDB_SESSIONID, LU_CLIENTPROPERTIES.BUILD, LU_CLIENTPROPERTIES.VERSION, SDB_CLIENTHISTORY.USINGSG, LU_CLIENTTYPEMAPPINGS.CLIENTTYPENAME, LU_LAUNCHER.LAUNCHER FROM LU_CLIENTPROPERTIES INNER JOIN SDB_CLIENTHISTORY ON LU_CLIENTPROPERTIES.PK_CLIENTPROPERTIESID = SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID INNER JOIN LU_CLIENTTYPEMAPPINGS ON LU_CLIENTPROPERTIES.FK_CLIENTTYPEID = LU_CLIENTTYPEMAPPINGS.PK_CLIENTTYPEID INNER JOIN LU_LAUNCHER ON SDB_CLIENTHISTORY.FK_LAUNCHERID = LU_LAUNCHER.PK_LAUNCHERID RIGHT OUTER JOIN SDB_SESSION INNER JOIN LU_USER ON SDB_SESSION.FK_USERID = LU_USER.PK_USERID INNER JOIN LU_SERVER ON SDB_SESSION.FK_SERVERID = LU_SERVER.PK_SERVERID INNER JOIN LU_SERVERNAME ON LU_SERVER.FK_SERVERNAMEID = LU_SERVERNAME.PK_SERVERNAMEID INNER JOIN LU_CLIENT ON SDB_SESSION.FK_CLIENTID = LU_CLIENT.PK_CLIENTID INNER JOIN LU_APPNAME ON SDB_SESSION.FK_APPNAMEID = LU_APPNAME.PK_APPNAMEID ON SDB_CLIENTHISTORY.FK_SDB_SESSIONID = SDB_SESSION.PK_SDB_SESSIONID WHERE (SDB_SESSION.PK_SDB_SESSIONID = {1})", Session["utcOffset"], Request.QueryString["sessionID"]);
            sdsProcessDetail.SelectCommand = String.Format("SELECT LU_PROCESS.VERSION, LU_PROCESS.PRODUCTDATE, LU_PATH.PATH, LU_PROCESSNAME.PROCESSNAME, SDB_PROCESS.PID, SDB_PROCESS.EXITCODE, DATEADD(hh, {0}, SDB_PROCESS.STARTTIME) AS STARTTIME, DATEADD(hh, {0}, SDB_PROCESS.ENDTIME) AS ENDTIME, SDB_PROCESS.TOTALTIME, SDB_PROCESS.ACTIVETIME, SDB_PROCESS.MEMORY, SDB_PROCESS.PAGEFILE, SDB_PROCESS.PAGEFAULTS, SDB_PROCESS.PAGEDPOOL, SDB_PROCESS.NONPAGEDPOOL FROM SDB_PROCESS INNER JOIN LU_PROCESS ON SDB_PROCESS.FK_PROCESSID = LU_PROCESS.PK_PROCESSID INNER JOIN LU_PATH ON LU_PROCESS.FK_PATHID = LU_PATH.PK_PATHID INNER JOIN LU_PROCESSNAME ON LU_PROCESS.FK_PROCESSNAMEID = LU_PROCESSNAME.PK_PROCESSNAMEID WHERE SDB_PROCESS.FK_SDB_SESSIONID = {1}", Session["utcOffset"], Request.QueryString["sessionID"]);
        }
    }

    protected void gvProcessDetail_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        e.Row.Cells[4].Visible = false;
        e.Row.Cells[5].Visible = false;
        e.Row.Cells[6].Visible = false;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string strProcessName = e.Row.Cells[0].Text;
            string strProcessMemory = e.Row.Cells[3].Text;
            string strVersion = e.Row.Cells[4].Text;
            string strProductDate = e.Row.Cells[5].Text;
            string strPath = e.Row.Cells[6].Text.Replace("\\", "\\\\");

            string strMouseOver = string.Format("stm(['{0}','{4}: {1} <br /> {5}: {2} <br /> {6}: {3}'],Style[0])",strProcessName, strVersion, strProductDate, strPath, Resources.WIRM.Version, Resources.WIRM.Date, Resources.WIRM.Path);

            e.Row.Cells[0].Attributes.Add("style", "cursor: help");
            e.Row.Cells[0].Attributes.Add("onMouseOver", strMouseOver);
            e.Row.Cells[0].Attributes.Add("onMouseOut", "htm()");

            e.Row.Cells[3].Text = getMemory(double.Parse(strProcessMemory));
        }
    }

    protected void fvSessionDetail_DataBound(object sender, EventArgs e)
    {
        Label lblDuration = (Label)fvSessionDetail.FindControl("DURATIONLabel");
        Label lblActiveTime = (Label)fvSessionDetail.FindControl("ACTIVETIMESUMLabel");
        Label lblCPUTime = (Label)fvSessionDetail.FindControl("CPUTIMESUMLabel");
        Label lblMemoryUsed = (Label)fvSessionDetail.FindControl("MEMORYSUMLabel");
        Label lblUsingSG = (Label)fvSessionDetail.FindControl("USINGSGLabel");

        try { lblDuration.Text = getTimeSpan(double.Parse(lblDuration.Text)); }
        catch { lblDuration.Text = String.Empty; }

        try { lblActiveTime.Text = getTimeSpan(double.Parse(lblActiveTime.Text)); }
        catch { lblActiveTime.Text = String.Empty; }

        try { lblCPUTime.Text = getTimeSpan(double.Parse(lblCPUTime.Text)); }
        catch { lblCPUTime.Text = String.Empty; }

        try { lblMemoryUsed.Text = getMemory(double.Parse(lblMemoryUsed.Text)); }
        catch { lblMemoryUsed.Text = String.Empty; }

        if(lblUsingSG.Text == "1")
            lblUsingSG.Text = " &nbsp (" + Resources.WIRM.ViaSecureGateway + ")";
        else
            lblUsingSG.Text = String.Empty;
    }

    public string getTimeSpan(double milliseconds)
    {
        // Note: 1 tick = 100 nanoseconds
        // 1 millisecond = 1,000,000 nanoseconds
        
        long ticks = (long)Math.Round(milliseconds * 10000);

        string strTimeSpan = "";

        TimeSpan ts = new TimeSpan(ticks);
        int intSeconds = ts.Seconds;
        int intMinutes = ts.Minutes;
        int intHours = ts.Hours;
        int intDays = ts.Days;

        if (intDays > 0)
            strTimeSpan += intDays.ToString() + " " + Resources.WIRM.Days.ToLower() + " ";

        if (intHours == 1)
            strTimeSpan += intHours.ToString() + " " + Resources.WIRM.Hour.ToLower() + " ";
        else
            strTimeSpan += intHours.ToString() + " " + Resources.WIRM.Hours.ToLower() + " ";

        strTimeSpan += intMinutes.ToString() + " " + Resources.WIRM.Minutes.ToLower() + " ";
        strTimeSpan += intSeconds.ToString() + " " + Resources.WIRM.Seconds.ToLower() + " ";

        return strTimeSpan;
    }

    public string getMemory(double megabytes)
    {
        string strMemory = "";

        // If Megabytes < 1, return Kilobytes
        if (megabytes < 1)
        {
            double KB = Math.Round((megabytes * 1024), 2);
            strMemory = KB.ToString() + " Kb";
        }
        
        // If Megabytes > 1024 (1 GB), rerutn Gigabytes
        if(megabytes > 1024)
        {
            double GB = Math.Round((megabytes / 1024), 2);
            strMemory = GB.ToString() + " GB";
        }

        // If Megabytes > 1 AND < 1024, return Megabytes
        if ((megabytes > 1) && (megabytes < 1024))
        {
            double MB = Math.Round(megabytes, 2);
            strMemory = MB.ToString() + " MB";
        }

        return strMemory;
    }
}
