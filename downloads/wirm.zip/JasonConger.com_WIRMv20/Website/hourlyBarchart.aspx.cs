//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class chartTest : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
                Resources.WIRM.SessionsStartedbyHour;

        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.SessionsStartedbyHour;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/graph.gif";
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        HiddenField1.Value = "Users";
    }

    protected void btnSessions_Click(object sender, EventArgs e)
    {
        HiddenField1.Value = "Sessions";
    }
   
}
