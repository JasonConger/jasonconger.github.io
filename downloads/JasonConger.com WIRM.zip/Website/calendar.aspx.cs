//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
// Date:    April 24th, 2006
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page 
{
    // 2D array to hold day session values
    public string[,] strSessions = new String[13, 32];

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Usage Calendar";

            Page.Title = "Web Interface for Resource Manager - Usage Calendar";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/calendar.gif";
        }

        // Set a session variable for the UTC offset.
        // Note that a UTC offset specified in web.config takes precedence
        if (Session["utcOffset"] == null)
        {
            // Get UTC offset (if any) from web.config
            string strAppSettingUTCOffset = ConfigurationManager.AppSettings["TimeZoneUTCOffset"];
            string strClientUTCOffset = Request["clientUTCOffset"];

            if (strClientUTCOffset.Trim() == String.Empty)
                Response.Redirect("Default.aspx");

            if (strAppSettingUTCOffset.Trim() != string.Empty)
                Session["utcOffset"] = strAppSettingUTCOffset;
            else
                Session["utcOffset"] = strClientUTCOffset;

            Session.Timeout = 480;
        }

        // Set our view date to the first day of the current month.
        string strMonth = DateTime.Now.Month.ToString();
        string strDay = "1";
        string strYear = DateTime.Now.Year.ToString();
        string strWorkingDate = strMonth + "/" + strDay + "/" + strYear;
        rmCalendar.VisibleDate = DateTime.Parse(strWorkingDate);
        loadDays();
    }

    protected void rmCalendar_DayRender(object sender, DayRenderEventArgs e)
    {
        // Remove the default hyperlink for the day
        e.Day.IsSelectable = false;

        // Get the data from the 2D array for this day
        string strSessionsThisDay = strSessions[e.Day.Date.Month, e.Day.Date.Day];

        if (strSessionsThisDay != null)
        {
            TableCell td = e.Cell;
            string strCellText = "<br /> <a href='hourlyBarChart.aspx?strDate=" + e.Day.Date.ToShortDateString() + "'>Users: " + strSessionsThisDay + "</a>";
            LiteralControl lcCellControl = new LiteralControl(strCellText);
            td.Controls.Add(lcCellControl);
        }
    }

    protected void loadDays()
    {
        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlCommand sqlCmd;
        SqlDataReader sqlDR;

        // Set up SQL query parameters
        string strSQL;
        DateTime startDate;
        DateTime endDate;

        int utcOffset = int.Parse(Session["utcOffset"].ToString());

        // Start our query 7 days before the start of the month
        startDate = rmCalendar.VisibleDate.Subtract(new TimeSpan(7, 0, 0, 0));

        // End our query 45 days after the start date
        endDate = startDate.AddDays(45);

        // Format our select date as MM/DD/YYYY in the correct time zone
        string sessionDate = String.Format("CONVERT(VARCHAR, DATEADD(hh, {0}, SESSIONSTART), 101)", utcOffset);
        
        strSQL = String.Format("SELECT {0} AS sessionDate, COUNT(DISTINCT(FK_USERID)) AS sessionsStarted FROM SDB_SESSION WHERE SESSIONSTART BETWEEN '{1}' AND '{2}' GROUP BY {0}", sessionDate, startDate.ToShortDateString(), endDate.ToShortDateString());

        // Connect to the RM summary database specified in web.config
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        sqlConn.Open();

        try
        {
            // Execute the SQL command to retreive the data
            sqlCmd = new SqlCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            // Populate 2D array
            while (sqlDR.Read())
            {
                // Retrieve sessionDate from SQL query
                string strThisDay = sqlDR["sessionDate"].ToString();

                // Convert returned value to a DateTime so we can grab
                // the month and day parts
                DateTime dtThisDay = DateTime.Parse(strThisDay);

                // Get the month and day parts from the DateTime
                int intMonth = dtThisDay.Month;
                int intDay = dtThisDay.Day;

                // Set the 2D array at [month, day] to the number
                // of sessions started
                strSessions[intMonth, intDay] = sqlDR["sessionsStarted"].ToString();
            }
        }
        catch (Exception e)
        {
            Response.Write(e.Message);
            Response.Write("<br /> " + strSQL);
        }
        finally
        {
            sqlConn.Close();
        }
    }

    protected void rmCalendar_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
    {
        loadDays();
    }
}