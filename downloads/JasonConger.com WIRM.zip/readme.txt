Setup Instructions can be found in the Setup folder.

Change Log
====================================================
4/27/2006
Added <globalization requestEncoding="utf-8" responseEncoding="utf-8" culture="En-US" /> to Web.Config to force the application to run in the EN-US culture.  This was done for some Date/Time formatting issues.