//--------------------------------------------------
// Name: Web Interface Access Control Center
// Description: Contols and logs access to
// Citrix Web Interface
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
// Date:    April 3rd, 2006
//--------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class PerUserUsage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string strManagementGroup = ConfigurationManager.AppSettings["ManagementGroup"];

            if (User.IsInRole(strManagementGroup))
                btnManage.Visible = true;
            else
                btnManage.Visible = false;
        }

    }

    protected void lbUsers_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlHourDetail.SelectParameters["username"].DefaultValue = lbUsers.SelectedValue;
    }

    protected void btnBackToCalendar_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UsageCalendar.aspx");
    }

    protected void lbUsers_DataBound(object sender, EventArgs e)
    {
        lbUsers.SelectedIndex = 0;
        SqlHourDetail.SelectParameters["username"].DefaultValue = lbUsers.SelectedValue;
    }

    protected void btnManage_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Admin/ManageAccess.aspx");
    }
}
