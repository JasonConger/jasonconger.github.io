//--------------------------------------------------
// Name: Web Interface Access Control Center
// Description: Contols and logs access to
// Citrix Web Interface
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
// Date:    April 3rd, 2006
//--------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class DayDetail : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string strDate = Request.QueryString["d"];
            string strSuccess = Request.QueryString["s"];
            lblDate.Text = strDate;
            loadUserList(strDate, strSuccess);

            // Add drop down list items
            ddlSelect.Items.Add(new ListItem("Show all logins for " + strDate, null));
            ddlSelect.Items.Add(new ListItem("Show successful logins for " + strDate, "yes"));
            ddlSelect.Items.Add(new ListItem("Show denied logins for " + strDate, "no"));

            // Set selected item in drop down list
            switch (Request.QueryString["s"])
            {
                default:
                    ddlSelect.Items[0].Selected = true;
                    break;

                case "yes":
                    ddlSelect.Items[1].Selected = true;
                    break;

                case "no":
                    ddlSelect.Items[2].Selected = true;
                    break;
            }
        }
    }

    /// <summary>
    /// Sets SQL select parameters.
    /// </summary>
    /// <param name="strDate">Date</param>
    /// <param name="strSuccess">Successful or Denied login</param>
    protected void loadUserList(string strDate, string strSuccess)
    {
        string strStart = strDate + " 12:00:00 AM";
        string strEnd = strDate + " 11:59:59 PM";
        sqlUsers.SelectParameters[0].DefaultValue = strStart;
        sqlUsers.SelectParameters[1].DefaultValue = strEnd;
        sqlUsers.SelectParameters[2].DefaultValue = strSuccess;
    }

    protected void btnGoToCalendar_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UsageCalendar.aspx");
    }

    protected void ddlSelect_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strURL;

        switch (ddlSelect.SelectedValue)
        {
            case "yes":
                strURL = string.Format("~/DayDetail.aspx?d={0}&s=yes", Request.QueryString["d"]);
                break;
            case "no":
                strURL = string.Format("~/DayDetail.aspx?d={0}&s=no", Request.QueryString["d"]);
                break;
            default:
                strURL = "~/DayDetail.aspx?d=" + Request.QueryString["d"];
                break;
        }

        Response.Redirect(strURL);
    }
}
