//--------------------------------------------------
// Name: Web Interface Access Control Center
// Description: Contols and logs access to
// Citrix Web Interface
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
// Date:    April 3rd, 2006
//--------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class HourDetail : System.Web.UI.Page
{
    public string strDate;
    public string strHour;
    public string strSuccess;
    public string strUsername;

    protected void Page_Load(object sender, EventArgs e)
    {
        strDate = Request.QueryString["strDate"];
        strHour = Request.QueryString["strHour"];
        strSuccess = Request.QueryString["strSuccess"];
        strUsername = Server.HtmlDecode(Request.QueryString["strUsername"]);

        if (!IsPostBack)
        {
            lbUsers.SelectedValue = strUsername;

            // Get month, day, and year from passed date string
            int intMonth = Int16.Parse(strDate.Split('/')[0]);
            int intDay = Int16.Parse(strDate.Split('/')[1]);
            int intYear = Int16.Parse(strDate.Split('/')[2]);
            int intHour = Int16.Parse(strHour);
            DateTime dtDate = new DateTime(intYear, intMonth, intDay, intHour, 0, 0);
            lblHour.Text = strDate + " " + dtDate.ToShortTimeString();

            string strStart = string.Format("{0} {1}:00:00", strDate, strHour);
            string strEnd = string.Format("{0} {1}:59:59", strDate, strHour);

            SqlHourDetail.SelectParameters["start"].DefaultValue = strStart;
            SqlHourDetail.SelectParameters["end"].DefaultValue = strEnd;
            SqlHourDetail.SelectParameters["success"].DefaultValue = strSuccess;
            setSelectParam(strUsername);

            sqlUsers.SelectParameters["start"].DefaultValue = strStart;
            sqlUsers.SelectParameters["end"].DefaultValue = strEnd;
            sqlUsers.SelectParameters["success"].DefaultValue = strSuccess;

            // Add drop down list items
            ddlSelect.Items.Add(new ListItem("Show all logins for " + dtDate.ToString(), null));
            ddlSelect.Items.Add(new ListItem("Show successful logins for " + dtDate.ToString(), "yes"));
            ddlSelect.Items.Add(new ListItem("Show denied logins for " + dtDate.ToString(), "no"));

            // Set selected item in drop down list
            switch (strSuccess)
            {
                default:
                    ddlSelect.Items[0].Selected = true;
                    break;

                case "yes":
                    ddlSelect.Items[1].Selected = true;
                    break;

                case "no":
                    ddlSelect.Items[2].Selected = true;
                    break;
            }

        }
    }

    /// <summary>
    /// Determines whether to show all users or a specific user
    /// </summary>
    /// <param name="strVal">SQL select parameter</param>
    protected void setSelectParam(string strVal)
    {
        if (strVal != "(All Users)")
        {
            SqlHourDetail.SelectParameters["username"].DefaultValue = strVal;
        }
        else
        {
            SqlHourDetail.SelectParameters["username"].DefaultValue = null;
        }
    }

    protected void lbUsers_SelectedIndexChanged(object sender, EventArgs e)
    {
        setSelectParam(lbUsers.SelectedValue);
    }

    protected void btnGoToCalendar_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UsageCalendar.aspx");
    }

    protected void ddlSelect_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strURL;

        switch (ddlSelect.SelectedValue)
        {
            case "yes":
                strURL = string.Format("~/HourDetail.aspx?strDate={0}&strHour={1}&strUsername={2}&strSuccess=yes", strDate, strHour, strUsername);
                break;
            case "no":
                strURL = string.Format("~/HourDetail.aspx?strDate={0}&strHour={1}&strUsername={2}&strSuccess=no", strDate, strHour, strUsername);
                break;
            default:
                strURL = string.Format("~/HourDetail.aspx?strDate={0}&strHour={1}&strUsername={2}", strDate, strHour, strUsername);
                break;
        }

        Response.Redirect(strURL);

    }
}
