//--------------------------------------------------
// Name: Web Interface Access Control Center
// Description: Contols and logs access to
// Citrix Web Interface
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
// Date:    April 3rd, 2006
//--------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.DirectoryServices;
using System.Data.SqlClient;
using System.Collections;

public partial class ManageAccess : System.Web.UI.Page 
{
    private ArrayList strPermitedUsers;
    private ArrayList strRestrictedUsers;

    /// <summary>
    /// Default constructor
    /// </summary>
    public ManageAccess()
    {
        strPermitedUsers = getPermitedUsers();
        strRestrictedUsers = getRestrictedUsers();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string strManagementGroup = ConfigurationManager.AppSettings["ManagementGroup"];
        if (!User.IsInRole(strManagementGroup))
        {
            Response.Write("<b>Access Denied<b>");
            Response.End();
        }

        loadLB(strPermitedUsers, lbMembers);
        loadLB(strRestrictedUsers, lbNonMembers);
    }

    /// <summary>
    /// Gets all users in Active Directory that are
    /// not in the permitted list
    /// </summary>
    /// <returns>ArrayList of usernames</returns>
    protected ArrayList getRestrictedUsers()
    {
        ArrayList strADUsers = new ArrayList();

        try
        {
            DirectoryEntry entry = new DirectoryEntry(String.Format("LDAP://{0}", ConfigurationManager.AppSettings["LDAPDomain"]));
            DirectorySearcher mySearcher = new DirectorySearcher(entry);

            mySearcher.CacheResults = true;
            mySearcher.PropertiesToLoad.Add("sAMAccountName");

            string strSearchFilter = "(&(objectClass=user)(objectCategory=person)(!(userAccountControl:1.2.840.113556.1.4.803:=2))";
            // Note: (!(userAccountControl:1.2.840.113556.1.4.803:=2)) filters disabled user objects

            if (strPermitedUsers.Count > 0)
            {
                strSearchFilter += "(!(|";
                foreach (string strUser in strPermitedUsers)
                {
                    strSearchFilter += string.Format("(sAMAccountName={0})", strUser);
                }
                strSearchFilter += "))";
            }

            strSearchFilter += ")";
            mySearcher.Filter = strSearchFilter;
            SearchResultCollection sResultColl = mySearcher.FindAll();

            foreach (SearchResult resEnt in sResultColl)
            {
                try
                {
                    string strUsername = resEnt.Properties["sAMAccountName"][0].ToString();
                    strADUsers.Add(strUsername);
                }
                catch
                {
                }
            }

            strADUsers.Sort();
        }
        catch (Exception e)
        {
            strADUsers.Add(e.Message);
        }

        return strADUsers;
    }

    /// <summary>
    /// Gets a list of permitted users in the database
    /// </summary>
    /// <returns>ArrayList of permitted users</returns>
    protected ArrayList getPermitedUsers()
    {
        string sql = "SELECT username FROM WI_Include ORDER BY username";
        ArrayList strPermitedUsers = new ArrayList();
        
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlCommand sqlCmd = new SqlCommand(sql, conn);
        SqlDataReader sqlRdr;

        try
        {
            conn.Open();
            sqlRdr = sqlCmd.ExecuteReader();

            while (sqlRdr.Read())
            {
                string strUser = (string)sqlRdr["username"].ToString();
                strPermitedUsers.Add(strUser);
            }
        }
        catch (Exception e)
        {
            strPermitedUsers.Add(e.Message);
        }
        finally
        {
            conn.Close();
        }

        return strPermitedUsers;
    }

    /// <summary>
    /// Generic ListBox loader
    /// </summary>
    /// <param name="aList">ArrayList of values to populate the ListBox</param>
    /// <param name="lb">ListBox to be populated</param>
    protected void loadLB(ArrayList aList, ListBox lb)
    {
        foreach (string user in aList)
        {
            lb.Items.Add(user);
        }
    }

    /// <summary>
    /// Adds selected user(s) to the permitted database list
    /// </summary>
    protected void addUsers()
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        try
        {
            conn.Open();

            foreach (ListItem liItem in lbNonMembers.Items)
            {
                try
                {
                    if (liItem.Selected == true)
                    {
                        string sql = string.Format("INSERT INTO WI_Include (username) VALUES ('{0}')", liItem.Text);
                        SqlCommand sqlCmd = new SqlCommand(sql, conn);
                        sqlCmd.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    Response.Write(e.Message);
                }
            }
        }
        catch
        {
        }
        finally
        {
            conn.Close();
        }
        Server.Transfer("~/Admin/ManageAccess.aspx");
    }

    /// <summary>
    /// Removes selected user(s) to the permitted database list
    /// </summary>
    protected void removeUsers()
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        conn.Open();

        foreach (ListItem liItem in lbMembers.Items)
        {
            try
            {
                if (liItem.Selected == true)
                {
                    string sql = string.Format("DELETE FROM WI_Include WHERE username='{0}'", liItem.Text);
                    SqlCommand sqlCmd = new SqlCommand(sql, conn);
                    sqlCmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                Response.Write(e.Message);
            }
        }

        conn.Close();
        Server.Transfer("~/Admin/ManageAccess.aspx");

    }

    protected void btnAddUsers_Click(object sender, EventArgs e)
    {
        addUsers();
    }

    protected void btnRemoveUsers_Click(object sender, EventArgs e)
    {
        removeUsers();
    }

    protected void btnGoToCalendar_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UsageCalendar.aspx");
    }

    protected void btnGoToUsers_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UserDetail.aspx");
    }
}
