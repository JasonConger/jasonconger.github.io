//--------------------------------------------------
// Name: Web Interface Access Control Center
// Description: Contols and logs access to
// Citrix Web Interface
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
// Date:    April 3rd, 2006
//--------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class UsageCalendar : System.Web.UI.Page
{
    // 2D array to hold successfull logins
    private int[,] iSuccess = new int[13, 32];

    // 2D array to hold denied logins
    private int[,] iDenied = new int[13, 32];

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DateTime dtStart = calSGUsage.TodaysDate;
            loadDays(dtStart);

            string strManagementGroup = ConfigurationManager.AppSettings["ManagementGroup"];

            if (User.IsInRole(strManagementGroup))
                btnManage.Visible = true;
            else
                btnManage.Visible = false;
        }
    }

    protected void loadDays(DateTime dtDate)
    {
        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlCommand sqlCmd;
        SqlDataReader sqlDR;

        // Set up SQL query parameters
        string strSQL;
        DateTime startDate;
        DateTime endDate;
        DateTime tmpDate;

        string strMonth = dtDate.Month.ToString();
        string strYear = dtDate.Year.ToString();
        tmpDate = DateTime.Parse(strMonth + "/1/" + strYear);

        // Start our query 7 days before the start of the month
        startDate = tmpDate.Subtract(new TimeSpan(7, 0, 0, 0));

        // End our query 45 days after the start date
        endDate = startDate.AddDays(49);

        strSQL = String.Format("SELECT logintime, success FROM WI_AccessLog WHERE logintime BETWEEN '{0}' AND '{1}'", startDate.ToShortDateString(), endDate.ToShortDateString());

        // Connect to the external log database specified in web.config
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

        try
        {
            sqlConn.Open();
            // Execute the SQL command to retreive the data
            sqlCmd = new SqlCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            // Populate 2D arrays
            while (sqlDR.Read())
            {
                // Retrieve the login time from SQL query
                string strThisDay = sqlDR["logintime"].ToString();

                // Deterimine if this was a successfull login
                string strSuccess = sqlDR["success"].ToString();

                // Convert returned value to a DateTime so we can grab
                // the month and day parts
                DateTime dtThisDay = DateTime.Parse(strThisDay);

                // Get the month and day parts from the DateTime
                int intMonth = dtThisDay.Month;
                int intDay = dtThisDay.Day;

                // Set the 2D array at [month, day] to the number
                // of sessions started
                if (strSuccess.Trim() == "yes")
                {
                    iSuccess[intMonth, intDay]++;
                }
                if (strSuccess.Trim() == "no")
                {
                    iDenied[intMonth, intDay]++;
                }
            }
        }
        catch (Exception e)
        {
            //Response.Write(e.Message);
            lblError.Text += e.Message;
        }
        finally
        {
            sqlConn.Close();
        }
    }

    protected void calSGUsage_DayRender(object sender, DayRenderEventArgs e)
    {
        // Remove the default hyperlink for the day
        e.Day.IsSelectable = false;
        
        // Get the data from the 2D array for this day
        string strSuccess = iSuccess[e.Day.Date.Month, e.Day.Date.Day].ToString();
        string strDenied = iDenied[e.Day.Date.Month, e.Day.Date.Day].ToString();
        string strThisDay = Server.HtmlEncode(e.Day.Date.ToShortDateString());

        if (strSuccess != "0")
        {
            TableCell td = e.Cell;
            td.VerticalAlign = VerticalAlign.Top;
            string strCellText = string.Format("<br /><a href='DayDetail.aspx?d={0}&s=yes' class='date'>Success: {1}</a><br />", strThisDay, strSuccess);
            LiteralControl lcCellControl = new LiteralControl(strCellText);
            td.Controls.Add(lcCellControl);
        }

        if (strDenied != "0")
        {
            TableCell td = e.Cell;
            td.VerticalAlign = VerticalAlign.Top;
            string strCellText = string.Format("<a href='DayDetail.aspx?d={0}&s=no' class='date'>Denied: {1}</a>", strThisDay, strDenied);
            LiteralControl lcCellControl = new LiteralControl(strCellText);
            td.Controls.Add(lcCellControl);
        }
    }

    protected void calSGUsage_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
    {
        loadDays(e.NewDate);
    }

    protected void btnGoToUserData_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UserDetail.aspx");
    }

    protected void btnManage_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Admin/ManageAccess.aspx");
    }
}
