<%

// Modify the following line to reflect your database connection settings
string strConnString = "Data Source=massql;Initial Catalog=WI_Access;Persist Security Info=True;User ID=wi_access;Password=wi_access";

System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection();
conn.ConnectionString = strConnString;

bool boolAllowed = false;
string strUsername = String.Empty;
string clientIP = String.Empty;


// Retrieve the username of the current logged in user
strUsername = ((AccessToken)authGetPrimaryAccessToken()).getShortUserName();

// Work around to get real client IP address (http://www.thomaskoetzing.de/index.php?option=com_content&task=view&id=64&Itemid=103)
if (!(Request.ServerVariables["HTTP_X_FORWARDED_FOR"] == null) && (Request.ServerVariables["REMOTE_ADDR"] == "127.0.0.1")) 
{
    clientIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
}
else
{
    clientIP = Request.ServerVariables["REMOTE_ADDR"];
}


try
{
    conn.Open();
    string strSQL = string.Format("SELECT COUNT(username) FROM WI_Include WHERE username='{0}'", strUsername);
    System.Data.SqlClient.SqlCommand sqlCmd = new System.Data.SqlClient.SqlCommand(strSQL, conn);

    int numRows = (int)sqlCmd.ExecuteScalar();

    // If the user is not allowed to log in, log the access attempt in the database
    if(numRows < 1)
    {
        boolAllowed = false;
        string strSQLDenied = string.Format("INSERT INTO WI_AccessLog (username, logintime, remote_addr, success) VALUES ('{0}', '{1}', '{2}', '{3}')", strUsername, DateTime.Now.ToString(), clientIP, "no");
        System.Data.SqlClient.SqlCommand sqlCmdDenied = new System.Data.SqlClient.SqlCommand(strSQLDenied, conn);
        sqlCmdDenied.ExecuteNonQuery();
    }
    else
    {
        boolAllowed = true;
        string strSQLAllowed = string.Format("INSERT INTO WI_AccessLog (username, logintime, remote_addr, success) VALUES ('{0}', '{1}', '{2}', '{3}')", strUsername, DateTime.Now.ToString(), clientIP, "yes");
        System.Data.SqlClient.SqlCommand sqlCmdAllowed = new System.Data.SqlClient.SqlCommand(strSQLAllowed, conn);
        sqlCmdAllowed.ExecuteNonQuery();
    }
}

catch
{
}


finally
{
    conn.Close();
}


if(!boolAllowed)
{
    Server.Transfer("../auth/errorPage.html");
}

%>