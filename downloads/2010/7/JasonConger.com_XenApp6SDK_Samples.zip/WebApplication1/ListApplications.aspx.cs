﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;

using Citrix.Management.Automation;
using Citrix.XenApp.Sdk;
using Citrix.XenApp.Commands;


namespace WebApplication1
{
    public partial class ListApplications : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            litApplications.Text = String.Empty;
            string[] appSearh = new string[] { "*" };

            if (tbSearch.Text != String.Empty)
            {
                appSearh = tbSearch.Text.Split(',');
            }

            GetXAApplicationByName apps = new GetXAApplicationByName();
            
            apps.BrowserName = appSearh;
            

            foreach (PSObject _app in CitrixRunspaceFactory.DefaultRunspace.ExecuteCommand(apps))
            {
                XAApplication app = (XAApplication)_app.BaseObject;
                
                litApplications.Text += app.BrowserName;
                litApplications.Text += "<br />";
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

        }
    }
}
