﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Management.Automation;
using System.Management.Automation.Runspaces;

using Citrix.Management.Automation;
using Citrix.XenApp.Sdk;
using Citrix.XenApp.Commands;

namespace WebApplication1
{
    public partial class SessionManager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblUsername.Text = User.Identity.Name;

            if (!IsPostBack)
            {
                //getSessionsFor(User.Identity.Name);
                getAllSessions();
            }
        }

        private void getSessionsFor(string strUsername)
        {
            SessionDataSet dsSessions = new SessionDataSet();
            SessionDataSet.SessionsDataTable dtSessions = dsSessions.Sessions;

            GetXASessionByAccount sessions = new GetXASessionByAccount();
            sessions.Account = new[] { strUsername };

            foreach (PSObject _session in CitrixRunspaceFactory.DefaultRunspace.ExecuteCommand(sessions))
            {
                XASession session = (XASession)_session.BaseObject;

                SessionDataSet.SessionsRow row = dsSessions.Sessions.NewSessionsRow();

                row.clearSession = true;
                row.UserName = session.AccountName;
                row.Application = "";
                row.ClientName = session.ClientName;
                row.LogonTime = session.LogOnTime.ToString();
                row.ServerName = session.ServerName;
                row.SessionName = session.SessionName;
                row.SessionID = session.SessionId.ToString();
                row.SessionState = session.State.ToString();
                dtSessions.AddSessionsRow(row);

            }

            gvSessions.DataSource = dtSessions;
            gvSessions.DataBind();
        }

        private void getAllSessions()
        {
            SessionDataSet dsSessions = new SessionDataSet();
            SessionDataSet.SessionsDataTable dtSessions = dsSessions.Sessions;

            GetXASessionByFarm sessions = new GetXASessionByFarm();
            sessions.Farm = true;
            
            foreach (PSObject _session in CitrixRunspaceFactory.DefaultRunspace.ExecuteCommand(sessions))
            {
                XASession session = (XASession)_session.BaseObject;
                
                SessionDataSet.SessionsRow row = dsSessions.Sessions.NewSessionsRow();

                row.clearSession = true;
                row.UserName = session.AccountName;
                row.Application = "";
                row.ClientName = session.ClientName;
                row.LogonTime = session.LogOnTime.ToString();
                row.ServerName = session.ServerName;
                row.SessionName = session.SessionName;
                row.SessionID = session.SessionId.ToString();
                row.SessionState = session.State.ToString();
                dtSessions.AddSessionsRow(row);

            }

            gvSessions.DataSource = dtSessions;
            gvSessions.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            foreach(GridViewRow row in gvSessions.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    bool rowChecked = ((CheckBox)row.FindControl("chkSelect")).Checked;

                    if (rowChecked)
                    {
                        string server = row.Cells[2].Text;
                        int[] sessionID = new int[] {Int32.Parse(row.Cells[6].Text)};

                        StopXASessionByServerName stopSession = new StopXASessionByServerName(sessionID);
                        stopSession.ServerName = server;

                        CitrixRunspaceFactory.DefaultRunspace.ExecuteCommand(stopSession);
                    }
                }
            }

            Response.Redirect("~/SessionManager.aspx");
        }
    }
}
