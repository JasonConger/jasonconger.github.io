﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Management.Automation;
using System.Management.Automation.Runspaces;


namespace WebApplication1
{
    public partial class RunSpaceFactory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Runspace rs = RunspaceFactory.CreateRunspace();
            rs.Open();

            PowerShell ps = PowerShell.Create();
            ps.Runspace = rs;
            PSSnapInException ex;

            rs.RunspaceConfiguration.AddPSSnapIn("Citrix.XenApp.Commands", out ex);

            //ps.AddCommand("Get-XAApplication");
            ps.AddCommand("Get-XAApplication").AddParameter("BrowserName", "n*");

            foreach (PSObject app in ps.Invoke())
            {
                Response.Write(app.Properties["DisplayName"].Value);
                Response.Write("<br />");
            }

            rs.Close();
        }
    }
}
