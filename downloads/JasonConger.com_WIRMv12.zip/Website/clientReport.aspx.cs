//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class clientReport : System.Web.UI.Page
{
    public string strChartType = "FC2Pie3D.swf";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Master.Page.Form.DefaultButton = btnClientFilter.UniqueID;

            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Client Report";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";

            imgFrom.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbFrom.ClientID + "'), null, PickerParams, true)};");
            imgTo.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbTo.ClientID + "'), null, PickerParams, true)};");

            getExtremeDates();

            tbFrom.Text = ViewState["minDateExtreme"].ToString();
            tbTo.Text = ViewState["maxDateExtreme"].ToString();

            getData();
        }

        ClientScript.RegisterClientScriptBlock(this.GetType(), "calendarOption", getCalendarOptions());
    }

    protected string getChartData()
    {
        string strRetXML = String.Empty;

        // Setup XML for pie chart
        strRetXML = "<graph ";
        strRetXML += "Bgcolor='ffffff' ";
        strRetXML += "canvasbgcolor='ececec' ";
        strRetXML += "xaxisname='Client' ";
        strRetXML += "basefont='Verdana' ";
        strRetXML += "bastfontsize='12px' ";
        strRetXML += "outcnvbasefontsize='12px' ";
        strRetXML += "legendboxbgcolor='ececec' ";
        strRetXML += "legendboxbrdcolor='000000' ";
        strRetXML += "showValues='0' ";
        strRetXML += "decimalPrecision='0' ";
        strRetXML += "animation='0' ";

        // Set hover options
        strRetXML += "hovercapbg='f5f5f5' ";
        strRetXML += "hovercapborder='c0c0c0' ";
        strRetXML += "hovercapSepChar=' - frequency:' ";
        strRetXML += "showhovercap='1' ";
        strRetXML += ">";

        // Array to hold slice colors
        string[] colors = new string[10] { "9BBDDE", "FFBC46", "A2C488", "D6B9DB", "CDC785", "DEA19B", "B9DBCF", "FFDC46", "9B88C4", "85CD9B" };

        string strIsSliced = String.Empty;

        ClientsDataSet dsClients = (ClientsDataSet)ViewState["dsClients"];

        for (int i = 0; i < Int32.Parse(ddlTop.SelectedValue) && i < dsClients._Clients.Rows.Count; i++)
        {
            ClientsDataSet.ClientsRow row = dsClients._Clients[i];

            string strClientName;
            strClientName = row.CLIENT_NAME.Replace("ICA ", String.Empty) + " ";

            if (row.VERSION.Trim() == String.Empty)
            {
                strClientName += " No Version (Build: " + row.BUILD + ")";
            }
            else
            {
                strClientName += row.VERSION;
            }

            string strClientFreq = row.FREQ.ToString();

            if (i == 0)
                strIsSliced = "isSliced='1'";
            else
                strIsSliced = String.Empty;

            strRetXML += String.Format("<set value='{0}' name='{1}' color='{2}' {3} />", strClientFreq, strClientName, colors[i], strIsSliced);
        }

        strRetXML += "</graph>";

        return strRetXML;
    }

    protected void btnPieChart_Click(object sender, EventArgs e)
    {
        this.imgGraph.ImageUrl = "~/images/pieGraphIcon.gif";
        this.strChartType = "FC2Pie3D.swf";
    }

    protected void btnColumnChart_Click(object sender, EventArgs e)
    {
        this.imgGraph.ImageUrl = "~/images/columnGraphIcon.gif";
        this.strChartType = "FC2Column.swf";
    }

    protected void gvClients_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        e.Row.Cells[5].Visible = false;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string strClientVersion = e.Row.Cells[1].Text;
            string strClientBuild = e.Row.Cells[2].Text;
            string strClientTypeId = e.Row.Cells[5].Text;

            string strClientName = e.Row.Cells[0].Text + " ";
            
            if (e.Row.Cells[1].Text.Trim() == String.Empty)
            {
                strClientName += " No Version (Build: " + e.Row.Cells[2].Text + ")";
            }
            else
            {
                strClientName += e.Row.Cells[1].Text;
            }

            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this);");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            //e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", gvHourDetail.DataKeys[e.Row.RowIndex].Value.ToString()));
            ImageButton btnPerson = (ImageButton)e.Row.Cells[4].FindControl("btnPerson");
            btnPerson.ToolTip = String.Format("Show all users that have used the {0} client.", strClientName.Replace("ICA ", String.Empty));
            btnPerson.PostBackUrl = String.Format("clientsByUser.aspx?c={0}&v={1}&b={2}", strClientTypeId, strClientVersion, strClientBuild);
        }
    }

    protected void getExtremeDates()
    {
        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlDataReader sqlDR;
        SqlCommand sqlCmd;
        string strSQL = String.Empty;

        // Connect to the RM summary database
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        sqlConn.Open();

        try
        {
            strSQL = "SELECT MAX(STARTTIME) AS MAX_DATE, MIN(STARTTIME) AS MIN_DATE FROM SDB_CLIENTHISTORY";
            sqlCmd = new SqlCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            sqlDR.Read();
            
            ViewState["maxDateExtreme"] = DateTime.Parse(sqlDR["MAX_DATE"].ToString()).ToString("dd-MMM-yyyy");
            ViewState["minDateExtreme"] = DateTime.Parse(sqlDR["MIN_DATE"].ToString()).ToString("dd-MMM-yyyy");
        }
        catch
        {
            ViewState["minDateExtreme"] = String.Empty;
            ViewState["maxDateExtreme"] = String.Empty;
        }
        finally
        {
            sqlConn.Close();
        }
    }

    protected string getCalendarOptions()
    {
        string calOptions = String.Empty;

        calOptions += "<script type=\"text/javascript\"> ";
        //calOptions += "<!-- ";
        calOptions += "var PickerParams = {";
        calOptions += "onClientDayRender:\"\",";
        calOptions += "onClientBeforeCalendarOpen:\"\",";
        calOptions += "onClientBeforeCalendarClose:\"\",";
        calOptions += "onClientAfterCalendarOpen:\"\",";
        calOptions += "onClientBeforeSelectionChanged:\"\",";
        calOptions += "onClientAfterSelectionChanged:\"updateLabel\",";
        calOptions += "onClientBeforeVisibleMonthChanged:\"\",";
        calOptions += "onClientAfterVisibleMonthChanged:\"\",";
        calOptions += "enabled:true,";
        calOptions += "autoPostBack:false,";
        calOptions += "selectableWeekDays:true,";
        calOptions += "selectableWeekendDays:true,";
        calOptions += "selectablePrevMonthDays:true,";
        calOptions += "selectableNextMonthDays:true,";
        
        DateTime maxDate = DateTime.Parse(ViewState["maxDateExtreme"].ToString());
        int maxYear = maxDate.Year;
        int maxMonth = maxDate.Month - 1;
        int maxDay = maxDate.Day;
        string strMaxDate = String.Format("{0}, {1}, {2}", maxYear, maxMonth, maxDay);

        calOptions += "maximumDate:new Date(" + strMaxDate + "),";

        DateTime minDate = DateTime.Parse(ViewState["minDateExtreme"].ToString());
        int minYear = minDate.Year;
        int minMonth = minDate.Month - 1;
        int minDay = minDate.Day;
        string strMinDate = String.Format("{0}, {1}, {2}", minYear, minMonth, minDay);

        calOptions += "minimumDate:new Date(" + strMinDate + "),";
        calOptions += "twoDigitYearBreak:50,";
        calOptions += "openCalendarOnTextBoxFocus:false,";
        calOptions += "monthSelectorEnabled:true,";
        calOptions += "yearSelectorEnabled:true,";
        calOptions += "rows:1,";
        calOptions += "columns:1,";
        calOptions += "dayStatusBarText:\"{0}\",";
        calOptions += "nullDateText:\"\",";
        calOptions += "xOffset:0,";
        calOptions += "yOffset:1,";
        calOptions += "resourcePath:\"clientScripts\",";
        calOptions += "nextPrevMonthImageWidth:\"5px\",";
        calOptions += "nextPrevMonthImageHeight:\"9px\",";
        calOptions += "nextMonthText:\"&gt;\",";
        calOptions += "prevMonthText:\"&lt;\",";
        calOptions += "showWeekNumbers:false,";
        calOptions += "showDaysInNextMonth:true,";
        calOptions += "showDaysInPrevMonth:true,";
        calOptions += "showTodayButton:true,";
        calOptions += "todayButtonText:\"Today\",";
        calOptions += "showNoneButton:false,";
        calOptions += "noneButtonText:\"None\",";
        calOptions += "footNoteText:\"\",";
        calOptions += "forceSixRows:true,";
        calOptions += "firstDayOfWeek:7,";
        calOptions += "dayNameFormat:\"FirstLetter\",";
        calOptions += "datePickerDisplayType:\"TextBoxAndImage\",";
        calOptions += "buttonText:\"Calendar\",";
        calOptions += "nextPrevFormat:\"Image\",";
        calOptions += "showDayHeader:true,";
        calOptions += "showNextPrevMonth:true,";
        calOptions += "showTitle:true,";
        calOptions += "downYearSelectorImageFileName:\"arrow_down.gif\",";
        calOptions += "upDownYearSelectorImageWidth:9,";
        calOptions += "upDownYearSelectorImageHeight:5,";
        calOptions += "upYearSelectorText:\"+\",";
        calOptions += "downYearSelectorText:\"-\",";
        calOptions += "upDownYearSelectorFormat:\"Image\",";
        calOptions += "monthSelectorXOffset:-11,";
        calOptions += "monthSelectorYOffset:2,";
        calOptions += "yearSelectorXOffset:-11,";
        calOptions += "yearSelectorYOffset:2,";
        calOptions += "visibleDate:null,";
        calOptions += "dateOrder:\"mdy\",";
        calOptions += "popUpStyle:\"\",";
        calOptions += "popUpStyleCssClass:\"bdpPopUp\",";
        calOptions += "calendarStyle:\"\",";
        calOptions += "calendarStyleCssClass:\"bdpCalendar\",";
        calOptions += "noneButtonStyle:\"\",";
        calOptions += "noneButtonStyleCssClass:\"bdpClearButton\",";
        calOptions += "todayButtonStyle:\"\",";
        calOptions += "todayButtonStyleCssClass:\"bdpTodayButton\",";
        calOptions += "titleStyle:\"\",";
        calOptions += "titleStyleCssClass:\"bdpTitle\",";
        calOptions += "nextPrevStyle:\"\",";
        calOptions += "nextPrevStyleCssClass:\"bdpNextPrev\",";
        calOptions += "dayHeaderStyle:\"\",";
        calOptions += "dayHeaderStyleCssClass:\"bdpDayHeader\",";
        calOptions += "dayStyle:\"\",";
        calOptions += "dayStyleCssClass:\"bdpDay\",";
        calOptions += "otherMonthDayStyle:\"\",";
        calOptions += "otherMonthDayStyleCssClass:\"bdpOtherMonthDay bdpDay\",";
        calOptions += "weekendDayStyle:\"\",";
        calOptions += "weekendDayStyleCssClass:\"bdpWeekendDay bdpDay\",";
        calOptions += "selectedDayStyle:\"\",";
        calOptions += "selectedDayStyleCssClass:\"bdpSelectedDay bdpDay\",";
        calOptions += "todayDayStyle:\"\",";
        calOptions += "todayDayStyleCssClass:\"bdpTodayDay bdpDay\",";
        calOptions += "footerStyle:\"\",";
        calOptions += "footerStyleCssClass:\"bdpFooter\",";
        calOptions += "footNoteStyle:\"\",";
        calOptions += "footNoteStyleCssClass:\"bdpFootNote\",";
        calOptions += "weekNumberStyle:\"\",";
        calOptions += "weekNumberStyleCssClass:\"bdpWeekNumber\",";
        calOptions += "otherMonthDayWeekendDayStyle:\"\",";
        calOptions += "otherMonthDayWeekendDayStyleCssClass:\"bdpOtherMonthDay bdpDay bdpWeekendDay bdpDay bdpDay\",";
        calOptions += "selectedDayTodayDayStyle:\"\",";
        calOptions += "selectedDayTodayDayStyleCssClass:\"bdpTodayDay bdpDay bdpSelectedDay bdpDay bdpDay\",";
        calOptions += "selectedDayWeekendDayStyle:\"\",";
        calOptions += "selectedDayWeekendDayStyleCssClass:\"bdpSelectedDay bdpDay bdpWeekendDay bdpDay bdpDay\",";
        calOptions += "todayDayWeekendDayStyle:\"\",";
        calOptions += "todayDayWeekendDayStyleCssClass:\"bdpTodayDay bdpDay bdpWeekendDay bdpDay bdpDay\",";
        calOptions += "timePicker:\"\",";
        calOptions += "postBackFunction:\"\",";
        calOptions += "dateFormat:\"d-MMM-yyyy\",";
        calOptions += "culture:\"basicDatePickerCulture_en_US\",";
        calOptions += "nextMonthImageUrl:\"images/calendar/arrow_right.gif\",";
        calOptions += "prevMonthImageUrl:\"images/calendar/arrow_left.gif\",";
        calOptions += "upYearSelectorImageUrl:\"images/calendar/arrow_up.gif\",";
        calOptions += "downYearSelectorImageUrl:\"images/calendar/arrow_down.gif\",";
        calOptions += "specialDates:\"\"};";
        //calOptions += " //-->";
        calOptions += "</script>";

        return calOptions;
    }

    protected void getData()
    {
        string strFrom = tbFrom.Text;
        string strTo = tbTo.Text;
        if (strFrom == strTo)
        {
            if (!strFrom.Contains(":"))
            {
                strFrom += " 00:00:00";
                strTo += " 23:59:59";
            }
        }
        ClientsDataSet dsClients = new ClientsDataSet();
        ClientsDataSetTableAdapters.ClientsTableAdapter da = new ClientsDataSetTableAdapters.ClientsTableAdapter();

        try
        {
            da.Fill(dsClients._Clients, DateTime.Parse(strFrom), DateTime.Parse(strTo));    
        }
        catch
        {
        }

        ViewState["dsClients"] = dsClients;

        gvClients.DataSource = dsClients._Clients;
        gvClients.DataBind();
        
    }

    protected void btnClientFilter_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            getData();
        }
    }

    // Sorting Helper
    protected void gvClients_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExpression = e.SortExpression;
        if (gvSortDirection == SortDirection.Ascending)
        {
            gvSortDirection = SortDirection.Descending;
            SortGridView(sortExpression, " DESC");
        }
        else
        {
            gvSortDirection = SortDirection.Ascending;
            SortGridView(sortExpression, " ASC");
        }
    }

    public SortDirection gvSortDirection
    {
        get
        {
            if (ViewState["sortDirection"] == null)
                ViewState["sortDirection"] = SortDirection.Ascending;

            return (SortDirection)ViewState["sortDirection"];
        }

        set { ViewState["sortDirection"] = value; }
    }

    private void SortGridView(string sortExpression, string direction)
    {
        ClientsDataSet dsClients = (ClientsDataSet)ViewState["dsClients"];
        DataTable dt = dsClients._Clients;
        DataView dv = new DataView(dt);
        dv.Sort = sortExpression + direction;
        gvClients.DataSource = dv;
        gvClients.DataBind();
    }
    
    // Custom Validators
    protected void cvFromDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbFrom.Text);
    }

    protected void cvToDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbTo.Text);
    }

    protected void cvDateCompare_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (cvFromDate.IsValid && cvToDate.IsValid)
        {
            if (DateTime.Parse(tbFrom.Text) > DateTime.Parse(tbTo.Text))
                args.IsValid = false;
        }
    }

    // Custom Validator Helper
    protected bool checkDateTime(string strDateTime)
    {
        try
        {
            DateTime.Parse(strDateTime);
            return true;
        }
        catch
        {
            return false;
        }
    }

    
}
