//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class sessionDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Session Detail";

            Page.Title = "Web Interface for Resource Manager - Session Detail";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/sessionDetail.gif";
        }
    }

    protected void gvProcessDetail_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        e.Row.Cells[4].Visible = false;
        e.Row.Cells[5].Visible = false;
        e.Row.Cells[6].Visible = false;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string strProcessName = e.Row.Cells[0].Text;
            string strProcessMemory = e.Row.Cells[3].Text;
            string strVersion = e.Row.Cells[4].Text;
            string strProductDate = e.Row.Cells[5].Text;
            string strPath = e.Row.Cells[6].Text.Replace("\\", "\\\\");

            string strMouseOver = string.Format("stm(['{0}','Version: {1} <br /> Date: {2} <br /> Path: {3}'],Style[0])",strProcessName, strVersion, strProductDate, strPath);

            e.Row.Cells[0].Attributes.Add("style", "cursor: help");
            e.Row.Cells[0].Attributes.Add("onMouseOver", strMouseOver);
            e.Row.Cells[0].Attributes.Add("onMouseOut", "htm()");

            e.Row.Cells[3].Text = getMemory(double.Parse(strProcessMemory));
        }
    }

    protected void fvSessionDetail_DataBound(object sender, EventArgs e)
    {
        Label lblDuration = (Label)fvSessionDetail.FindControl("DURATIONLabel");
        Label lblActiveTime = (Label)fvSessionDetail.FindControl("ACTIVETIMESUMLabel");
        Label lblCPUTime = (Label)fvSessionDetail.FindControl("CPUTIMESUMLabel");
        Label lblMemoryUsed = (Label)fvSessionDetail.FindControl("MEMORYSUMLabel");
        Label lblUsingSG = (Label)fvSessionDetail.FindControl("USINGSGLabel");

        try { lblDuration.Text = getTimeSpan(double.Parse(lblDuration.Text)); }
        catch { lblDuration.Text = String.Empty; }

        try { lblActiveTime.Text = getTimeSpan(double.Parse(lblActiveTime.Text)); }
        catch { lblActiveTime.Text = String.Empty; }

        try { lblCPUTime.Text = getTimeSpan(double.Parse(lblCPUTime.Text)); }
        catch { lblCPUTime.Text = String.Empty; }

        try { lblMemoryUsed.Text = getMemory(double.Parse(lblMemoryUsed.Text)); }
        catch { lblMemoryUsed.Text = String.Empty; }

        if(lblUsingSG.Text == "1")
            lblUsingSG.Text = " &nbsp (via Secure Gateway)";
        else
            lblUsingSG.Text = String.Empty;
    }

    public string getTimeSpan(double milliseconds)
    {
        // Note: 1 tick = 100 nanoseconds
        // 1 millisecond = 1,000,000 nanoseconds
        
        long ticks = (long)Math.Round(milliseconds * 10000);

        string strTimeSpan = "";

        TimeSpan ts = new TimeSpan(ticks);
        int intSeconds = ts.Seconds;
        int intMinutes = ts.Minutes;
        int intHours = ts.Hours;
        int intDays = ts.Days;

        if(intDays > 0)
            strTimeSpan += intDays.ToString() + " days ";

        if (intHours == 1)
            strTimeSpan += intHours.ToString() + " hour ";
        else
            strTimeSpan += intHours.ToString() + " hours ";

        strTimeSpan += intMinutes.ToString() + " minutes ";
        strTimeSpan += intSeconds.ToString() + " seconds ";

        return strTimeSpan;
    }

    public string getMemory(double megabytes)
    {
        string strMemory = "";

        // If Megabytes < 1, return Kilobytes
        if (megabytes < 1)
        {
            double KB = Math.Round((megabytes * 1024), 2);
            strMemory = KB.ToString() + " Kb";
        }
        
        // If Megabytes > 1024 (1 GB), rerutn Gigabytes
        if(megabytes > 1024)
        {
            double GB = Math.Round((megabytes / 1024), 2);
            strMemory = GB.ToString() + " GB";
        }

        // If Megabytes > 1 AND < 1024, return Megabytes
        if ((megabytes > 1) && (megabytes < 1024))
        {
            double MB = Math.Round(megabytes, 2);
            strMemory = MB.ToString() + " MB";
        }

        return strMemory;
    }
}
