//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class clientsByUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Clients By User";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";

        }

        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        sqlClientsByUser.SelectParameters["utcOffset"].DefaultValue = Session["utcOffset"].ToString();
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
            e.Row.Cells[3].Visible = false;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[3].Visible = false;
            string strSessionID = e.Row.Cells[3].Text;
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='pointer';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", "Click to view session details . . .");
            e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", strSessionID));
        }
    }
}
