//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page 
{
    public struct dayDetail
    {
        public string strDate;
        public int intSessionCount;
        public int intApplicationCount;
    }

    public System.Collections.Hashtable dayDetails =
        new System.Collections.Hashtable();

    protected void Page_Load(object sender, EventArgs e)
    {
        // Set a session variable for the UTC offset.
        // Note that a UTC offset specified in web.config takes precedence
        if (Session["utcOffset"] == null)
        {
            // Get UTC offset (if any) from web.config
            string strAppSettingUTCOffset = ConfigurationManager.AppSettings["TimeZoneUTCOffset"];
            string strClientUTCOffset = Request["clientUTCOffset"];

            if (strClientUTCOffset.Trim() == String.Empty)
                Response.Redirect("Default.aspx");

            if (strAppSettingUTCOffset.Trim() != string.Empty)
                Session["utcOffset"] = strAppSettingUTCOffset;
            else
                Session["utcOffset"] = strClientUTCOffset;

            Session.Timeout = 480;
        }
        
        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Usage Calendar";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/calendar.gif";

            // Set our view date to the first day of the current month.
            string strMonth = DateTime.Now.Month.ToString();
            string strDay = "1";
            string strYear = DateTime.Now.Year.ToString();
            string strWorkingDate = strMonth + "/" + strDay + "/" + strYear;
            rmCalendar.VisibleDate = DateTime.Parse(strWorkingDate);

            initialApplicationFilterDDL();
            loadDays();
        }
    }

    protected void rmCalendar_DayRender(object sender, DayRenderEventArgs e)
    {
        // Remove the default hyperlink for the day
        e.Day.IsSelectable = false;

        string strThisDay = e.Day.Date.ToShortDateString();

        if (dayDetails.ContainsKey(strThisDay))
        {
            dayDetail thisDay = (dayDetail)dayDetails[strThisDay];
            TableCell td = e.Cell;
            string strCellText = String.Format("<br /> <a href='hourlyBarChart.aspx?strDate={0}' class='sessionLink'>Users: {1}</a>", thisDay.strDate, thisDay.intSessionCount.ToString());

            if (ddlApplicationFilter.SelectedIndex != 0)
            {
                if(thisDay.intApplicationCount != 0)
                    strCellText += String.Format("<br /><br /> <a href='hourlyBarChart.aspx?strDate={0}&strAppID={1}&strAppName={2}' class='appLink'>{2}: {3}</a>", thisDay.strDate, ddlApplicationFilter.SelectedValue, ddlApplicationFilter.SelectedItem, thisDay.intApplicationCount.ToString());
            }

            LiteralControl lcCellControl = new LiteralControl(strCellText);
            td.Controls.Add(lcCellControl);
        }
        
    }

    protected void loadDays()
    {
        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlCommand sqlCmd;
        SqlDataReader sqlDR;

        // Set up SQL query parameters
        string strSQL;
        DateTime startDate;
        DateTime endDate;

        float utcOffset = float.Parse(Session["utcOffset"].ToString());

        // Start our query 7 days before the start of the month
        startDate = rmCalendar.VisibleDate.Subtract(new TimeSpan(7, 0, 0, 0));

        // End our query 45 days after the start date
        endDate = startDate.AddDays(45);

        // Set application filter drop down list sql paramters
        sqlApplicationFilter.SelectParameters["sessionStart"].DefaultValue = startDate.ToShortDateString();
        sqlApplicationFilter.SelectParameters["sessionEnd"].DefaultValue = endDate.ToShortDateString();

        // Format our select date as MM/DD/YYYY in the correct time zone
        string sessionDate = String.Format("CONVERT(VARCHAR, DATEADD(hh, {0}, SESSIONSTART), 101)", utcOffset);

        strSQL = String.Format("SELECT {0} AS sessionDate, COUNT(DISTINCT(FK_USERID)) AS sessionsStarted FROM SDB_SESSION WHERE SESSIONSTART BETWEEN '{1}' AND '{2}' GROUP BY {0}", sessionDate, startDate.ToShortDateString(), endDate.ToShortDateString());
       
        // Connect to the RM summary database specified in web.config
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        sqlConn.Open();

        try
        {
            // Execute the SQL command to retreive the data
            sqlCmd = new SqlCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            // Populate Hash Table
            while (sqlDR.Read())
            {
                // Retrieve sessionDate from SQL query
                string strThisDay = DateTime.Parse(sqlDR["sessionDate"].ToString()).ToShortDateString();

                // Create new datDetail struct and add to hash table
                dayDetail thisDay = new dayDetail();
                thisDay.strDate = strThisDay;
                thisDay.intSessionCount = int.Parse(sqlDR["sessionsStarted"].ToString());

                dayDetails.Add(strThisDay, thisDay);
            }

            sqlDR.Dispose();
            sqlCmd.Dispose();



            // populate application counts on the dayDetail structs
            if (ddlApplicationFilter.SelectedIndex != 0)
            {
                string strSQLApps = String.Format("SELECT {0} AS sessionDate, COUNT(FK_APPNAMEID) AS appCount FROM SDB_SESSION WHERE (SESSIONSTART BETWEEN '{1}' AND '{2}') AND SDB_SESSION.FK_APPNAMEID = '{3}' GROUP BY {0}", sessionDate, startDate.ToShortDateString(), endDate.ToShortDateString(), ddlApplicationFilter.SelectedValue);

                sqlCmd = new SqlCommand(strSQLApps, sqlConn);
                sqlDR = sqlCmd.ExecuteReader();

                // Modify the Hash Table
                while (sqlDR.Read())
                {
                    // Retrieve sessionDate from SQL query
                    string strThisDay = DateTime.Parse(sqlDR["sessionDate"].ToString()).ToShortDateString();

                    // get the struct for this day
                    dayDetail thisDay = (dayDetail)dayDetails[strThisDay];

                    thisDay.intApplicationCount = int.Parse(sqlDR["appCount"].ToString());

                    dayDetails[strThisDay] = thisDay;
                }

                sqlDR.Dispose();
                sqlCmd.Dispose();
            }
        }
        catch (Exception e)
        {
            Response.Write(e.Message);
            Response.Write("<br /> " + strSQL);
        }
        finally
        {
            sqlConn.Close();
        }
    }

    protected void rmCalendar_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
    {
        initialApplicationFilterDDL();
        loadDays();
    }

    protected void initialApplicationFilterDDL()
    {
        ddlApplicationFilter.Items.Clear();
        ddlApplicationFilter.Items.Add("Select Application");
    }

    protected void validateAppFilter_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (ddlApplicationFilter.SelectedIndex == 0)
            args.IsValid = false;
    }

    protected void btnApplicationFilter_Click(object sender, EventArgs e)
    {
        loadDays();
    }
}