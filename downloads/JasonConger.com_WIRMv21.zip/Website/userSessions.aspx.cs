//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class userDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
                Resources.WIRM.UserSessionDetail;

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += String.Format(" - {0} {1}.", Resources.WIRM.SessionsStartedBy, Request["strUsername"]);

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";
        }

        getData();
    }

    protected void gvUserDetail_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='pointer';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", Resources.WIRM.ClickToViewSessionDetails);
            e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", gvUserDetail.DataKeys[e.Row.RowIndex].Value.ToString()));
        }
    }

    protected void getData()
    {
        float utcOffset = float.Parse(Session["utcOffset"].ToString());

        string strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;

        switch (strProvider)
        {
            case "System.Data.OracleClient":
                sqlUserDetail.ProviderName = strProvider;
                sqlUserDetail.SelectCommand = String.Format("SELECT LU_USER.USERNAME, SDB_SESSION.SESSIONSTART + ({0}/24) AS SESSIONSTART, SDB_SESSION.SESSIONEND + ({0}/24) AS SESSIONEND, LU_APPNAME.APPNAME, SDB_SESSION.PK_SDB_SESSIONID FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID INNER JOIN LU_APPNAME ON SDB_SESSION.FK_APPNAMEID = LU_APPNAME.PK_APPNAMEID WHERE (LU_USER.PK_USERID = {1}) ORDER BY SDB_SESSION.SESSIONSTART DESC", utcOffset, Int32.Parse(Request.QueryString["userID"]));
                break;
            default:
                sqlUserDetail.SelectCommand = String.Format("SELECT LU_USER.USERNAME, DATEADD(hh, {0}, SDB_SESSION.SESSIONSTART) AS SESSIONSTART, DATEADD(hh, {0}, SDB_SESSION.SESSIONEND) AS SESSIONEND, LU_APPNAME.APPNAME, SDB_SESSION.PK_SDB_SESSIONID FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID INNER JOIN LU_APPNAME ON SDB_SESSION.FK_APPNAMEID = LU_APPNAME.PK_APPNAMEID WHERE (LU_USER.PK_USERID = '{1}') ORDER BY SDB_SESSION.SESSIONSTART DESC", utcOffset, Request.QueryString["userID"]);
                break;
        }

        gvUserDetail.DataBind();

    }
}
