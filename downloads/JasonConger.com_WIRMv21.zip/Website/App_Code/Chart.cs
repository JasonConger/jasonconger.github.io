//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for getGraph
/// </summary>
public class Chart
{
    // Array to hold slice colors
    private string[] colors;

	public Chart()
	{
        this.colors = new string[10] { "9BBDDE", "FFBC46", "A2C488", "D6B9DB", "CDC785", "DEA19B", "B9DBCF", "FFDC46", "9B88C4", "85CD9B" };
	}

    public string getApplicationXML(DataView dv, int numResults)
    {
        string strHoverText = String.Empty;

        if (dv.Table.Columns.Contains("mx"))
        {
            // Concurrent usage table
            strHoverText = "' - " + Resources.WIRM.ConcurrentUsers + ":' ";
        }
        else
        {
            strHoverText = "' - " + Resources.WIRM.Frequency.ToLower() + ":' ";
        }

        string strRetXML = String.Empty;

        // Setup XML for pie chart
        strRetXML = "<graph ";
        strRetXML += "Bgcolor='ffffff' ";
        strRetXML += "canvasbgcolor='ececec' ";
        strRetXML += "xaxisname='" + Resources.WIRM.Application + "' ";
        strRetXML += "basefont='Verdana' ";
        strRetXML += "bastfontsize='12px' ";
        strRetXML += "outcnvbasefontsize='12px' ";
        strRetXML += "legendboxbgcolor='ececec' ";
        strRetXML += "legendboxbrdcolor='000000' ";
        strRetXML += "showValues='0' ";
        strRetXML += "decimalPrecision='0' ";
        strRetXML += "animation='0' ";

        // Set hover options
        strRetXML += "hovercapbg='f5f5f5' ";
        strRetXML += "hovercapborder='c0c0c0' ";
        strRetXML += "hovercapSepChar=" + strHoverText;
        strRetXML += "showhovercap='1' ";
        strRetXML += ">";

        string strIsSliced = String.Empty;

        for (int i = 0; i < numResults && i < dv.Table.Rows.Count; i++)
        {

            if (i == 0)
                strIsSliced = "isSliced='1'";
            else
                strIsSliced = String.Empty;

            strRetXML += String.Format("<set value='{0}' name='{1}' color='{2}' {3} />", dv[i][1], dv[i][0], this.colors[i], strIsSliced);
        }


        strRetXML += "</graph>";

        return strRetXML;
    }

    public static void loadChartDDL(DropDownList ddl)
    {
        ddl.Items.Add(new ListItem(Resources.WIRM.PieChart, "FC2Pie3D.swf"));
        ddl.Items.Add(new ListItem(Resources.WIRM.ColumnChart, "FC2Column.swf"));
        ddl.Items.Add(new ListItem(Resources.WIRM.PipeChart, "FC2Pipe.swf"));
        ddl.Items.Add(new ListItem(Resources.WIRM.AreaChart, "FC2Area3D.swf"));
    }

}
