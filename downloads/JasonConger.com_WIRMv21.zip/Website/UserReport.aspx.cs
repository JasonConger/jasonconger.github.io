//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class userreport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
                Resources.WIRM.UserReport;

        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.UserReport;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";
        }

        getData();
    }

    protected void getData()
    {
        float utcOffset = float.Parse(Session["utcOffset"].ToString());
        string strUsername;
        if (tbUsername.Text.Trim() == String.Empty)
            strUsername = "NULL";
        else
            strUsername = String.Format("'{0}%'",tbUsername.Text.Trim().ToUpper());

        string strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;

        switch (strProvider)
        {
            case "System.Data.OracleClient":
                sqlUsers.ProviderName = strProvider;
                sqlUsers.SelectCommand = String.Format("SELECT MAX(SDB_SESSION.SESSIONSTART + ({0}/24)) AS sessionstart, LU_USER.USERNAME, LU_USER.PK_USERID, LU_NETDOMAIN.NETDOMAIN FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID INNER JOIN LU_NETDOMAIN ON LU_USER.FK_NETDOMAINID = LU_NETDOMAIN.PK_NETDOMAINID WHERE (LU_USER.USERNAME LIKE NVL({1}, LU_USER.USERNAME)) GROUP BY LU_USER.USERNAME, LU_USER.PK_USERID, LU_NETDOMAIN.NETDOMAIN ORDER BY LU_USER.USERNAME", utcOffset, strUsername);
                break;
            default:
                sqlUsers.SelectCommand = String.Format("SELECT MAX(DATEADD(hh, {0}, SDB_SESSION.SESSIONSTART)) AS sessionstart, LU_USER.USERNAME, LU_USER.PK_USERID, LU_NETDOMAIN.NETDOMAIN FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID INNER JOIN LU_NETDOMAIN ON LU_USER.FK_NETDOMAINID = LU_NETDOMAIN.PK_NETDOMAINID WHERE (LU_USER.USERNAME LIKE ISNULL({1}, LU_USER.USERNAME)) GROUP BY LU_USER.USERNAME, LU_USER.PK_USERID, LU_NETDOMAIN.NETDOMAIN ORDER BY LU_USER.USERNAME", utcOffset, strUsername);
                break;
        }

        gvUsers.DataBind();
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        tbUsername.Text = String.Empty;
        getData();
    }

    protected void gvUsers_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='pointer';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", String.Format("{0} {1}\\{2} . . .", Resources.WIRM.ClickToViewAllSessions, e.Row.Cells[0].Text, e.Row.Cells[1].Text));
            e.Row.Attributes.Add("onClick", String.Format("location.href='userSessions.aspx?userID={0}&strUsername={1}'", gvUsers.DataKeys[e.Row.RowIndex].Value.ToString(), e.Row.Cells[1].Text));
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        getData();
    }
}
