De installatie handleiding staat in de "Setup" map.
