//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.OracleClient;
using System.Collections;

/// <summary>
/// Summary description for DataAccess
/// </summary>
public class DataAccess
{
    private string strConnectionString;
    private string strProvider;

    public struct dayDetail
    {
        public string strDate;
        public int intSessionCount;
        public int intApplicationCount;
    }

	public DataAccess()
	{
        strConnectionString = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString;

        strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;
    }

    public Hashtable getCalendarData(float utcOffset, DateTime startDate, int appID)
    {
        switch (strProvider)
        {
            case "System.Data.SqlClient":
                return getCalendarDataSQL(utcOffset, startDate, appID);
                break;
            case "System.Data.OracleClient":
                return getCalendarDataOracle(utcOffset, startDate, appID);
                break;
            default:
                return null;
                break;
        }
    }

    private Hashtable getCalendarDataSQL(float utcOffset, DateTime startDate, int appID)
    {
        Hashtable dayDetails = new Hashtable();

        // Set up SQL query parameters
        string strSQL;
        DateTime endDate;
        SqlCommand sqlCmd;
        SqlDataReader sqlDR;

        // End our query 45 days after the start date
        endDate = startDate.AddDays(45);

        // Format our select date in the correct time zone
        string sessionDate = String.Format("CONVERT(VARCHAR, DATEADD(hh, {0}, SESSIONSTART), 111)", utcOffset);

        strSQL = String.Format("SELECT {0} AS sessionDate, COUNT(DISTINCT(FK_USERID)) AS sessionsStarted FROM SDB_SESSION WHERE SESSIONSTART BETWEEN @dtStart AND @dtEnd GROUP BY {0}", sessionDate);

        SqlConnection sqlConn = new SqlConnection(strConnectionString);

        sqlConn.Open();

        try
        {
            // Execute the SQL command to retreive the data
            sqlCmd = new SqlCommand(strSQL, sqlConn);
            sqlCmd.Parameters.AddWithValue("dtStart", startDate.Date);
            sqlCmd.Parameters.AddWithValue("dtEnd", endDate.Date);
            sqlDR = sqlCmd.ExecuteReader();

            // Populate Hash Table
            while (sqlDR.Read())
            {
                // Retrieve sessionDate from SQL query
                string strThisDay = DateTime.Parse(sqlDR["sessionDate"].ToString()).ToShortDateString();

                // Create new datDetail struct and add to hash table
                dayDetail thisDay = new dayDetail();
                thisDay.strDate = strThisDay;
                thisDay.intSessionCount = int.Parse(sqlDR["sessionsStarted"].ToString());

                dayDetails.Add(strThisDay, thisDay);
            }

            sqlDR.Dispose();
            sqlCmd.Dispose();

            // populate application counts on the dayDetail structs
            if (appID != 0)
            {
                string strSQLApps = String.Format("SELECT {0} AS sessionDate, COUNT(FK_APPNAMEID) AS appCount FROM SDB_SESSION WHERE (SESSIONSTART BETWEEN '{1}' AND '{2}') AND SDB_SESSION.FK_APPNAMEID = '{3}' GROUP BY {0}", sessionDate, startDate.ToShortDateString(), endDate.ToShortDateString(), appID.ToString());

                sqlCmd = new SqlCommand(strSQLApps, sqlConn);

                sqlDR = sqlCmd.ExecuteReader();

                // Modify the Hash Table
                while (sqlDR.Read())
                {
                    // Retrieve sessionDate from SQL query
                    string strThisDay = DateTime.Parse(sqlDR["sessionDate"].ToString()).ToShortDateString();

                    // get the struct for this day
                    dayDetail thisDay = (dayDetail)dayDetails[strThisDay];

                    thisDay.intApplicationCount = int.Parse(sqlDR["appCount"].ToString());

                    dayDetails[strThisDay] = thisDay;
                }

                sqlDR.Dispose();
                sqlCmd.Dispose();
            }
        }
        catch (Exception e)
        {
            throw new Exception(e.Message + "<br /> " + strSQL);
        }
        finally
        {
            sqlConn.Close();
        }

        return dayDetails;
    }

    private Hashtable getCalendarDataOracle(float utcOffset, DateTime startDate, int appID)
    {
        Hashtable dayDetails = new Hashtable();

        // Set up SQL query parameters
        string strSQL;
        DateTime endDate;
        OracleCommand sqlCmd;
        OracleDataReader sqlDR;

        // End our query 45 days after the start date
        endDate = startDate.AddDays(45);

        // Format our select date in the correct time zone
        string sessionDate = String.Format("TO_CHAR(SESSIONSTART + ({0}/24), 'YYYY-MM-DD')", utcOffset);

        strSQL = String.Format("SELECT {0} AS sessionDate, COUNT(DISTINCT(FK_USERID)) AS sessionsStarted FROM SDB_SESSION WHERE SESSIONSTART BETWEEN To_Date('{1}', 'YYYY-MM-DD') AND To_Date('{2}', 'YYYY-MM-DD') GROUP BY {0}", sessionDate, startDate.ToString("yyyy-MM-dd"), endDate.ToString("yyyy-MM-dd"));

        OracleConnection sqlConn = new OracleConnection(strConnectionString);

        sqlConn.Open();

        try
        {
            // Execute the SQL command to retreive the data
            sqlCmd = new OracleCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            // Populate Hash Table
            while (sqlDR.Read())
            {
                // Retrieve sessionDate from SQL query
                string strThisDay = DateTime.Parse(sqlDR["sessionDate"].ToString()).ToShortDateString();

                // Create new datDetail struct and add to hash table
                dayDetail thisDay = new dayDetail();
                thisDay.strDate = strThisDay;
                thisDay.intSessionCount = int.Parse(sqlDR["sessionsStarted"].ToString());

                dayDetails.Add(strThisDay, thisDay);
            }

            sqlDR.Dispose();
            sqlCmd.Dispose();

            // populate application counts on the dayDetail structs
            if (appID != 0)
            {
                string strSQLApps = String.Format("SELECT {0} AS sessionDate, COUNT(FK_APPNAMEID) AS appCount FROM SDB_SESSION WHERE (SESSIONSTART BETWEEN  To_Date('{1}', 'YYYY-MM-DD') AND To_Date('{2}', 'YYYY-MM-DD')) AND (SDB_SESSION.FK_APPNAMEID = '{3}') GROUP BY {0}", sessionDate, startDate.ToString("yyyy-MM-dd"), endDate.ToString("yyyy-MM-dd"), appID);

                sqlCmd = new OracleCommand(strSQLApps, sqlConn);

                sqlDR = sqlCmd.ExecuteReader();

                // Modify the Hash Table
                while (sqlDR.Read())
                {
                    // Retrieve sessionDate from SQL query
                    string strThisDay = DateTime.Parse(sqlDR["sessionDate"].ToString()).ToShortDateString();

                    // get the struct for this day
                    dayDetail thisDay = (dayDetail)dayDetails[strThisDay];

                    thisDay.intApplicationCount = int.Parse(sqlDR["appCount"].ToString());

                    dayDetails[strThisDay] = thisDay;
                }

                sqlDR.Dispose();
                sqlCmd.Dispose();
            }
        }
        catch (Exception e)
        {
            throw new Exception(e.Message + "<br /> " + strSQL);
        }
        finally
        {
            sqlConn.Close();
        }

        return dayDetails;
    }

    public static string getApplicationsFilter(DateTime startDate)
    {
        string strAppFilter = String.Empty;

        DateTime endDate = startDate.AddDays(45);

        string strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;

        switch (strProvider)
        {
            case "System.Data.SqlClient":
                strAppFilter = String.Format("SELECT DISTINCT LU_APPNAME.PK_APPNAMEID, LU_APPNAME.APPNAME FROM LU_APPNAME INNER JOIN SDB_SESSION ON LU_APPNAME.PK_APPNAMEID = SDB_SESSION.FK_APPNAMEID WHERE ((SDB_SESSION.SESSIONSTART BETWEEN '{0}' AND '{1}') AND (LU_APPNAME.APPNAME <> '')) ORDER BY LU_APPNAME.APPNAME", startDate.ToShortDateString(), endDate.ToShortDateString());
                break;
            case "System.Data.OracleClient":
                strAppFilter = String.Format("SELECT DISTINCT LU_APPNAME.PK_APPNAMEID, LU_APPNAME.APPNAME FROM LU_APPNAME INNER JOIN SDB_SESSION ON LU_APPNAME.PK_APPNAMEID = SDB_SESSION.FK_APPNAMEID WHERE ((SDB_SESSION.SESSIONSTART BETWEEN TO_DATE('{0}', 'YYYY-MM-DD') AND TO_DATE('{1}', 'YYYY-MM-DD')) AND (LU_APPNAME.APPNAME <> ' ')) ORDER BY LU_APPNAME.APPNAME", startDate.ToString("yyyy-MM-dd"), endDate.ToString("yyyy-MM-dd"));
                break;
            default:
                strAppFilter = String.Empty;
                break;
        }

        return strAppFilter;
    }

	public void DateHelper(float utcOffset, ref string minDateExtreme, ref string maxDateExtreme)
	{
        switch (strProvider)
        {
            case "System.Data.SqlClient":
                DateHelperSQL(utcOffset, ref minDateExtreme, ref maxDateExtreme);
                break;
            case "System.Data.OracleClient":
                DateHelperOracle(utcOffset, ref minDateExtreme, ref maxDateExtreme);
                break;
        }
    }

    private void DateHelperOracle(float utcOffset, ref string minDateExtreme, ref string maxDateExtreme)
    {
        // Set up Oracle connection parameters
        OracleConnection sqlConn;
        OracleDataReader sqlDR;
        OracleCommand sqlCmd;
        string strSQL = String.Empty;

        // Connect to the RM summary database
        sqlConn = new OracleConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        sqlConn.Open();

        try
        {
            strSQL = String.Format("SELECT MAX(SESSIONSTART + ({0}/24)) AS MAX_DATE, MIN(SESSIONSTART + ({0}/24)) AS MIN_DATE FROM SDB_SESSION", utcOffset);
            sqlCmd = new OracleCommand(strSQL, sqlConn);

            sqlDR = sqlCmd.ExecuteReader();

            sqlDR.Read();

            maxDateExtreme = DateTime.Parse(sqlDR["MAX_DATE"].ToString()).ToShortDateString();
            minDateExtreme = DateTime.Parse(sqlDR["MIN_DATE"].ToString()).ToShortDateString();
        }
        catch
        {
            maxDateExtreme = DateTime.Now.ToShortDateString();
            minDateExtreme = DateTime.Now.ToShortDateString();
        }
        finally
        {
            sqlConn.Close();
        }
    }

    private void DateHelperSQL(float utcOffset, ref string minDateExtreme, ref string maxDateExtreme)
    {
        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlDataReader sqlDR;
        SqlCommand sqlCmd;
        string strSQL = String.Empty;

        // Connect to the RM summary database
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);

        try
        {
            sqlConn.Open();
            strSQL = "SELECT MAX(DATEADD(hh, " + utcOffset + ", SESSIONSTART)) AS MAX_DATE, MIN(DATEADD(hh, " + utcOffset + ", SESSIONSTART)) AS MIN_DATE FROM SDB_SESSION";
            sqlCmd = new SqlCommand(strSQL, sqlConn);

            sqlDR = sqlCmd.ExecuteReader();

            sqlDR.Read();

            maxDateExtreme = DateTime.Parse(sqlDR["MAX_DATE"].ToString()).ToShortDateString();
            minDateExtreme = DateTime.Parse(sqlDR["MIN_DATE"].ToString()).ToShortDateString();
        }
        catch
        {
            maxDateExtreme = DateTime.Now.ToShortDateString();
            minDateExtreme = DateTime.Now.ToShortDateString();
        }
        finally
        {
            sqlConn.Close();
        }
    }

    public void getApplicationFreqData(DateTime dtFrom, DateTime dtTo, ref ApplicationsDataSet dsApps)
    {

        switch (strProvider)
        {
            case "System.Data.OracleClient":
                getAppFreqOracle(dtFrom, dtTo, ref dsApps);
                break;
            default:
                getAppFreqSQL(dtFrom, dtTo, ref dsApps);
                break;
        }
    }

    private void getAppFreqSQL(DateTime dtFrom, DateTime dtTo, ref ApplicationsDataSet dsApps)
    {
        string strSql = "SELECT DISTINCT LU_APPNAME.APPNAME, COUNT(SDB_SESSION.PK_SDB_SESSIONID) AS APP_FREQ FROM LU_APPNAME INNER JOIN SDB_SESSION ON LU_APPNAME.PK_APPNAMEID = SDB_SESSION.FK_APPNAMEID WHERE (LU_APPNAME.APPNAME <> '') AND (SDB_SESSION.SESSIONSTART BETWEEN @dtStart AND @dtEnd) GROUP BY LU_APPNAME.APPNAME ORDER BY APP_FREQ DESC";

        SqlDataAdapter da = new SqlDataAdapter(strSql, strConnectionString);
        da.SelectCommand.Parameters.AddWithValue("dtStart", dtFrom);
        da.SelectCommand.Parameters.AddWithValue("dtEnd", dtTo);

        try
        {
            da.Fill(dsApps.Applications);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message + "<br /> " + strSql);
        }
    }

    private void getAppFreqOracle(DateTime dtFrom, DateTime dtTo, ref ApplicationsDataSet dsApps)
    {
        string strSql = String.Format("SELECT DISTINCT LU_APPNAME.APPNAME, COUNT(SDB_SESSION.PK_SDB_SESSIONID) AS APP_FREQ FROM LU_APPNAME INNER JOIN SDB_SESSION ON LU_APPNAME.PK_APPNAMEID = SDB_SESSION.FK_APPNAMEID WHERE (LU_APPNAME.APPNAME <> ' ') AND (SDB_SESSION.SESSIONSTART BETWEEN TO_DATE('{0}', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('{1}', 'YYYY-MM-DD HH24:MI:SS')) GROUP BY LU_APPNAME.APPNAME ORDER BY APP_FREQ DESC", dtFrom.ToString("yyyy-MM-dd HH:mm:ss"), dtTo.ToString("yyyy-MM-dd HH:mm:ss"));

        OracleDataAdapter da = new OracleDataAdapter(strSql, strConnectionString);

        try
        {
            da.Fill(dsApps.Applications);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message + "<br />" + strSql);
        }
    }

    public void getClientsData(ref ClientsDataSet dsClients, DateTime dtFrom, DateTime dtTo)
    {
        switch (strProvider)
        {
            case "System.Data.OracleClient":
                getClientsDataOracle(ref dsClients, dtFrom, dtTo);
                updateClientVersions(ref dsClients);
                break;
            default:
                getClientsDataSQL(ref dsClients, dtFrom, dtTo);
                updateClientVersions(ref dsClients);
                break;
        }
    }

    private void getClientsDataSQL(ref ClientsDataSet dsClients, DateTime dtFrom, DateTime dtTo)
    {
        SqlConnection sqlConn = new SqlConnection(strConnectionString);
        string strSql =
            "SELECT DISTINCT SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID, " +
            "LU_CLIENTTYPEMAPPINGS.CLIENTTYPENAME AS CLIENT_NAME, " +
            "LU_CLIENTPROPERTIES.BUILD AS BUILD, " +
            "LU_CLIENTPROPERTIES.VERSION AS VERSION, " +
            "LU_CLIENTPROPERTIES.FK_CLIENTTYPEID, " +
            "COUNT(SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID) AS FREQ " +
            "FROM SDB_CLIENTHISTORY " +
            "INNER JOIN LU_CLIENTPROPERTIES ON SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID = LU_CLIENTPROPERTIES.PK_CLIENTPROPERTIESID " +
            "INNER JOIN LU_CLIENTTYPEMAPPINGS ON LU_CLIENTPROPERTIES.FK_CLIENTTYPEID = LU_CLIENTTYPEMAPPINGS.PK_CLIENTTYPEID " +
            "WHERE (LU_CLIENTTYPEMAPPINGS.PROTOCOL_TYPE <> '0') " +
            "AND (SDB_CLIENTHISTORY.STARTTIME BETWEEN @dtStart AND @dtEnd) " +
            "GROUP BY SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID, " +
            "LU_CLIENTTYPEMAPPINGS.CLIENTTYPENAME, " +
            "LU_CLIENTPROPERTIES.BUILD, " +
            "LU_CLIENTPROPERTIES.VERSION, " +
            "LU_CLIENTPROPERTIES.FK_CLIENTTYPEID " +
            "ORDER BY FREQ DESC, " +
            "LU_CLIENTTYPEMAPPINGS.CLIENTTYPENAME, " +
            "LU_CLIENTPROPERTIES.VERSION DESC, LU_CLIENTPROPERTIES.BUILD DESC";

        SqlDataAdapter da = new SqlDataAdapter(strSql, sqlConn);
        da.SelectCommand.Parameters.AddWithValue("dtStart", dtFrom);
        da.SelectCommand.Parameters.AddWithValue("dtEnd", dtTo);

        try
        {
            da.Fill(dsClients._Clients);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message + "<br />" + strSql);
        }
        finally
        {
            da.Dispose();
        }
    }

    private void getClientsDataOracle(ref ClientsDataSet dsClients, DateTime dtFrom, DateTime dtTo)
    {
        OracleConnection sqlConn = new OracleConnection(strConnectionString);
        string strSql = String.Format(
            "SELECT DISTINCT SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID, " +
            "LU_CLIENTTYPEMAPPINGS.CLIENTTYPENAME AS CLIENT_NAME, " +
            "LU_CLIENTPROPERTIES.BUILD AS BUILD, " +
            "LU_CLIENTPROPERTIES.VERSION AS VERSION, " +
            "LU_CLIENTPROPERTIES.FK_CLIENTTYPEID, " +
            "COUNT(SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID) AS FREQ " +
            "FROM SDB_CLIENTHISTORY " +
            "INNER JOIN LU_CLIENTPROPERTIES ON SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID = LU_CLIENTPROPERTIES.PK_CLIENTPROPERTIESID " +
            "INNER JOIN LU_CLIENTTYPEMAPPINGS ON LU_CLIENTPROPERTIES.FK_CLIENTTYPEID = LU_CLIENTTYPEMAPPINGS.PK_CLIENTTYPEID " +
            "WHERE (LU_CLIENTTYPEMAPPINGS.PROTOCOL_TYPE <> '0') " +
            "AND (SDB_CLIENTHISTORY.STARTTIME BETWEEN TO_DATE('{0}', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('{1}', 'YYYY-MM-DD HH24:MI:SS')) " +
            "GROUP BY SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID, " +
            "LU_CLIENTTYPEMAPPINGS.CLIENTTYPENAME, " +
            "LU_CLIENTPROPERTIES.BUILD, " +
            "LU_CLIENTPROPERTIES.VERSION, " +
            "LU_CLIENTPROPERTIES.FK_CLIENTTYPEID " +
            "ORDER BY FREQ DESC, " +
            "LU_CLIENTTYPEMAPPINGS.CLIENTTYPENAME, " +
            "LU_CLIENTPROPERTIES.VERSION DESC, LU_CLIENTPROPERTIES.BUILD DESC",
            dtFrom.ToString("yyyy-MM-dd hh:mm:ss"),
            dtTo.ToString("yyyy-MM-dd hh:mm:ss"));

        OracleDataAdapter da = new OracleDataAdapter(strSql, sqlConn);

        try
        {
            da.Fill(dsClients._Clients);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message + "<br />" + strSql);
        }
        finally
        {
            da.Dispose();
        }
    }

    private void updateClientVersions(ref ClientsDataSet dsClients)
    {
        Hashtable htVersions = new Hashtable();
        htVersions.Add(317, "3.00");
        htVersions.Add(324, "3.00");
        htVersions.Add(330, "3.00");
        htVersions.Add(349, "3.00");

        htVersions.Add(581, "4.00");
        htVersions.Add(606, "4.00");
        htVersions.Add(609, "4.00");
        htVersions.Add(614, "4.00");
 
        htVersions.Add(715, "4.20");
        htVersions.Add(727, "4.20");
        htVersions.Add(741, "4.20");
 
        htVersions.Add(779, "4.21");
 
        htVersions.Add(910, "6.00");
 
        htVersions.Add(961, "6.01");
        htVersions.Add(963, "6.01");
        htVersions.Add(964, "6.01");
        htVersions.Add(967, "6.01");
 
        htVersions.Add(985, "6.20");
        htVersions.Add(986, "6.20");

        htVersions.Add(1050, "6.30");
 
        htVersions.Add(1051, "6.31");
 
        htVersions.Add(17534, "7.00");

        htVersions.Add(21825, "7.1");
        htVersions.Add(22650, "7.1");

        htVersions.Add(24737, "8.0");
 
        htVersions.Add(29670, "8.1");
 
        htVersions.Add(31827, "9.0");
 
        htVersions.Add(32649, "9.0");
 
        htVersions.Add(36280, "9.1");
 
        htVersions.Add(39151, "9.15");
 
        htVersions.Add(44376, "9.2");

        htVersions.Add(50211, "9.23");
 
        htVersions.Add(45418, "10.0");
        htVersions.Add(49686, "10.0");
 
        foreach (ClientsDataSet.ClientsRow row in dsClients._Clients)
        {
            // If the version is not present, determine the version by the client build
            if (row.VERSION.Trim() == String.Empty)
            {
                if (htVersions.ContainsKey(row.BUILD))
                {
                    row.VERSION = "c" + htVersions[row.BUILD].ToString();
                }
            }
        }
    }

    public string getFarmName()
    {
        string strReturnVal;

        switch (strProvider)
        {
            case "System.Data.SqlClient":
                strReturnVal = getFarmNameSql();
                break;
            case "System.Data.OracleClient":
                strReturnVal = getFarmNameOracle();
                break;
            default:
                strReturnVal = String.Empty;
                break;
        }

        if (strReturnVal != String.Empty)
            strReturnVal = " - " + strReturnVal;

        return strReturnVal;
    }

    private string getFarmNameSql()
    {
        string strFarmName = String.Empty;

        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlDataReader sqlDR;
        SqlCommand sqlCmd;
        string strSQL = String.Empty;

        // Connect to the RM summary database
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        strSQL = "SELECT TOP 1 FARMNAME FROM LU_FARMNAME";
        sqlCmd = new SqlCommand(strSQL, sqlConn);

        try
        {
            sqlConn.Open();
            sqlDR = sqlCmd.ExecuteReader();
            sqlDR.Read();
            strFarmName = sqlDR["FARMNAME"].ToString();
        }
        catch
        {
            strFarmName = String.Empty;
        }
        finally
        {
            sqlCmd.Dispose();
            sqlConn.Close();
        }

        return strFarmName;
    }

    private string getFarmNameOracle()
    {
        string strFarmName = String.Empty;

        // Set up Oracle connection parameters
        OracleConnection sqlConn;
        OracleDataReader sqlDR;
        OracleCommand sqlCmd;
        string strSQL = String.Empty;

        // Connect to the RM summary database
        sqlConn = new OracleConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        strSQL = "SELECT FARMNAME FROM LU_FARMNAME WHERE ROWNUM <= 1";
        sqlCmd = new OracleCommand(strSQL, sqlConn);

        try
        {
            sqlConn.Open();
            sqlDR = sqlCmd.ExecuteReader();
            sqlDR.Read();
            strFarmName = sqlDR["FARMNAME"].ToString();
        }
        catch
        {
            strFarmName = String.Empty;
        }
        finally
        {
            sqlCmd.Dispose();
            sqlConn.Close();
        }

        return strFarmName;
    }

}
