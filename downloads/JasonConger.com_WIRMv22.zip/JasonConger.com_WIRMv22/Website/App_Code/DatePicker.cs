using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for DatePicker
/// </summary>
public class DatePicker
{

	public DatePicker()
	{
	}

    public static string getCalendarOptions(DateTime dtMaxDate, DateTime dtMinDate)
    {
        string calOptions = String.Empty;

        calOptions += "<script type=\"text/javascript\"> ";
        //calOptions += "<!-- ";
        calOptions += "var PickerParams = {";
        calOptions += "onClientDayRender:\"\",";
        calOptions += "onClientBeforeCalendarOpen:\"\",";
        calOptions += "onClientBeforeCalendarClose:\"\",";
        calOptions += "onClientAfterCalendarOpen:\"\",";
        calOptions += "onClientBeforeSelectionChanged:\"\",";
        calOptions += "onClientAfterSelectionChanged:\"updateLabel\",";
        calOptions += "onClientBeforeVisibleMonthChanged:\"\",";
        calOptions += "onClientAfterVisibleMonthChanged:\"\",";
        calOptions += "enabled:true,";
        calOptions += "autoPostBack:false,";
        calOptions += "selectableWeekDays:true,";
        calOptions += "selectableWeekendDays:true,";
        calOptions += "selectablePrevMonthDays:true,";
        calOptions += "selectableNextMonthDays:true,";

        int maxYear = dtMaxDate.Year;
        int maxMonth = dtMaxDate.Month - 1;
        int maxDay = dtMaxDate.Day;
        string strMaxDate = String.Format("{0}, {1}, {2}", maxYear, maxMonth, maxDay);

        calOptions += "maximumDate:new Date(" + strMaxDate + "),";

        int minYear = dtMinDate.Year;
        int minMonth = dtMinDate.Month - 1;
        int minDay = dtMinDate.Day;
        string strMinDate = String.Format("{0}, {1}, {2}", minYear, minMonth, minDay);

        calOptions += "minimumDate:new Date(" + strMinDate + "),";
        calOptions += "twoDigitYearBreak:50,";
        calOptions += "openCalendarOnTextBoxFocus:false,";
        calOptions += "monthSelectorEnabled:true,";
        calOptions += "yearSelectorEnabled:true,";
        calOptions += "rows:1,";
        calOptions += "columns:1,";
        calOptions += "dayStatusBarText:\"{0}\",";
        calOptions += "nullDateText:\"\",";
        calOptions += "xOffset:0,";
        calOptions += "yOffset:1,";
        calOptions += "resourcePath:\"clientScripts\",";
        calOptions += "nextPrevMonthImageWidth:\"5px\",";
        calOptions += "nextPrevMonthImageHeight:\"9px\",";
        calOptions += "nextMonthText:\"&gt;\",";
        calOptions += "prevMonthText:\"&lt;\",";
        calOptions += "showWeekNumbers:false,";
        calOptions += "showDaysInNextMonth:true,";
        calOptions += "showDaysInPrevMonth:true,";
        calOptions += "showTodayButton:true,";
        calOptions += "todayButtonText:\"Today\",";
        calOptions += "showNoneButton:false,";
        calOptions += "noneButtonText:\"None\",";
        calOptions += "footNoteText:\"\",";
        calOptions += "forceSixRows:true,";
        calOptions += "firstDayOfWeek:7,";
        calOptions += "dayNameFormat:\"FirstLetter\",";
        calOptions += "datePickerDisplayType:\"TextBoxAndImage\",";
        calOptions += "buttonText:\"Calendar\",";
        calOptions += "nextPrevFormat:\"Image\",";
        calOptions += "showDayHeader:true,";
        calOptions += "showNextPrevMonth:true,";
        calOptions += "showTitle:true,";
        calOptions += "downYearSelectorImageFileName:\"arrow_down.gif\",";
        calOptions += "upDownYearSelectorImageWidth:9,";
        calOptions += "upDownYearSelectorImageHeight:5,";
        calOptions += "upYearSelectorText:\"+\",";
        calOptions += "downYearSelectorText:\"-\",";
        calOptions += "upDownYearSelectorFormat:\"Image\",";
        calOptions += "monthSelectorXOffset:-11,";
        calOptions += "monthSelectorYOffset:2,";
        calOptions += "yearSelectorXOffset:-11,";
        calOptions += "yearSelectorYOffset:2,";
        calOptions += "visibleDate:null,";
        calOptions += "dateOrder:\"mdy\",";
        calOptions += "popUpStyle:\"\",";
        calOptions += "popUpStyleCssClass:\"bdpPopUp\",";
        calOptions += "calendarStyle:\"\",";
        calOptions += "calendarStyleCssClass:\"bdpCalendar\",";
        calOptions += "noneButtonStyle:\"\",";
        calOptions += "noneButtonStyleCssClass:\"bdpClearButton\",";
        calOptions += "todayButtonStyle:\"\",";
        calOptions += "todayButtonStyleCssClass:\"bdpTodayButton\",";
        calOptions += "titleStyle:\"\",";
        calOptions += "titleStyleCssClass:\"bdpTitle\",";
        calOptions += "nextPrevStyle:\"\",";
        calOptions += "nextPrevStyleCssClass:\"bdpNextPrev\",";
        calOptions += "dayHeaderStyle:\"\",";
        calOptions += "dayHeaderStyleCssClass:\"bdpDayHeader\",";
        calOptions += "dayStyle:\"\",";
        calOptions += "dayStyleCssClass:\"bdpDay\",";
        calOptions += "otherMonthDayStyle:\"\",";
        calOptions += "otherMonthDayStyleCssClass:\"bdpOtherMonthDay bdpDay\",";
        calOptions += "weekendDayStyle:\"\",";
        calOptions += "weekendDayStyleCssClass:\"bdpWeekendDay bdpDay\",";
        calOptions += "selectedDayStyle:\"\",";
        calOptions += "selectedDayStyleCssClass:\"bdpSelectedDay bdpDay\",";
        calOptions += "todayDayStyle:\"\",";
        calOptions += "todayDayStyleCssClass:\"bdpTodayDay bdpDay\",";
        calOptions += "footerStyle:\"\",";
        calOptions += "footerStyleCssClass:\"bdpFooter\",";
        calOptions += "footNoteStyle:\"\",";
        calOptions += "footNoteStyleCssClass:\"bdpFootNote\",";
        calOptions += "weekNumberStyle:\"\",";
        calOptions += "weekNumberStyleCssClass:\"bdpWeekNumber\",";
        calOptions += "otherMonthDayWeekendDayStyle:\"\",";
        calOptions += "otherMonthDayWeekendDayStyleCssClass:\"bdpOtherMonthDay bdpDay bdpWeekendDay bdpDay bdpDay\",";
        calOptions += "selectedDayTodayDayStyle:\"\",";
        calOptions += "selectedDayTodayDayStyleCssClass:\"bdpTodayDay bdpDay bdpSelectedDay bdpDay bdpDay\",";
        calOptions += "selectedDayWeekendDayStyle:\"\",";
        calOptions += "selectedDayWeekendDayStyleCssClass:\"bdpSelectedDay bdpDay bdpWeekendDay bdpDay bdpDay\",";
        calOptions += "todayDayWeekendDayStyle:\"\",";
        calOptions += "todayDayWeekendDayStyleCssClass:\"bdpTodayDay bdpDay bdpWeekendDay bdpDay bdpDay\",";
        calOptions += "timePicker:\"\",";
        calOptions += "postBackFunction:\"\",";
        calOptions += "dateFormat:\"" + System.Globalization.DateTimeFormatInfo.CurrentInfo.ShortDatePattern + "\",";
        calOptions += "culture:\"datePickerCulture_" + System.Globalization.CultureInfo.CurrentCulture.ToString().Replace("-", "_") + "\",";
        calOptions += "nextMonthImageUrl:\"images/calendar/arrow_right.gif\",";
        calOptions += "prevMonthImageUrl:\"images/calendar/arrow_left.gif\",";
        calOptions += "upYearSelectorImageUrl:\"images/calendar/arrow_up.gif\",";
        calOptions += "downYearSelectorImageUrl:\"images/calendar/arrow_down.gif\",";
        calOptions += "specialDates:\"\"};";
        //calOptions += " //-->";
        calOptions += "</script>";

        return calOptions;
    }
}
