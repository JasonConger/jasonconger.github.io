//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class clientsByUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
                Resources.WIRM.ClientsByWorkstation;

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.ClientsByWorkstation;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/computer_large.gif";
        }

        string strClientVersion = Request.QueryString["v"];

        if (strClientVersion.Length > 0 && strClientVersion.Substring(0, 1) == "c")
            strClientVersion = strClientVersion.Substring(1, strClientVersion.Length - 1);

        lblClient.Text = Resources.WIRM.ClientVersion + ": " + strClientVersion;

        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        getData();

        gvClientsByUser.Width = 550;
    }

    protected void getData()
    {
        string strClientTypeID = Request.QueryString["c"];
        string strClientVersion = Request.QueryString["v"];

        if (strClientVersion.Length > 0 && strClientVersion.Substring(0, 1) == "c")
            strClientVersion = " ";

        string strClientBuild = Request.QueryString["b"];
        float utcOffset = float.Parse(Session["utcoffset"].ToString());
        string strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;
        string strStart = Request.QueryString["strStart"];
        string strEnd = Request.QueryString["strEnd"];

        switch (strProvider)
        {
            case "System.Data.OracleClient":
                sqlClientsByUser.ProviderName = strProvider;
                sqlClientsByUser.SelectCommand = String.Format(
                    "SELECT DISTINCT T.CLIENTNAME, " +
                    "T.LAST_USED + ({3}/24) AS LAST_USED, " +
                    "MAX(SDB_SESSION_1.PK_SDB_SESSIONID) AS SESSIONID " +
                    "FROM (SELECT " +
                    "MAX(SDB_SESSION.SESSIONSTART) AS LAST_USED, LU_CLIENT.CLIENTNAME " +
                    "FROM SDB_SESSION " +
                    "INNER JOIN SDB_CLIENTHISTORY ON SDB_SESSION.PK_SDB_SESSIONID = SDB_CLIENTHISTORY.FK_SDB_SESSIONID " +
                    "INNER JOIN LU_CLIENTPROPERTIES ON SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID = LU_CLIENTPROPERTIES.PK_CLIENTPROPERTIESID " +
                    "INNER JOIN LU_CLIENT ON LU_CLIENT.PK_CLIENTID = SDB_SESSION.FK_CLIENTID " +
                    "WHERE (LU_CLIENTPROPERTIES.FK_CLIENTTYPEID = '{0}') " +
                    "AND (LU_CLIENTPROPERTIES.VERSION = '{1}') " +
                    "AND (LU_CLIENTPROPERTIES.BUILD = '{2}') " +
                    "AND SDB_SESSION.SESSIONSTART BETWEEN To_Date('{4}', 'YYYY-MM-DD') AND To_Date('{5}', 'YYYY-MM-DD') " +
                    "GROUP BY LU_CLIENT.CLIENTNAME) T " +
                    "INNER JOIN SDB_SESSION SDB_SESSION_1 ON T.LAST_USED = SDB_SESSION_1.SESSIONSTART " +
                    "INNER JOIN SDB_CLIENTHISTORY SDB_CLIENTHISTORY_1 ON SDB_SESSION_1.PK_SDB_SESSIONID = SDB_CLIENTHISTORY_1.FK_SDB_SESSIONID " +
                    "GROUP BY T.LAST_USED, T.CLIENTNAME " +
                    "ORDER BY LAST_USED DESC, T.CLIENTNAME",
                    strClientTypeID,
                    strClientVersion,
                    strClientBuild,
                    utcOffset,
                    DateTime.Parse(strStart).ToString("yyyy-MM-dd"),
                    DateTime.Parse(strEnd).ToString("yyyy-MM-dd"));
                break;
            default:
                sqlClientsByUser.SelectCommand = String.Format(
                    "SELECT DISTINCT T.CLIENTNAME, " +
                    "DATEADD(hh, {3}, T.LAST_USED) AS LAST_USED, " +
                    "MAX(SDB_SESSION_1.PK_SDB_SESSIONID) AS SESSIONID " +
                    "FROM (SELECT " +
                    "MAX(SDB_SESSION.SESSIONSTART) AS LAST_USED, LU_CLIENT.CLIENTNAME " +
                    "FROM SDB_SESSION " +
                    "INNER JOIN SDB_CLIENTHISTORY ON SDB_SESSION.PK_SDB_SESSIONID = SDB_CLIENTHISTORY.FK_SDB_SESSIONID " +
                    "INNER JOIN LU_CLIENTPROPERTIES ON SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID = LU_CLIENTPROPERTIES.PK_CLIENTPROPERTIESID " +
                    "INNER JOIN LU_CLIENT ON LU_CLIENT.PK_CLIENTID = SDB_SESSION.FK_CLIENTID " +
                    "WHERE (LU_CLIENTPROPERTIES.FK_CLIENTTYPEID = '{0}') " +
                    "AND (LU_CLIENTPROPERTIES.VERSION = '{1}') " +
                    "AND (LU_CLIENTPROPERTIES.BUILD = '{2}') " +
                    "AND (SDB_SESSION.SESSIONSTART BETWEEN '{4}' AND '{5}') " +
                    "GROUP BY LU_CLIENT.CLIENTNAME) AS T " +
                    "INNER JOIN SDB_SESSION AS SDB_SESSION_1 ON T.LAST_USED = SDB_SESSION_1.SESSIONSTART " +
                    "INNER JOIN SDB_CLIENTHISTORY AS SDB_CLIENTHISTORY_1 ON SDB_SESSION_1.PK_SDB_SESSIONID = SDB_CLIENTHISTORY_1.FK_SDB_SESSIONID " +
                    "GROUP BY T.LAST_USED, T.CLIENTNAME " +
                    "ORDER BY LAST_USED DESC, T.CLIENTNAME",
                    strClientTypeID,
                    strClientVersion.Trim(),
                    strClientBuild,
                    utcOffset,
                    strStart,
                    strEnd);
                break;
        }
    }

    protected void gvClientsByUser_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
            e.Row.Cells[2].Visible = false;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[2].Visible = false;
            string strSessionID = e.Row.Cells[2].Text;
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='pointer';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", Resources.WIRM.ClickToViewSessionDetails);
            e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", strSessionID));
        }
    }

    protected void lbExcelExport_Click(object sender, EventArgs e)
    {
        GridView gv = new GridView();
        gv.AllowPaging = false;
        gv.AllowSorting = false;
        gv.AutoGenerateColumns = false;

        foreach (DataControlField col in gvClientsByUser.Columns)
        {
            if (col.HeaderText != String.Empty)
                gv.Columns.Add(col);
        }

        gv.DataSource = sqlClientsByUser;
        getData();
        gv.DataBind();

        Response.Clear();
        Response.AddHeader("content-disposition", "attachment;filename=Report_Export.xls");
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.xls";
        System.IO.StringWriter stringWrite = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
        gv.RenderControl(htmlWrite);
        Response.Write(stringWrite.ToString());
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
}
