//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class hourDetail : System.Web.UI.Page
{
    private float utcOffset;
    private float utcOffset2;
    private string strDate;
    private string strHour;
    private string strStartDate;
    private string strEndDate;
    private string strAppID;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
            String.Format("{0} {1} {2} {3}",
                Resources.WIRM.SessionsStartedOn,
                strDate,
                Resources.WIRM.During.ToLower(),
                strHour);

        GetData();

        if (!IsPostBack)
        {

            int intHour = int.Parse(strHour);

            if (intHour > 12)
            {
                intHour = intHour - 12;
                strHour = intHour.ToString() + ":00 PM";
            }
            else
            {
                strHour = strHour + ":00 AM";
            }

            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += String.Format(" - {0} {1} {2} {3}.",
                Resources.WIRM.SessionsStartedOn,
                strDate,
                Resources.WIRM.During.ToLower(),
                strHour);

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";
        }
    }

    private void GetData()
    {
        utcOffset = float.Parse(Session["utcOffset"].ToString());
        utcOffset2 = utcOffset * -1;
        strDate = Request["strDate"];
        strHour = Request["strHour"];
        strStartDate = String.Format("{0} {1}:00:00", strDate, strHour);
        strEndDate = String.Format("{0} {1}:59:59", strDate, strHour);
        if (Request["strAppID"].Trim() != String.Empty)
            strAppID = Request["strAppID"];
        else
            strAppID = "NULL";
   

        if (ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName == "System.Data.OracleClient")
        {
            sqlHourDetail.ProviderName = "System.Data.OracleClient";
            sqlHourDetail.SelectCommand = String.Format("SELECT LU_USER.USERNAME, SDB_SESSION.SESSIONSTART + ({0}/24) AS SESSIONSTART, SDB_SESSION.SESSIONEND + ({0}/24) AS SESSIONEND, LU_APPNAME.APPNAME, SDB_SESSION.PK_SDB_SESSIONID FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID INNER JOIN LU_APPNAME ON SDB_SESSION.FK_APPNAMEID = LU_APPNAME.PK_APPNAMEID WHERE (SDB_SESSION.SESSIONSTART BETWEEN To_Date('{2}', 'YYYY-MM-DD HH24:MI:SS') + ({1}/24) AND To_Date('{3}', 'YYYY-MM-DD HH24:MI:SS') + ({1}/24)) AND (LU_APPNAME.PK_APPNAMEID = NVL({4}, LU_APPNAME.PK_APPNAMEID))", utcOffset.ToString(), utcOffset2.ToString(), DateTime.Parse(strStartDate).ToString("yyyy-MM-dd HH:mm:ss"), DateTime.Parse(strEndDate).ToString("yyyy-MM-dd HH:mm:ss"), strAppID);
        }
        else
        {
            sqlHourDetail.SelectCommand = String.Format("SELECT LU_USER.USERNAME, DATEADD(hh, {0}, SDB_SESSION.SESSIONSTART) AS SESSIONSTART, DATEADD(hh, {0}, SDB_SESSION.SESSIONEND) AS SESSIONEND, LU_APPNAME.APPNAME, SDB_SESSION.PK_SDB_SESSIONID FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID INNER JOIN LU_APPNAME ON SDB_SESSION.FK_APPNAMEID = LU_APPNAME.PK_APPNAMEID WHERE (SDB_SESSION.SESSIONSTART BETWEEN DATEADD(hh, {1}, '{2}') AND DATEADD(hh, {1}, '{3}')) AND (LU_APPNAME.PK_APPNAMEID = ISNULL({4}, LU_APPNAME.PK_APPNAMEID))", utcOffset.ToString(), utcOffset2.ToString(), strStartDate, strEndDate, strAppID);
        }
    }


    protected void gvHourDetail_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='pointer';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", Resources.WIRM.ClickToViewSessionDetails);
            e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", gvHourDetail.DataKeys[e.Row.RowIndex].Value.ToString()));
        }
    }

    protected void lbExcelExport_Click(object sender, EventArgs e)
    {
        GridView gv = new GridView();
        gv.AllowPaging = false;
        gv.AllowSorting = false;
        gv.AutoGenerateColumns = false;

        foreach (DataControlField col in gvHourDetail.Columns)
        {
            if (col.HeaderText != String.Empty)
                gv.Columns.Add(col);
        }

        gv.DataSource = sqlHourDetail;
        GetData();
        gv.DataBind();

        Response.Clear();
        Response.AddHeader("content-disposition", "attachment;filename=Report_Export.xls");
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.xls";
        System.IO.StringWriter stringWrite = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
        gv.RenderControl(htmlWrite);
        Response.Write(stringWrite.ToString());
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
}
