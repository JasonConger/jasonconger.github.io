//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;

public partial class _Default : System.Web.UI.Page
{
    private Hashtable dayDetails;

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
            Resources.WIRM.UsageCalendar;

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.UsageCalendar;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/calendar.gif";

            // Set our view date to the first day of the current month.
            DateTime dtWorkingDate = DateTime.Now;
            int day = dtWorkingDate.Day;
            day = (day - 1) * -1;
            dtWorkingDate = dtWorkingDate.AddDays(day);
            rmCalendar.VisibleDate = dtWorkingDate;

            validateAppFilter.ErrorMessage = "<-- " + Resources.WIRM.PleaseSelectAnApplication;
            initialApplicationFilterDDL();
            loadDays();
        }
    }

    protected void rmCalendar_DayRender(object sender, DayRenderEventArgs e)
    {
        // Remove the default hyperlink for the day
        e.Day.IsSelectable = false;

        string strThisDay = e.Day.Date.ToShortDateString();

        if (dayDetails.ContainsKey(strThisDay))
        {
            DataAccess.dayDetail thisDay = (DataAccess.dayDetail)dayDetails[strThisDay];
            TableCell td = e.Cell;
            string strCellText = String.Format("<br /> <a href='hourlyBarChart.aspx?strDate={0}' class='sessionLink'>{2}: {1}</a>", thisDay.strDate, thisDay.intSessionCount.ToString(), Resources.WIRM.Users);

            if (ddlApplicationFilter.SelectedIndex != 0)
            {
                if (thisDay.intApplicationCount != 0)
                    strCellText += String.Format("<br /><br /> <a href='hourlyBarChart.aspx?strDate={0}&strAppID={1}&strAppName={2}' class='appLink'>{2}: {3}</a>", thisDay.strDate, ddlApplicationFilter.SelectedValue, ddlApplicationFilter.SelectedItem, thisDay.intApplicationCount.ToString());
            }

            LiteralControl lcCellControl = new LiteralControl(strCellText);
            td.Controls.Add(lcCellControl);
        }

    }

    protected void loadDays()
    {
        float utcOffset = float.Parse(Session["utcOffset"].ToString());

        // Start our query 7 days before the start of the month
        DateTime startDate = rmCalendar.VisibleDate.AddDays(-7);

        int appID = 0;
        if (ddlApplicationFilter.SelectedIndex != 0)
            appID = Int32.Parse(ddlApplicationFilter.SelectedValue);
            

        DataAccess da = new DataAccess();
        dayDetails = da.getCalendarData(utcOffset, startDate, appID);
    }

    protected void rmCalendar_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
    {
        initialApplicationFilterDDL();
        loadDays();
    }

    protected void initialApplicationFilterDDL()
    {
        ddlApplicationFilter.Items.Clear();
        ddlApplicationFilter.Items.Add(Resources.WIRM.SelectApplication);
        
        DateTime startDate = rmCalendar.VisibleDate.Subtract(new TimeSpan(7, 0, 0, 0));

        sqlApplicationFilter.SelectCommand = DataAccess.getApplicationsFilter(startDate);
    }

    protected void validateAppFilter_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (ddlApplicationFilter.SelectedIndex == 0)
            args.IsValid = false;
    }

    protected void btnApplicationFilter_Click(object sender, EventArgs e)
    {
        loadDays();
    }
}
