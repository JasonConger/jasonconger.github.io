//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class serversMetrics : System.Web.UI.Page
{
    private string strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
                Resources.WIRM.ServerMetricsReport;

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.ServerMetricsReport;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/server.gif";

            if (Request.QueryString["d"] != null)
                tbDate.Text = DateTime.Parse(Request.QueryString["d"]).ToShortDateString();
            else
                tbDate.Text = DateTime.Now.AddDays(-1).ToShortDateString();
            
            
            imgDate.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbDate.ClientID + "'), null, PickerParams, true)};");

            loadServerDDL();
            loadObjectDDL();
            loadInstanceDDL();
            loadCounterDDL();
            loadStatDDL();
        }
        ClientScript.RegisterClientScriptBlock(this.GetType(), "calendarOption", DatePicker.getCalendarOptions(DateTime.Parse(Session["maxDateExtreme"].ToString()), DateTime.Parse(Session["minDateExtreme"].ToString())));
    }

    private void loadStatDDL()
    {
        ddlStat.Items.Add(new ListItem(Resources.WIRM.Maximum, "MAXMETRICVALUE"));
        ddlStat.Items.Add(new ListItem(Resources.WIRM.Minimum, "MINMETRICVALUE"));
        ddlStat.Items.Add(new ListItem(Resources.WIRM.Mean, "MEANMETRICVALUE"));
        ddlStat.Items.Add(new ListItem(Resources.WIRM.StandardDeviation, "STDDEVMETRICVALUE"));
    }

    protected void ddlInstance_DataBound(object sender, EventArgs e)
    {
        if (ddlServers.Items.Count == 0)
        {
            throw new Exception("Could not enumerate instances.");
        }

        if ((ddlInstance.Items.Count == 1) && (ddlInstance.Items[0].Text.Trim() == String.Empty))
            ddlInstance.Attributes.Add("style", "display: none");
        else
            ddlInstance.Attributes.Add("style", "display: inline");
    }

    protected void loadServerDDL()
    {
        sqlServers.ProviderName = strProvider;
        sqlServers.SelectCommand = "SELECT LU_SERVERNAME.SERVERNAME, LU_SERVER.PK_SERVERID FROM LU_SERVER INNER JOIN LU_SERVERNAME ON LU_SERVER.FK_SERVERNAMEID = LU_SERVERNAME.PK_SERVERNAMEID ORDER BY LU_SERVERNAME.SERVERNAME";

        try
        {
            ddlServers.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write("Error: <br />" + sqlServers.SelectCommand + "<br />" + ex.Message);
            Response.End();
        }
    }

    protected void loadObjectDDL()
    {
        sqlObject.ProviderName = strProvider;
        sqlObject.SelectCommand = "SELECT PK_OBJECTID, OBJECT FROM LU_OBJECT ORDER BY OBJECT";

        try
        {
            ddlObject.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write("Error: <br />" + sqlObject.SelectCommand + "<br />" + ex.Message);
            Response.End();
        }
    }

    protected void loadInstanceDDL()
    {
        sqlInstance.ProviderName = strProvider;
        string strSql = String.Format("SELECT DISTINCT LU_INSTANCE.INSTANCE, LU_INSTANCE.PK_INSTANCEID FROM LU_INSTANCE INNER JOIN LU_METRIC ON LU_INSTANCE.PK_INSTANCEID = LU_METRIC.FK_INSTANCEID WHERE (LU_METRIC.FK_OBJECTID = {0})", ddlObject.SelectedValue);
        sqlInstance.SelectCommand = strSql;
        
        try
        {
            ddlInstance.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write("Error: <br />" + strSql + "<br />" + ex.Message);
            Response.End();
        }

    }

    protected void loadCounterDDL()
    {
        sqlCounter.ProviderName = strProvider;
        string strSql = String.Format("SELECT DISTINCT LU_METRICCOUNTER.PK_METRICCOUNTERID, LU_METRICCOUNTER.METRICCOUNTER FROM LU_METRICCOUNTER INNER JOIN LU_METRIC ON LU_METRICCOUNTER.PK_METRICCOUNTERID = LU_METRIC.FK_METRICCOUNTERID WHERE (LU_METRIC.FK_OBJECTID = '{0}')", ddlObject.SelectedValue);
        sqlCounter.SelectCommand = strSql;
        
        try
        {
            ddlCounter.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write("Error: <br />" + strSql + "<br />" + ex.Message);
            Response.End();
        }
    }

    protected void ddlServers_DataBound(object sender, EventArgs e)
    {
        if (ddlServers.Items.Count == 0)
        {
            throw new Exception("Could not enumerate servers.");
        }

        if (Request.QueryString["n"] != null)
            ddlServers.SelectedIndex = ddlServers.Items.IndexOf(ddlServers.Items.FindByText(Request.QueryString["n"]));
    }

    protected void ddlObject_DataBound(object sender, EventArgs e)
    {
        if (ddlServers.Items.Count == 0)
        {
            throw new Exception("Could not enumerate objects.");
        }

        ListItem li = ddlObject.Items.FindByText("Processor");

        if (ddlObject.Items.Contains(li))
            ddlObject.SelectedIndex = ddlObject.Items.IndexOf(li);
    }

    protected void ddlObject_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadInstanceDDL();
        loadCounterDDL();
    }

    protected void ddlCounter_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadInstanceDDL();
    }
}
