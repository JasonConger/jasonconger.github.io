//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class applicationReport : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
                Resources.WIRM.ApplicationUsageReport;

        if (!IsPostBack)
        {
            Master.Page.Form.DefaultButton = btnAppFilter.UniqueID;

            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.ApplicationUsageReport;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/application.gif";

            imgFrom.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbFrom.ClientID + "'), null, PickerParams, true)};");
            imgTo.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbTo.ClientID + "'), null, PickerParams, true)};");

            DateTime dtLast30 = DateTime.Parse(Session["maxDateExtreme"].ToString()).AddDays(-30);
            tbFrom.Text = dtLast30.ToShortDateString();
            tbTo.Text = Session["maxDateExtreme"].ToString();

            Chart.loadChartDDL(ddlChartType);
            getData(gvApplications);

            lblFrom.Text += ":";
            lblTo.Text += ":";
        }

        

        ClientScript.RegisterClientScriptBlock(this.GetType(), "calendarOption", DatePicker.getCalendarOptions(DateTime.Parse(Session["maxDateExtreme"].ToString()), DateTime.Parse(Session["minDateExtreme"].ToString())));
    }

    protected string getChartData()
    {
        Chart appChart = new Chart();

        try
        {
            DataView dv = ((DataTable)Session["dtConcurrentApps"]).DefaultView;
            dv.Sort = "mx DESC";
            return appChart.getApplicationXML(dv, Int32.Parse(ddlTop.SelectedValue));
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            return String.Empty;
        }
    }

    protected void btnAppFilter_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            getData(gvApplications);
        }
    }

    protected void getData(GridView gv)
    {
        try
        {
            DateTime dtStart = DateTime.Parse(tbFrom.Text);
            DateTime dtEnd = DateTime.Parse(tbTo.Text);
            jcc.conuse t = new jcc.conuse();
            t.UtcOffset = float.Parse(Session["utcOffset"].ToString());
            t.ConnectionString = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString;
            t.Provider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;
            DataTable dt = t.getConcurrentApplication(dtStart, dtEnd);

            Session["dtConcurrentApps"] = dt;

            gv.DataSource = dt;
            gv.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    // Paging Helper
    protected void gvApplications_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        DataTable dtApps = (DataTable)Session["dtConcurrentApps"];
        gvApplications.PageIndex = e.NewPageIndex;
        gvApplications.DataSource = dtApps;
        gvApplications.DataBind();
    }

    // Sorting Helper
    protected void gvApplications_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExpression = e.SortExpression;

        if (sortExpression == "Excel")
            return;

        if (gvSortDirection == SortDirection.Ascending)
        {
            gvSortDirection = SortDirection.Descending;
            SortGridView(sortExpression, " DESC");
        }
        else
        {
            gvSortDirection = SortDirection.Ascending;
            SortGridView(sortExpression, " ASC");
        }
    }

    public SortDirection gvSortDirection
    {
        get
        {
            if (ViewState["sortDirection"] == null)
                ViewState["sortDirection"] = SortDirection.Ascending;

            return (SortDirection)ViewState["sortDirection"];
        }

        set { ViewState["sortDirection"] = value; }
    }

    private void SortGridView(string sortExpression, string direction)
    {
        DataTable dt = (DataTable)Session["dtConcurrentApps"];
        DataView dv = new DataView(dt);
        dv.Sort = sortExpression + direction;
        gvApplications.DataSource = dv;
        gvApplications.DataBind();
    }

    // Custom Validators
    protected void cvFromDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbFrom.Text);
    }

    protected void cvToDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbTo.Text);
    }

    protected void cvDateCompare_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (cvFromDate.IsValid && cvToDate.IsValid)
        {
            if (DateTime.Parse(tbFrom.Text) > DateTime.Parse(tbTo.Text))
                args.IsValid = false;
        }
    }

    // Custom Validator Helper
    protected bool checkDateTime(string strDateTime)
    {
        try
        {
            DateTime.Parse(strDateTime);
            return true;
        }
        catch
        {
            return false;
        }
    }

    protected void ddlChartType_SelectedIndexChanged(object sender, EventArgs e)
    {
        switch (ddlChartType.SelectedValue)
        {
            case "FC2Column.swf":
                this.imgGraph.ImageUrl = "~/images/columnGraphIcon.gif";
                break;

            case "FC2Pie3D.swf":
                this.imgGraph.ImageUrl = "~/images/pieGraphIcon.gif";
                break;
        }
    }

    protected void gvApplications_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (e.Row.Cells[0].Text.Trim() == String.Empty)
                e.Row.Cells[0].Text = "RDP";
        }
    }

    protected void lbExcelExport_Click(object sender, EventArgs e)
    {
        GridView gv = new GridView();
        gv.AllowPaging = false;
        gv.AllowSorting = false;
        gv.AutoGenerateColumns = false;

        foreach (DataControlField col in gvApplications.Columns)
        {
            if (col.HeaderText != String.Empty)
                gv.Columns.Add(col);
        }

        gv.DataSource = (DataTable)Session["dtConcurrentApps"];
        gv.DataBind();

        Response.Clear();
        Response.AddHeader("content-disposition", "attachment;filename=Report_Export.xls");
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.xls";
        System.IO.StringWriter stringWrite = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
        gv.RenderControl(htmlWrite);
        Response.Write(stringWrite.ToString());
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
}
