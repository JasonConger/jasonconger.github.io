//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
// Date:    April 24th, 2006
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class applicationReport : System.Web.UI.Page
{

    public string strChartType = "FC2Pie3D.swf";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Application Usage Report";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/graph.gif";


        }
    }

    protected string getChartData()
    {

        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlDataReader sqlDR;
        SqlCommand sqlCmd;

        string strSQL = String.Empty;
        string strRetXML = String.Empty;

        // Setup XML for pie chart
        strRetXML = "<graph ";
        strRetXML += "Bgcolor='ffffff' ";
        strRetXML += "canvasbgcolor='ececec' ";
        strRetXML += "xaxisname='Application' ";
        strRetXML += "caption='Top 5 Applications' ";
        strRetXML += "basefont='Verdana' ";
        strRetXML += "bastfontsize='12px' ";
        strRetXML += "outcnvbasefontsize='12px' ";
        strRetXML += "legendboxbgcolor='ececec' ";
        strRetXML += "legendboxbrdcolor='000000' ";
        strRetXML += "showValues='0' ";
        strRetXML += "decimalPrecision='0' ";
        strRetXML += "animation='0' ";

        // Set hover options
        strRetXML += "hovercapbg='f5f5f5' ";
        strRetXML += "hovercapborder='c0c0c0' ";
        strRetXML += "hovercapSepChar=' - frequency:' ";
        strRetXML += "showhovercap='1' ";
        strRetXML += ">";

        // Connect to the RM summary database
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        sqlConn.Open();

        try
        {
            // Array to hold slice colors
            string[] colors = new string[5] { "3682EE", "FCAC36", "FF4F00", "025988", "B9B9B9" };
            int x = 0;
            string strIsSliced = String.Empty;

            strSQL = "SELECT TOP 5 LU_APPNAME.APPNAME, COUNT(SDB_SESSION.FK_APPNAMEID) AS APP_FREQ FROM LU_APPNAME, SDB_SESSION WHERE (SDB_SESSION.FK_APPNAMEID = LU_APPNAME.PK_APPNAMEID) AND (LU_APPNAME.APPNAME <> ' ') GROUP BY LU_APPNAME.APPNAME ORDER BY APP_FREQ DESC";
            sqlCmd = new SqlCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            while (sqlDR.Read())
            {
                string strAppName = sqlDR["APPNAME"].ToString();
                string strAppFreq = sqlDR["APP_FREQ"].ToString();

                if (x == 0)
                    strIsSliced = "isSliced='1'";
                else
                    strIsSliced = String.Empty;

                strRetXML += String.Format("<set value='{0}' name='{1}' color='{2}' {3} />", strAppFreq, strAppName, colors[x++], strIsSliced);
            }

        }
        catch (Exception ex)
        {
            strRetXML += String.Format("<set name='Error: {0}' value='0'>", ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }


        strRetXML += "</graph>";

        return strRetXML;
    }

    protected void btnPieChart_Click(object sender, EventArgs e)
    {
        strChartType = "FC2Pie3D.swf";
    }

    protected void btnColumnChart_Click(object sender, EventArgs e)
    {
        strChartType = "FC2Column.swf";
    }
}
