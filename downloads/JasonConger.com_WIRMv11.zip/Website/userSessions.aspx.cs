using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class userDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += String.Format(" - Sessions started by {0}.", Request["strUsername"]);

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";
        }
    }

    protected void gvUserDetail_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='hand';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", "Click to view session details . . .");
            e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", gvUserDetail.DataKeys[e.Row.RowIndex].Value.ToString()));
        }
    }
}
