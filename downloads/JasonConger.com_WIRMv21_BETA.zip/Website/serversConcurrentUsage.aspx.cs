//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class serversConcurrentUsage : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
                Resources.WIRM.ServerUsageReport;

        if (!IsPostBack)
        {
            Master.Page.Form.DefaultButton = btnServerFilter.UniqueID;

            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += String.Format(" - {0} ({1})", Resources.WIRM.ServerUsageReport, Resources.WIRM.ConcurrentUsage);

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/server.gif";

            imgFrom.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbFrom.ClientID + "'), null, PickerParams, true)};");
            imgTo.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbTo.ClientID + "'), null, PickerParams, true)};");

            DateTime dtLast30 = DateTime.Now.Subtract(new TimeSpan(30, 0, 0, 0));
            tbFrom.Text = dtLast30.ToString("dd-MMM-yyyy");
            tbTo.Text = Session["maxDateExtreme"].ToString();

            getData();
        }

        ClientScript.RegisterClientScriptBlock(this.GetType(), "calendarOption", DatePicker.getCalendarOptions(DateTime.Parse(Session["maxDateExtreme"].ToString()), DateTime.Parse(Session["minDateExtreme"].ToString())));
    }

    protected void btnServerFilter_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            getData();
        }
    }

    protected void getData()
    {
        try
        {
            DateTime dtStart = DateTime.Parse(tbFrom.Text);
            DateTime dtEnd = DateTime.Parse(tbTo.Text);
            jcc.conuse t = new jcc.conuse();
            t.ConnectionString = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString;
            t.Provider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;
            t.UtcOffset = float.Parse(Session["utcOffset"].ToString());
            DataTable dt = t.getConcurrentServer(dtStart, dtEnd);

            Session["dtConcurrentServers"] = dt;

            gvServers.DataSource = dt;
            gvServers.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }


    // Sorting Helper
    protected void gvServers_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExpression = e.SortExpression;

        if (sortExpression == "Excel")
            return;

        if (gvSortDirection == SortDirection.Ascending)
        {
            gvSortDirection = SortDirection.Descending;
            SortGridView(sortExpression, " DESC");
        }
        else
        {
            gvSortDirection = SortDirection.Ascending;
            SortGridView(sortExpression, " ASC");
        }
    }

    public SortDirection gvSortDirection
    {
        get
        {
            if (ViewState["sortDirection"] == null)
                ViewState["sortDirection"] = SortDirection.Ascending;

            return (SortDirection)ViewState["sortDirection"];
        }

        set { ViewState["sortDirection"] = value; }
    }

    private void SortGridView(string sortExpression, string direction)
    {
        DataTable dt = (DataTable)Session["dtConcurrentServers"];
        DataView dv = new DataView(dt);
        dv.Sort = sortExpression + direction;
        gvServers.DataSource = dv;
        gvServers.DataBind();
    }

    // Custom Validators
    protected void cvFromDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbFrom.Text);
    }

    protected void cvToDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbTo.Text);
    }

    protected void cvDateCompare_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (cvFromDate.IsValid && cvToDate.IsValid)
        {
            if (DateTime.Parse(tbFrom.Text) > DateTime.Parse(tbTo.Text))
                args.IsValid = false;
        }
    }

    // Custom Validator Helper
    protected bool checkDateTime(string strDateTime)
    {
        try
        {
            DateTime.Parse(strDateTime);
            return true;
        }
        catch
        {
            return false;
        }
    }
    protected void gvServers_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
                e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='pointer';");
                e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
                e.Row.Attributes.Add("title", String.Format("{0} {1}. . .", Resources.WIRM.ClickToViewServerMetricsOn, e.Row.Cells[2].Text));
                e.Row.Attributes.Add("onClick", String.Format("location.href='serversMetrics.aspx?n={0}&d={1}'", e.Row.Cells[0].Text, e.Row.Cells[2].Text));
        }
    }
}
