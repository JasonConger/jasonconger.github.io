//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class clientsByUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.Page.Title = Resources.WIRM.WebInterfaceRM + " - " +
                Resources.WIRM.ClientsByUser;

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - " + Resources.WIRM.ClientsByUser;

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";
        }

        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        getData();

        gvClientsByUser.Width = 550;
    }

    protected void getData()
    {
        string strClientTypeID = Request.QueryString["c"];
        string strClientVersion = Request.QueryString["v"];
        string strClientBuild = Request.QueryString["b"];
        float utcOffset = float.Parse(Session["utcoffset"].ToString());
        string strProvider = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ProviderName;

        switch (strProvider)
        {
            case "System.Data.OracleClient":
                sqlClientsByUser.ProviderName = strProvider;
                sqlClientsByUser.SelectCommand = String.Format(
                    "SELECT DISTINCT T.NETDOMAIN, T.USERNAME, " +
                    "T.LAST_USED + ({3}/24) AS LAST_USED, " +
                    "MAX(SDB_SESSION_1.PK_SDB_SESSIONID) AS SESSIONID " +
                    "FROM (SELECT LU_NETDOMAIN.NETDOMAIN, LU_USER.USERNAME, " +
                    "MAX(SDB_SESSION.SESSIONSTART) AS LAST_USED " +
                    "FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID " +
                    "INNER JOIN SDB_CLIENTHISTORY ON SDB_SESSION.PK_SDB_SESSIONID = SDB_CLIENTHISTORY.FK_SDB_SESSIONID " +
                    "INNER JOIN LU_CLIENTPROPERTIES ON SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID = LU_CLIENTPROPERTIES.PK_CLIENTPROPERTIESID " +
                    "INNER JOIN LU_NETDOMAIN ON LU_USER.FK_NETDOMAINID = LU_NETDOMAIN.PK_NETDOMAINID " +
                    "WHERE (LU_CLIENTPROPERTIES.FK_CLIENTTYPEID = '{0}') " +
                    "AND (LU_CLIENTPROPERTIES.VERSION = '{1}') " +
                    "AND (LU_CLIENTPROPERTIES.BUILD = '{2}') " +
                    "GROUP BY LU_NETDOMAIN.NETDOMAIN, LU_USER.USERNAME) T " +
                    "INNER JOIN SDB_SESSION SDB_SESSION_1 ON T.LAST_USED = SDB_SESSION_1.SESSIONSTART " +
                    "INNER JOIN SDB_CLIENTHISTORY SDB_CLIENTHISTORY_1 ON SDB_SESSION_1.PK_SDB_SESSIONID = SDB_CLIENTHISTORY_1.FK_SDB_SESSIONID " +
                    "GROUP BY T.NETDOMAIN, T.USERNAME, T.LAST_USED " +
                    "ORDER BY T.NETDOMAIN, T.USERNAME",
                    strClientTypeID,
                    strClientVersion,
                    strClientBuild,
                    utcOffset);
                break;
            default:
                sqlClientsByUser.SelectCommand = String.Format(
                    "SELECT DISTINCT T.NETDOMAIN, T.USERNAME, " +
                    "DATEADD(hh, {3}, T.LAST_USED) AS LAST_USED, " +
                    "MAX(SDB_SESSION_1.PK_SDB_SESSIONID) AS SESSIONID " +
                    "FROM (SELECT LU_NETDOMAIN.NETDOMAIN, LU_USER.USERNAME, "+
                    "MAX(SDB_SESSION.SESSIONSTART) AS LAST_USED " +
                    "FROM LU_USER INNER JOIN SDB_SESSION ON LU_USER.PK_USERID = SDB_SESSION.FK_USERID " +
                    "INNER JOIN SDB_CLIENTHISTORY ON SDB_SESSION.PK_SDB_SESSIONID = SDB_CLIENTHISTORY.FK_SDB_SESSIONID " +
                    "INNER JOIN LU_CLIENTPROPERTIES ON SDB_CLIENTHISTORY.FK_CLIENTPROPERTIESID = LU_CLIENTPROPERTIES.PK_CLIENTPROPERTIESID " +
                    "INNER JOIN LU_NETDOMAIN ON LU_USER.FK_NETDOMAINID = LU_NETDOMAIN.PK_NETDOMAINID " +
                    "WHERE (LU_CLIENTPROPERTIES.FK_CLIENTTYPEID = '{0}') " +
                    "AND (LU_CLIENTPROPERTIES.VERSION = '{1}') " +
                    "AND (LU_CLIENTPROPERTIES.BUILD = '{2}') " +
                    "GROUP BY LU_NETDOMAIN.NETDOMAIN, LU_USER.USERNAME) AS T " +
                    "INNER JOIN SDB_SESSION AS SDB_SESSION_1 ON T.LAST_USED = SDB_SESSION_1.SESSIONSTART " +
                    "INNER JOIN SDB_CLIENTHISTORY AS SDB_CLIENTHISTORY_1 ON SDB_SESSION_1.PK_SDB_SESSIONID = SDB_CLIENTHISTORY_1.FK_SDB_SESSIONID " +
                    "GROUP BY T.NETDOMAIN, T.USERNAME, T.LAST_USED " +
                    "ORDER BY T.NETDOMAIN, T.USERNAME",
                    strClientTypeID,
                    strClientVersion,
                    strClientBuild,
                    utcOffset);
                break;
        }
    }

    protected void gvClientsByUser_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
            e.Row.Cells[3].Visible = false;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[3].Visible = false;
            string strSessionID = e.Row.Cells[3].Text;
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='pointer';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", Resources.WIRM.ClickToViewSessionDetails);
            e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", strSessionID));
        }
    }
}
