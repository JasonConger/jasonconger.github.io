using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class reportExport_applicationReportExcel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ApplicationsDataSet dsApps = (ApplicationsDataSet)Session["dsApps"];

        gvApplications.DataSource = dsApps.Applications;
        gvApplications.DataBind();

        Response.Clear();
        Response.AddHeader("content-disposition", "attachment;filename=Application_Report.xls");
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.xls";
        System.IO.StringWriter stringWrite = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
        gvApplications.RenderControl(htmlWrite);
        Response.Write(stringWrite.ToString());
        Response.End();

    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
}
