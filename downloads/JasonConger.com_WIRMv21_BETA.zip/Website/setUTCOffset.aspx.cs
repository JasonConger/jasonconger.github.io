using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class setUTCOffset : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Set a session variable for the UTC offset.
        // Note that a UTC offset specified in web.config takes precedence
        if (Session["utcOffset"] == null)
        {
            // Get UTC offset (if any) from web.config
            string strAppSettingUTCOffset = ConfigurationManager.AppSettings["TimeZoneUTCOffset"];
            string strClientUTCOffset = Request["clientUTCOffset"];

            if (strClientUTCOffset != null && strClientUTCOffset.Trim() == String.Empty)
                Response.Redirect("Default.aspx");

            if (strAppSettingUTCOffset.Trim() != string.Empty)
                Session["utcOffset"] = strAppSettingUTCOffset;
            else
                Session["utcOffset"] = strClientUTCOffset;
        }

        string strConnectionString = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString;

        if (strConnectionString == String.Empty ||
            strConnectionString == null ||
            strConnectionString.Contains("Data Source=;"))
        {
            Response.Redirect("Configure.aspx");
        }
        else
        {
            Response.Redirect(Request.QueryString["redirect"]);
        }

    }
}
