//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class applicationReport : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Master.Page.Form.DefaultButton = btnAppFilter.UniqueID;

            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Application Usage Report (Concurrent Usage)";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/application.gif";

            imgFrom.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbFrom.ClientID + "'), null, PickerParams, true)};");
            imgTo.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbTo.ClientID + "'), null, PickerParams, true)};");

            DateTime dtLast30 = DateTime.Now.Subtract(new TimeSpan(30, 0, 0, 0));
            tbFrom.Text = dtLast30.ToString("dd-MMM-yyyy");
            tbTo.Text = Session["maxDateExtreme"].ToString();

            getData();
        }

        ClientScript.RegisterClientScriptBlock(this.GetType(), "calendarOption", DatePicker.getCalendarOptions(DateTime.Parse(Session["maxDateExtreme"].ToString()), DateTime.Parse(Session["minDateExtreme"].ToString())));
    }

    protected string getChartData()
    {
        Chart appChart = new Chart();

        DataView dv = ((DataTable)Session["dtConcurrentApps"]).DefaultView;
        dv.Sort = "mx DESC";

        return appChart.getApplicationXML(dv, Int32.Parse(ddlTop.SelectedValue));
    }

    protected void btnAppFilter_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            getData();
        }
    }

    protected void getData()
    {
        try
        {
            DateTime dtStart = DateTime.Parse(tbFrom.Text);
            DateTime dtEnd = DateTime.Parse(tbTo.Text);
            jcc.conuse t = new jcc.conuse();
            t.ConnectionString = ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString;
            DataTable dt = t.getConcurrentApplication(dtStart, dtEnd);

            Session["dtConcurrentApps"] = dt;

            gvApplications.DataSource = dt;
            gvApplications.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    // Paging Helper
    protected void gvApplications_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        DataTable dtApps = (DataTable)Session["dtConcurrentApps"];
        gvApplications.PageIndex = e.NewPageIndex;
        gvApplications.DataSource = dtApps;
        gvApplications.DataBind();
    }

    // Sorting Helper
    protected void gvApplications_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExpression = e.SortExpression;

        if (sortExpression == "Excel")
            return;

        if (gvSortDirection == SortDirection.Ascending)
        {
            gvSortDirection = SortDirection.Descending;
            SortGridView(sortExpression, " DESC");
        }
        else
        {
            gvSortDirection = SortDirection.Ascending;
            SortGridView(sortExpression, " ASC");
        }
    }

    public SortDirection gvSortDirection
    {
        get
        {
            if (ViewState["sortDirection"] == null)
                ViewState["sortDirection"] = SortDirection.Ascending;

            return (SortDirection)ViewState["sortDirection"];
        }

        set { ViewState["sortDirection"] = value; }
    }

    private void SortGridView(string sortExpression, string direction)
    {
        DataTable dt = (DataTable)Session["dtConcurrentApps"];
        DataView dv = new DataView(dt);
        dv.Sort = sortExpression + direction;
        gvApplications.DataSource = dv;
        gvApplications.DataBind();
    }

    // Custom Validators
    protected void cvFromDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbFrom.Text);
    }

    protected void cvToDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbTo.Text);
    }

    protected void cvDateCompare_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (cvFromDate.IsValid && cvToDate.IsValid)
        {
            if (DateTime.Parse(tbFrom.Text) > DateTime.Parse(tbTo.Text))
                args.IsValid = false;
        }
    }

    // Custom Validator Helper
    protected bool checkDateTime(string strDateTime)
    {
        try
        {
            DateTime.Parse(strDateTime);
            return true;
        }
        catch
        {
            return false;
        }
    }

    protected void ddlChartType_SelectedIndexChanged(object sender, EventArgs e)
    {
        switch (ddlChartType.SelectedValue)
        {
            case "FC2Column.swf":
                this.imgGraph.ImageUrl = "~/images/columnGraphIcon.gif";
                break;

            case "FC2Pie3D.swf":
                this.imgGraph.ImageUrl = "~/images/pieGraphIcon.gif";
                break;
        }
    }
}
