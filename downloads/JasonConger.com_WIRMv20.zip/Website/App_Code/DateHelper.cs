using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DateHelper
/// </summary>
public class DateHelper
{
    private string minDateExtreme;
    private string maxDateExtreme;

	public DateHelper(float utcOffset)
	{
        // Set up SQL connection parameters
        SqlConnection sqlConn;
        SqlDataReader sqlDR;
        SqlCommand sqlCmd;
        string strSQL = String.Empty;

        // Connect to the RM summary database
        sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        sqlConn.Open();

        try
        {
            strSQL = "SELECT MAX(DATEADD(hh, " + utcOffset + ", SESSIONSTART)) AS MAX_DATE, MIN(DATEADD(hh, " + utcOffset + ", SESSIONSTART)) AS MIN_DATE FROM SDB_SESSION";
            sqlCmd = new SqlCommand(strSQL, sqlConn);
            sqlDR = sqlCmd.ExecuteReader();

            sqlDR.Read();

            this.maxDateExtreme = DateTime.Parse(sqlDR["MAX_DATE"].ToString()).ToString("dd-MMM-yyyy");
            this.minDateExtreme = DateTime.Parse(sqlDR["MIN_DATE"].ToString()).ToString("dd-MMM-yyyy");
        }
        catch
        {
            this.maxDateExtreme = DateTime.Now.ToString("dd-MMM-yyyy");
            this.minDateExtreme = DateTime.Now.ToString("dd-MMM-yyyy");
        }
        finally
        {
            sqlConn.Close();
        }
    }

    public string MinDateExtreme
    {
        get { return minDateExtreme; }
        set { }
    }

    public string MaxDateExtreme
    {
        get { return maxDateExtreme; }
        set { }
    }
}
