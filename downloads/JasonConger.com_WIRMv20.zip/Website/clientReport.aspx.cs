//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class clientReport : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Master.Page.Form.DefaultButton = btnClientFilter.UniqueID;

            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Client Report";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";

            imgFrom.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbFrom.ClientID + "'), null, PickerParams, true)};");
            imgTo.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbTo.ClientID + "'), null, PickerParams, true)};");

            tbFrom.Text = Session["minDateExtreme"].ToString();
            tbTo.Text = Session["maxDateExtreme"].ToString();

            getData();
        }

        ClientScript.RegisterClientScriptBlock(this.GetType(), "calendarOption", DatePicker.getCalendarOptions(DateTime.Parse(Session["maxDateExtreme"].ToString()), DateTime.Parse(Session["minDateExtreme"].ToString())));
    }

    protected string getChartData()
    {
        string strRetXML = String.Empty;

        // Setup XML for pie chart
        strRetXML = "<graph ";
        strRetXML += "Bgcolor='ffffff' ";
        strRetXML += "canvasbgcolor='ececec' ";
        strRetXML += "xaxisname='Client' ";
        strRetXML += "basefont='Verdana' ";
        strRetXML += "bastfontsize='12px' ";
        strRetXML += "outcnvbasefontsize='12px' ";
        strRetXML += "legendboxbgcolor='ececec' ";
        strRetXML += "legendboxbrdcolor='000000' ";
        strRetXML += "showValues='0' ";
        strRetXML += "decimalPrecision='0' ";
        strRetXML += "animation='0' ";

        // Set hover options
        strRetXML += "hovercapbg='f5f5f5' ";
        strRetXML += "hovercapborder='c0c0c0' ";
        strRetXML += "hovercapSepChar=' - frequency:' ";
        strRetXML += "showhovercap='1' ";
        strRetXML += ">";

        // Array to hold slice colors
        string[] colors = new string[10] { "9BBDDE", "FFBC46", "A2C488", "D6B9DB", "CDC785", "DEA19B", "B9DBCF", "FFDC46", "9B88C4", "85CD9B" };

        string strIsSliced = String.Empty;

        ClientsDataSet dsClients = (ClientsDataSet)Session["dsClients"];

        for (int i = 0; i < Int32.Parse(ddlTop.SelectedValue) && i < dsClients._Clients.Rows.Count; i++)
        {
            ClientsDataSet.ClientsRow row = dsClients._Clients[i];

            string strClientName;
            strClientName = row.CLIENT_NAME.Replace("ICA ", String.Empty) + " ";

            if (row.VERSION.Trim() == String.Empty)
            {
                strClientName += " No Version (Build: " + row.BUILD + ")";
            }
            else
            {
                strClientName += row.VERSION;
            }

            string strClientFreq = row.FREQ.ToString();

            if (i == 0)
                strIsSliced = "isSliced='1'";
            else
                strIsSliced = String.Empty;

            strRetXML += String.Format("<set value='{0}' name='{1}' color='{2}' {3} />", strClientFreq, strClientName, colors[i], strIsSliced);
        }

        strRetXML += "</graph>";

        return strRetXML;
    }

    protected void gvClients_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        e.Row.Cells[5].Visible = false;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string strClientVersion = e.Row.Cells[1].Text;
            string strClientBuild = e.Row.Cells[2].Text;
            string strClientTypeId = e.Row.Cells[5].Text;

            string strClientName = e.Row.Cells[0].Text + " ";
            
            if (e.Row.Cells[1].Text.Trim() == String.Empty)
            {
                strClientName += " No Version (Build: " + e.Row.Cells[2].Text + ")";
            }
            else
            {
                strClientName += e.Row.Cells[1].Text;
            }

            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this);");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            //e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", gvHourDetail.DataKeys[e.Row.RowIndex].Value.ToString()));
            ImageButton btnPerson = (ImageButton)e.Row.Cells[4].FindControl("btnPerson");
            btnPerson.ToolTip = String.Format("Show all users that have used the {0} client.", strClientName.Replace("ICA ", String.Empty));
            btnPerson.PostBackUrl = String.Format("clientsByUser.aspx?c={0}&v={1}&b={2}", strClientTypeId, strClientVersion, strClientBuild);
        }
    }

    protected void getData()
    {
        string strFrom = tbFrom.Text;
        string strTo = tbTo.Text;
        if (strFrom == strTo)
        {
            if (!strFrom.Contains(":"))
            {
                strFrom += " 00:00:00";
                strTo += " 23:59:59";
            }
        }
        ClientsDataSet dsClients = new ClientsDataSet();
        ClientsDataSetTableAdapters.ClientsTableAdapter da = new ClientsDataSetTableAdapters.ClientsTableAdapter();

        try
        {
            da.Fill(dsClients._Clients, DateTime.Parse(strFrom), DateTime.Parse(strTo));    
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

        Session["dsClients"] = dsClients;

        gvClients.DataSource = dsClients._Clients;
        gvClients.DataBind();
        
    }

    protected void btnClientFilter_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            getData();
        }
    }

    // Sorting Helper
    protected void gvClients_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExpression = e.SortExpression;
        if (gvSortDirection == SortDirection.Ascending)
        {
            gvSortDirection = SortDirection.Descending;
            SortGridView(sortExpression, " DESC");
        }
        else
        {
            gvSortDirection = SortDirection.Ascending;
            SortGridView(sortExpression, " ASC");
        }
    }

    public SortDirection gvSortDirection
    {
        get
        {
            if (ViewState["sortDirection"] == null)
                ViewState["sortDirection"] = SortDirection.Ascending;

            return (SortDirection)ViewState["sortDirection"];
        }

        set { ViewState["sortDirection"] = value; }
    }

    private void SortGridView(string sortExpression, string direction)
    {
        ClientsDataSet dsClients = (ClientsDataSet)Session["dsClients"];
        DataTable dt = dsClients._Clients;
        DataView dv = new DataView(dt);
        dv.Sort = sortExpression + direction;
        gvClients.DataSource = dv;
        gvClients.DataBind();
    }
    
    // Custom Validators
    protected void cvFromDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbFrom.Text);
    }

    protected void cvToDate_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = checkDateTime(tbTo.Text);
    }

    protected void cvDateCompare_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (cvFromDate.IsValid && cvToDate.IsValid)
        {
            if (DateTime.Parse(tbFrom.Text) > DateTime.Parse(tbTo.Text))
                args.IsValid = false;
        }
    }

    // Custom Validator Helper
    protected bool checkDateTime(string strDateTime)
    {
        try
        {
            DateTime.Parse(strDateTime);
            return true;
        }
        catch
        {
            return false;
        }
    }

    protected void ddlChartType_SelectedIndexChanged(object sender, EventArgs e)
    {
        switch (ddlChartType.SelectedValue)
        {
            case "Column Chart":
                this.imgGraph.ImageUrl = "~/images/columnGraphIcon.gif";
                break;

            case "Pie Chart":
                this.imgGraph.ImageUrl = "~/images/pieGraphIcon.gif";
                break;
        }
    }
}
