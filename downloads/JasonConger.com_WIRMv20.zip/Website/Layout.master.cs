//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        hlApplications.Attributes.Add("onClick", "toggleList('appReports', 'appPlusMinus')");
        hlServers.Attributes.Add("onClick", "toggleList('serverReports', 'serverPlusMinus')");

        if ((Session["extremeStart"] == null) || (Session["extremeEnd"] == null))
        {
            if (Session["utcOffset"] != null)
            {
                DateHelper dh = new DateHelper(float.Parse(Session["utcOffset"].ToString()));
                Session["minDateExtreme"] = dh.MinDateExtreme;
                Session["maxDateExtreme"] = dh.MaxDateExtreme;
            }
            else
            {
                throw new Exception("Error getting dates: UTC Offset is not set");
            }
        }
    }
}
