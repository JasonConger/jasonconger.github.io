//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class serversMetrics : System.Web.UI.Page
{
    public string strChartXML;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - Server Metrics Report";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/server.gif";

            if (Request.QueryString["d"] != null)
                tbDate.Text = DateTime.Parse(Request.QueryString["d"]).ToString("dd-MMM-yyyy");
            else
                tbDate.Text = DateTime.Now.AddDays(-1).ToString("dd-MMM-yyyy");

            imgDate.Attributes.Add("onclick", "if(window.basicDatePickerButtonElementClick){basicDatePickerButtonElementClick(this, document.getElementById('" + tbDate.ClientID + "'), null, PickerParams, true)};");
        }

        ClientScript.RegisterClientScriptBlock(this.GetType(), "calendarOption", DatePicker.getCalendarOptions(DateTime.Parse(Session["maxDateExtreme"].ToString()), DateTime.Parse(Session["minDateExtreme"].ToString())));
    }

    protected void ddlInstance_DataBound(object sender, EventArgs e)
    {
        if ((ddlInstance.Items.Count == 1) && (ddlInstance.Items[0].Text.Trim() == String.Empty))
            ddlInstance.Attributes.Add("style", "display: none");
        else
            ddlInstance.Attributes.Add("style", "display: inline");
    }

    protected string getChartData()
    {
        string strXML = String.Empty;

        if (tbDate.Text.Trim() == String.Empty)
        {
            return String.Empty;
        }

        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        float utcOffset = float.Parse(Session["utcOffset"].ToString());
        
        string strStartDate = String.Format("{0} 00:00:00", tbDate.Text);
        string strEndDate = String.Format("{0} 23:59:59", tbDate.Text);

        float utcOffset2 = utcOffset * -1;


        DataTable dtMetrics = new DataTable("Metrics");
        dtMetrics.Columns.Add("UpdateTime");
        dtMetrics.Columns.Add("DataCount");
        dtMetrics.Columns.Add("MinValue");
        dtMetrics.Columns.Add("MaxValue");

        string strSql = String.Format("SELECT DATEADD(hh, {6}, SDB_METRICS.METRICUPDATETIME) AS METRICUPDATETIME, SDB_METRICS.METRICDATACOUNT, SDB_METRICS.MINMETRICVALUE, SDB_METRICS.MAXMETRICVALUE, SDB_METRICS.MEANMETRICVALUE, SDB_METRICS.STDDEVMETRICVALUE FROM SDB_METRICS INNER JOIN LU_METRIC ON SDB_METRICS.FK_METRICID = LU_METRIC.PK_METRICID WHERE (SDB_METRICS.FK_SERVERID = '{0}') AND (LU_METRIC.FK_OBJECTID = '{1}') AND (LU_METRIC.FK_METRICCOUNTERID = '{2}') AND (LU_METRIC.FK_INSTANCEID = '{3}') AND (DATEADD(hh, {6}, SDB_METRICS.METRICUPDATETIME) BETWEEN DATEADD(hh, {7}, '{4}') AND DATEADD(hh, {7}, '{5}')) ORDER BY METRICUPDATETIME", ddlServers.SelectedValue, ddlObject.SelectedValue, ddlCounter.SelectedValue, ddlInstance.SelectedValue, strStartDate, strEndDate, utcOffset.ToString(), utcOffset2.ToString());

        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["rmsummarydbConnectionString"].ConnectionString);
        SqlCommand sqlCmd = new SqlCommand(strSql, sqlConn);

        SqlDataReader dr;

        sqlConn.Open();

        try
        {
            dr = sqlCmd.ExecuteReader();

            while (dr.Read())
            {
                DataRow drMetric = dtMetrics.NewRow();
                drMetric["UpdateTime"] = dr["METRICUPDATETIME"].ToString();
                drMetric["MaxValue"] = dr["MAXMETRICVALUE"].ToString();
                dtMetrics.Rows.Add(drMetric);
            }

            Chart metricChart = new Chart();

            strXML = metricChart.getMetricXML(dtMetrics, ddlCounter.SelectedItem.Text);

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }

        return strXML;
    }

    protected void ddlServers_DataBound(object sender, EventArgs e)
    {
        if (Request.QueryString["n"] != null)
            ddlServers.SelectedIndex = ddlServers.Items.IndexOf(ddlServers.Items.FindByText(Request.QueryString["n"]));
    }

    protected void ddlObject_DataBound(object sender, EventArgs e)
    {
        ListItem li = ddlObject.Items.FindByText("Processor");

        if (ddlObject.Items.Contains(li))
            ddlObject.SelectedIndex = ddlObject.Items.IndexOf(li);
    }
}
