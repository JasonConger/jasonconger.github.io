﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using CitrixMobility;
using System.Runtime.InteropServices;

namespace ResponsiveDemo
{
    public partial class ClientData : Form
    {
        private clientDataSet ds = new clientDataSet();
        private CitrixMobile cmp = null;
        private int deviceWidth = 0;
        private int deviceHeight = 0;
        private bool isMobile = false;
        private bool orientationEnabled = false;
        private string[] chartTypes;
        private int chartTypeIndex = 0;
        private const int PickerId = 0x13141516;
        private Rectangle viewport;

        #region WTS Handling
        
        [DllImport("WtsApi32.dll")]
        private static extern bool WTSRegisterSessionNotification(IntPtr hWnd, [MarshalAs(UnmanagedType.U4)]int dwFlags);

        [DllImport("WtsApi32.dll")]
        private static extern bool WTSUnRegisterSessionNotification(IntPtr hWnd);

        private const int NOTIFY_FOR_THIS_SESSION = 0;
        private const int WM_WTSSESSION_CHANGE = 0x2b1;
        private const int WTS_REMOTE_CONNECT = 0x3;
        private const int WTS_REMOTE_DISCONNECT = 0x4;
        private bool registered = false;

        protected override void OnHandleDestroyed(EventArgs e)
        {
            // unregister the handle before it gets destroyed
            if(registered)
                WTSUnRegisterSessionNotification(this.Handle);

            base.OnHandleDestroyed(e);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            registered = WTSRegisterSessionNotification(Handle, NOTIFY_FOR_THIS_SESSION);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_WTSSESSION_CHANGE)
            {
                if (m.WParam.ToInt32() == WTS_REMOTE_CONNECT)
                {
                    // The session is in the reconnect state, so style the app for the new session
                    setAppStyle();
                }

                if (m.WParam.ToInt32() == WTS_REMOTE_DISCONNECT)
                {
                    // The session is in the disconnect state, so close the CMP if it is open
                    if (this.cmp != null && this.cmp.IsChannelOpen())
                    {
                        try
                        {
                            this.cmp.CloseChannel();
                        }
                        catch {}
                    }
                }
            }
            base.WndProc(ref m);
        }

        #endregion

        public ClientData()
        {
            InitializeComponent();

            // Set up the supported chart types
            fillChartTypes();

            // Get some data
            fillDataSet();

            // set up our initial style based on device
            setAppStyle();
        }

        /// <summary>
        /// Sets the application style based on if it is running on a mobile device
        /// </summary>
        private void setAppStyle()
        {
            // Is this a mobile device?
            if (isMobileDevice())
            {
                // Set up some differnet things for mobile devices
                styleMobile();
            }
            else
            {
                // Set traditional style for non-mobile devices
                styleNormal();
            }
        }

        /// <summary>
        /// Sets up a string array to hold chart types based on the ToolStripMenu views
        /// </summary>
        private void fillChartTypes()
        {
            chartTypes = new string[chartTypeToolStripMenuItem.DropDownItems.Count];

            for (int i = 0; i < chartTypeToolStripMenuItem.DropDownItems.Count; i++)
            {
                chartTypes[i] = chartTypeToolStripMenuItem.DropDownItems[i].Text;
            }
        }

        /// <summary>
        /// Populates a dataset to be used for the chart and grid view
        /// </summary>
        private void fillDataSet()
        {
            // Normally, you would pull from a database or something here.
            // The data below was taken from an EdgeSight sample.  Some samples have been removed to
            // make the chart more interesting.
            //this.ds.dtClient.AdddtClientRow("12.1.0.30","30","Windows",21563);
            //this.ds.dtClient.AdddtClientRow("11.0.0.5357","5357","Windows",12302);
            this.ds.dtClient.AdddtClientRow("13.0.0.6685", "6685", "Windows", 636);
            this.ds.dtClient.AdddtClientRow("11.2.0.169077", "11200", "Mac", 595);
            this.ds.dtClient.AdddtClientRow("13.1.0.89", "89", "Windows", 575);
            this.ds.dtClient.AdddtClientRow("11.2.0.31560", "31560", "Windows", 373);
            this.ds.dtClient.AdddtClientRow("12.1.44.1", "1", "Windows", 296);
            this.ds.dtClient.AdddtClientRow("10.100.55836", "55836", "Windows", 241);
            this.ds.dtClient.AdddtClientRow("11.4.3.192268", "11403", "Mac", 219);
            this.ds.dtClient.AdddtClientRow("12.1.0.30", "0", "Unknown", 212);
            this.ds.dtClient.AdddtClientRow("11.4.0.188921", "11400", "Mac", 160);
            this.ds.dtClient.AdddtClientRow("11.3.2.176933", "11302", "Mac", 115);
            this.ds.dtClient.AdddtClientRow("11.0.0.5357", "0", "Unknown", 85);
            this.ds.dtClient.AdddtClientRow("11.0.150.5357", "5357", "Windows", 60);
            this.ds.dtClient.AdddtClientRow("12.0.0.6410", "6410", "Windows", 10);
            /*
            this.ds.dtClient.AdddtClientRow("13.1.0.89","0","Unknown",9);
            this.ds.dtClient.AdddtClientRow("1.0","1","Android",9);
            this.ds.dtClient.AdddtClientRow("10.150.58643","58643","Windows",9);
            this.ds.dtClient.AdddtClientRow("3.0.60","1","Android",4);
            this.ds.dtClient.AdddtClientRow("11.2.0.31560","0","Unknown",4);
            this.ds.dtClient.AdddtClientRow("2.1.1079","1","Android",3);
            this.ds.dtClient.AdddtClientRow("3.0.67","1","Android",3);
            this.ds.dtClient.AdddtClientRow("11.2.0.169077","0","Unknown",2);
            this.ds.dtClient.AdddtClientRow("2.1.1078","1","Android",2);
            this.ds.dtClient.AdddtClientRow("13.0.0.6685","0","Unknown",2);
            this.ds.dtClient.AdddtClientRow("11.4.3.192268","0","Unknown",1);
            this.ds.dtClient.AdddtClientRow("2.1 (1077)","1","Android",1);
            this.ds.dtClient.AdddtClientRow("12.1.44.1","0","Unknown",1);
            this.ds.dtClient.AdddtClientRow("3.0.10","1","Android",1);
            */

            chartClients.DataSource = this.ds.dtClient;

            chartClients.Series["Clients"].XValueMember = this.ds.dtClient.client_versionColumn.ColumnName;
            chartClients.Series["Clients"].YValueMembers = this.ds.dtClient.freqColumn.ColumnName;

            chartClients.DataBind();
            gridClients.DataSource = ds.dtClient;

            gridClients.Columns[0].HeaderText = "Client Version";
            gridClients.Columns[1].HeaderText = "Client Build";
            gridClients.Columns[2].HeaderText = "Client Platform";
            gridClients.Columns[3].HeaderText = "Amount Used";

        }

        private delegate void showChartDelegate();
        /// <summary>
        /// Shows the chart
        /// </summary>
        private void showChart()
        {
            if (InvokeRequired)
            {
                Invoke(new showChartDelegate(this.showChart));
            }
            else
            {
                splitContainer1.Panel2Collapsed = true;
                splitContainer1.Panel1Collapsed = false;
            }
        }

        private delegate void showGridDelegate();
        /// <summary>
        /// Shows the grid view
        /// </summary>
        private void showGrid()
        {
            if (InvokeRequired)
            {
                Invoke(new showGridDelegate(this.showGrid));
            }
            else
            {
                splitContainer1.Panel1Collapsed = true;
                splitContainer1.Panel2Collapsed = false;
            }
        }

        private delegate void setChartViewDelegate(string chartType);
        /// <summary>
        /// Changes the chart type
        /// </summary>
        /// <param name="chartType"></param>
        private void setChartView(string chartType)
        {
            if (InvokeRequired)
            {
                this.chartClients.Invoke(new setChartViewDelegate(this.setChartView), chartType);
            }
            else
            {
                this.timer1.Enabled = false;
                this.chartClients.ChartAreas[0].Area3DStyle.Rotation = 20;
                switch (chartType)
                {
                    case "Pie":
                        this.chartClients.Series["Clients"].ChartType = SeriesChartType.Pie;
                        this.chartClients.Series["Clients"].Palette = ChartColorPalette.BrightPastel;
                        this.chartClients.Series["Clients"].Label = "#PERCENT";

                        this.chartClients.Legends[0].Enabled = true;
                        break;
                    case "Doughnut":
                        this.chartClients.Series["Clients"].ChartType = SeriesChartType.Doughnut;
                        this.chartClients.Series["Clients"].Palette = ChartColorPalette.SemiTransparent;
                        this.chartClients.Series["Clients"].Label = "#PERCENT";
                        this.timer1.Enabled = true;
                        this.chartClients.Legends[0].Enabled = true;
                        break;
                    case "Column":
                        this.chartClients.Series["Clients"].ChartType = SeriesChartType.Column;
                        this.chartClients.Series["Clients"].Palette = ChartColorPalette.None;
                        this.chartClients.Series["Clients"].Label = "#PERCENT";
                        this.chartClients.Legends[0].Enabled = false;
                        break;
                    case "Area":
                        this.chartClients.Series["Clients"].ChartType = SeriesChartType.Area;
                        this.chartClients.Series["Clients"].Palette = ChartColorPalette.None;
                        this.chartClients.Series["Clients"].Label = "#AXISLABEL";
                        this.chartClients.Legends[0].Enabled = false;
                        break;
                    default:
                        this.chartClients.Series["Clients"].ChartType = SeriesChartType.Pie;
                        break;
                }

                this.chartClients.ResetAutoValues();
            }
        }

        /// <summary>
        /// Changes the chart type
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chartTypeToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            setChartView(e.ClickedItem.Text);
        }

        /// <summary>
        /// Exits the application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Rotates the chart
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (chartClients.ChartAreas[0].Area3DStyle.Rotation < 180)
                chartClients.ChartAreas[0].Area3DStyle.Rotation += 1;
            else
                chartClients.ChartAreas[0].Area3DStyle.Rotation = -180;
        }

        #region Citrix Mobility

        /// <summary>
        /// Returns an masked result code
        /// </summary>
        /// <param name="rc">Unmasked result code</param>
        /// <returns>Masked result code</returns>
        private bool CmpSuccess(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        /// <summary>
        /// Changes Winform layout if being viewed from a mobile device
        /// </summary>
        private void styleMobile()
        {
            // hide the window border
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

            // hide the top menu
            menuStrip1.Visible = false;

            // Show only the chart
            splitContainer1.Panel2Collapsed = true;
            splitContainer1.Dock = DockStyle.Fill;

        }

        /// <summary>
        /// Changes Winform layout if being viewed from traditional device
        /// </summary>
        private void styleNormal()
        {
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            this.Width = 600;
            this.Height = 700;

            splitContainer1.Panel1Collapsed = false;
            splitContainer1.Panel2Collapsed = false;
            splitContainer1.Dock = DockStyle.None;
            splitContainer1.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Bottom;
            splitContainer1.Location = new Point(0, 27);
            splitContainer1.SplitterDistance = 350;

            menuStrip1.Visible = true;
         }

        /// <summary>
        /// Tries to open a connection to the mobile device
        /// </summary>
        /// <returns>True if being viewed from a mobile device, otherwise False</returns>
        private bool isMobileDevice()
        {
            this.isMobile = false;
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                this.cmp = new CitrixMobile();

                // Try to open a session to the mobile device
                rc = cmp.OpenSession();

                if (CmpSuccess(rc))
                {
                    // This is a mobile device
                    this.isMobile = true;

                    // Get the width and height of the device
                    cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, 8, out this.deviceWidth);
                    cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, 9, out this.deviceHeight);

                    // Is orientation enabled?
                    cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, 0, out this.orientationEnabled);

                    // Register an event handler to catch orientation changes
                    if (this.orientationEnabled)
                    {
                        cmp.OrientationChanged += new ICMPEvents_OrientationChangedEventHandler(OrientationChanged);
                    }

                    short flags;
                    short zoom;
                    CMP_DISPLAY_RECT server, client;
                    int result = cmp.GetViewport(out flags, out zoom, out server, out client);
                    if (CmpSuccess(result))
                    {
                        cmp.ViewportChanged += new ICMPEvents_ViewportChangedEventHandler(ViewportChanged);
                        this.viewport = new Rectangle(client.Left, client.Top,
                            Math.Max(0, client.Right - client.Left),
                            Math.Max(0, client.Bottom - client.Top));
                        RepositionWindow();
                    }

                    cmp.PickerControlStateChanged += new ICMPEvents_PickerControlStateChangedEventHandler(cmp_PickerControlStateChanged);
                }
            }
            catch (Exception ex)
            {
                this.isMobile = false;
            }

            return isMobile;
        }

        /// <summary>
        /// Handles edge cases to ensure the window is always sized to match the client
        /// viewport. On orientation changes the size of the session will get changed if the
        /// session is set to fit-to-screen (which it should be). What can happen is the
        /// viewport change event can fire and trigger a window layout change before the session
        /// resize has completed on the server. This means your window will truncated down to
        /// a smaller size than expected.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnResize(EventArgs e)
        {
            if (this.isMobile)
            {
                //
                // If the size/position doesn't match what we were expecting, then retry setting it.
                //
                if (this.Top != this.viewport.Top ||
                    this.Left != this.viewport.Left ||
                    this.Width != this.viewport.Width ||
                    this.Height != this.viewport.Height)
                {
                    RepositionWindow();
                }
                else
                {
                    //
                    // Success - toggle portrait/landscape layout. This is a work around for the CMP
                    // orientation event not firing in some cases. Instead detect based on window
                    // dimensions. 
                    //
                    if (this.Width > this.Height)
                    {
                        showGrid();
                    }
                    else
                    {
                        showChart();
                    }
                }
            }

            base.OnResize(e);
        }

        /// <summary>
        /// Handler for the Citrix client viewport changing.
        /// </summary>
        private void ViewportChanged(int rc, short flags, short zoomFactor, int x0Server, int y0Server, int x1Server, int y1Server, int x0Client, int y0Client, int x1Client, int y1Client)
        {
            if (CmpSuccess(rc))
            {
                this.BeginInvoke((Action)delegate
                {
                    this.viewport = new Rectangle(x0Client, y0Client, x1Client - x0Client, y1Client - y0Client);
                    RepositionWindow();
                });
            }
        }

        /// <summary>
        /// Matches the size/position of the window to the client viewport.
        /// </summary>
        private void RepositionWindow()
        {
            this.Top = this.viewport.Top;
            this.Left = this.viewport.Left;
            this.Width = this.viewport.Width;
            this.Height = this.viewport.Height;
        }

        /// <summary>
        /// Event handler for mobile picker state change
        /// </summary>
        /// <param name="ControlId"></param>
        /// <param name="PickerFlags"></param>
        /// <param name="result"></param>
        /// <param name="SelectedItemIndex"></param>
        private void cmp_PickerControlStateChanged(int ControlId, short PickerFlags, int result, short SelectedItemIndex)
        {
            if (ControlId == PickerId)
            {
                if ((PickerFlags & (short)CMP_PICKER_CONTROL_STATE.CMP_PICKER_CONTROL_STATE_SELECTED) != 0)
                {
                    chartTypeIndex = SelectedItemIndex;
                    setChartView(chartTypes[SelectedItemIndex]);
                }
            }
        }

        /// <summary>
        /// Handles orientation changes on mobile devices
        /// </summary>
        /// <param name="cmpResult"></param>
        /// <param name="deviceOrientation"></param>
        /// <param name="appOrientation"></param>
        /// <param name="orientationFlags"></param>
        private void OrientationChanged(
            int cmpResult,
            CMP_ORIENTATION_POSITION deviceOrientation,
            CMP_ORIENTATION_POSITION appOrientation,
            short orientationFlags)
        {
            // TODO: for some reason, not always seeing this event.

            //if (deviceOrientation == CMP_ORIENTATION_POSITION.CMP_ORIENTATION_LANDSCAPE_LEFT || deviceOrientation == CMP_ORIENTATION_POSITION.CMP_ORIENTATION_LANDSCAPE_RIGHT)
            //{
            //    // Landscape should show the Data Grid
            //    showGrid();
            //}

            //if (deviceOrientation == CMP_ORIENTATION_POSITION.CMP_ORIENTATION_PORTRAIT || deviceOrientation == CMP_ORIENTATION_POSITION.CMP_ORIENTATION_PORTRAIT_UPSIDE_DOWN)
            //{
            //    // Portrait should show chart
            //    showChart();
            //}
        }


        /// <summary>
        /// Opition to change the chart type if this is a mobile device
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chartClients_Click(object sender, EventArgs e)
        {
            if (this.isMobile)
            {
                int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;
                CMP_DISPLAY_RECT rect = new CMP_DISPLAY_RECT();
                string pickerTitle = "Choose Chart Type";

                rc = cmp.ShowPicker(PickerId, ref rect, chartTypeIndex, ref chartTypes, pickerTitle);

                if (!CmpSuccess(rc))
                {
                    MessageBox.Show(String.Format("Failed to show picker rc={0:X}", rc), "Error");
                }
            }
        }

        #endregion
    }
}
