using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class userreport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        if (!IsPostBack)
        {
            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += " - User Report";

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        sqlUsers.SelectParameters["username"].DefaultValue = tbUsername.Text + "%";
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        tbUsername.Text = String.Empty;
        sqlUsers.SelectParameters["username"].DefaultValue = null;
    }

    protected void gvUsers_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='hand';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", String.Format("Click to view all session started by {0} . . .", e.Row.Cells[0].Text));
            e.Row.Attributes.Add("onClick", String.Format("location.href='userSessions.aspx?userID={0}&strUsername={1}'", gvUsers.DataKeys[e.Row.RowIndex].Value.ToString(), e.Row.Cells[1].Text));
        }
    }
}
