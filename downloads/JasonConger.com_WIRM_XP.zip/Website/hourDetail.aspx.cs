//--------------------------------------------------
// Name: Web Interface for Resource Manager
// Description: A collection of useful queries
// for the Citrix Resource Manager Summary Database
//
// Author:  Jason Conger (jason@jasonconger.com)
// URL:     http://www.jasonconger.com
// Date:    April 24th, 2006
//--------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class hourDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["utcOffset"] == null)
            Response.Redirect("Default.aspx");

        int utcOffset = int.Parse(Session["utcOffset"].ToString());
        string strDate = Request["strDate"];
        string strHour = Request["strHour"];

        string strStartDate = String.Format("{0} {1}:00:00", strDate, strHour);
        string strEndDate   = String.Format("{0} {1}:59:59", strDate, strHour);
                
        int utcOffset2 = utcOffset * -1;
        sqlHourDetail.SelectParameters["utcOffset"].DefaultValue = utcOffset.ToString();
        sqlHourDetail.SelectParameters["utcOffset2"].DefaultValue = utcOffset2.ToString();
        sqlHourDetail.SelectParameters["sessionStart"].DefaultValue = strStartDate;
        sqlHourDetail.SelectParameters["sessionEnd"].DefaultValue = strEndDate;

        if (Request["strAppID"].Trim() != String.Empty)
            sqlHourDetail.SelectParameters["appID"].DefaultValue = Request["strAppID"];
        else
            sqlHourDetail.SelectParameters["appID"].DefaultValue = null;

        if (!IsPostBack)
        {
            int intHour = int.Parse(strHour);

            if (intHour > 12)
            {
                intHour = intHour - 12;
                strHour = intHour.ToString() + ":00 PM";
            }
            else
            {
                strHour = strHour + ":00 AM";
            }

            Label lblHeader = (Label)Master.FindControl("lblHeader");
            lblHeader.Text += String.Format(" - Sessions started on {0} during {1}.", strDate, strHour);

            Page.Title = String.Format("Web Interface for Resource Manager - Sessions started on {0} during {1}.", strDate, strHour);

            Image imgHeader = (Image)Master.FindControl("imgHeader");
            imgHeader.ImageUrl = "~/images/users.gif";
        }
    }


    protected void gvHourDetail_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onMouseOver", "SetNewColor(this); this.style.cursor='hand';");
            e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
            e.Row.Attributes.Add("title", "Click to view session details . . .");
            e.Row.Attributes.Add("onClick", String.Format("location.href='sessionDetail.aspx?sessionID={0}'", gvHourDetail.DataKeys[e.Row.RowIndex].Value.ToString()));
        }
    }
}
