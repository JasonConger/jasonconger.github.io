/*

Project S-Bend

Author: Jason Conger
http://www.jasonconger.com/

The following script creates the Alerts table and SQL Trigger
for project S-Bend.

*/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [trig_ChangeAlert]
   ON  [dbo].[CtxLog_AdminTask_LogEntry]
   AFTER INSERT
AS 
BEGIN
     SET NOCOUNT ON;
     declare @LogEntry_RecordID int
     SELECT @LogEntry_RecordID = LogEntry_RecordID FROM INSERTED
     INSERT INTO Alerts (LogEntry_RecordID) VALUES (@LogEntry_RecordID)
END
GO
CREATE TABLE [dbo].[Alerts](
	[LogEntry_RecordID] [int] NOT NULL,
	[Processed] [bit] NOT NULL CONSTRAINT [DF_Alerts_Processed]  DEFAULT ((0)),
 CONSTRAINT [PK_Alerts] PRIMARY KEY CLUSTERED 
(
	[LogEntry_RecordID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO